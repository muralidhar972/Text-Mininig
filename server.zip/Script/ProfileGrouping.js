var divLength=0;
var $sourceFields;
var $destinationFields;
var $chooser;
var strGroupId='';

function _RefreshProfiles(param,id)
{
  strGroupId=id;
  $("#div_loader").show();
  $("#destinationFields").html('');
  $("#txtGroupName").removeClass('validateRed');
  $("#destinationFields").removeClass('validateRed');
  var strHTML='';
  var req = new XMLHttpRequest();
  req.open('GET', '/_api/MstProfiles');
  req.send();
  req.onload = function () 
  {
      var obj = JSON.parse(req.response);
      if(obj!==undefined && obj.length>0)
      {
        arrAllProfiles=obj;
        arrAllProfiles.sort(GetSortOrder("profile_name"));
        arrChildNode=[];
        for(var c=0;c<arrAllProfiles.length;c++)
        {
          if(arrAllProfiles[c].type!==undefined)
          {
            if($.trim(arrAllProfiles[c].type)==='group')
            {
              for(var m=0;m<arrAllProfiles[c].childnode.length;m++)
              {
                arrChildNode.push({'childnode':$.trim(arrAllProfiles[c].childnode[m].node),'parentnode':$.trim(arrAllProfiles[c]._id)});
              }
            }
          }
        }
        ShowGroup(param,strGroupId);
      }
      else
      {
        $("#div_loader").hide();
        arrAllProfiles=[];
        strHTML=strHTML+'<div class="profilecontent">No record found</div>';
        $("#div_ProfileWrapper").html('');
        $("#div_ProfileWrapper").html(strHTML);
        strHTML='';
      }
  };
}


function ShowGroup(param,strGroupId)
{
    var strHTML='';
    if(arrAllProfiles.length>0)
    {
      for(var i=0;i<arrAllProfiles.length;i++)
      {
        if(arrAllProfiles[i].type==="profile")
        {
          var retPro=arrChildNode.filter(function(el)
          {
            return $.trim(el.childnode)===$.trim(arrAllProfiles[i]._id)
          })
          if(retPro.length===0)
          {
            strHTML=strHTML+'<div id="proid_'+arrAllProfiles[i]._id+'">'+arrAllProfiles[i].profile_name+'</div>';
          }
        }
      }
    }
    $("#sourceFields").html('');
    $("#sourceFields").html(strHTML);
    strHTML='';
    if(param==='updategroup')
    {
      $("#showCreateGroup").attr('onclick',"_validateGrouping('updategroup','"+strGroupId+"')");
      _doEditGroup(strGroupId)
    }
    else
    {
      $("#div_loader").hide();
      $("#txtGroupName").removeAttr('disabled');
      $("#txtGroupName").val('');
      $('#myGroupSummary').modal('show');
      $sourceFields = $("#sourceFields");
      $destinationFields = $("#destinationFields");
      $chooser = $("#fieldChooser").fieldChooser(sourceFields, destinationFields);
      setTimeout(function()
      { 
        $(".rightgroup").height($(".leftgroup").height());
        $('.fc-field').mousedown(function(event) 
        {
          $(this).removeClass('fc-selected').addClass('fc-selected');
        });
        $('#fieldChooser').animate({ scrollTop: 0 }, 'slow');
        _groupName();
      }, 500);
    }
}

function fixGroupHeight(list)
{
  if(list.attr('id')==='sourceFields')
  {
    $(".rightgroup").height($(".rightgroup").height()+55);
    //$(".leftgroup").height($(".leftgroup").height()-55);
  }
  else
  {
    $(".leftgroup").height($(".leftgroup").height()+55);
    $(".rightgroup").height($(".rightgroup").height()-55);
  }
}


function _doEditGroup(profileid)
{
    var grpInfo=[];
    var strHTML='';
    var grpname='';
    var retPro=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(profileid)
    })
    grpname=retPro[0].profile_name;
    $("#div_loader").show();
    grpInfo.push({'grpid':profileid})
    var req = new XMLHttpRequest();
    
    req.open('POST', '/_api/groupinfo');
    req.setRequestHeader('content-type', 'application/json');
    req.send(JSON.stringify(grpInfo));

    req.onload = function ()
    {
        strHTML='';
        try
        {
          var obj = JSON.parse(req.response);
          if(obj.length>0)
          {
              var childNodes=obj[0].childnode;
              if(childNodes.length>0)
              {
                for(var i=0;i<childNodes.length;i++)
                {
                  var retPro=arrAllProfiles.filter(function(el)
                  {
                    return $.trim(el._id)===$.trim(childNodes[i].node)
                  })
                  if(retPro.length>0)
                  {
                    strHTML=strHTML+'<div id="proid_'+retPro[0]._id+'" class="fc-field" tabindex="1">'+retPro[0].profile_name+'</div>';
                  }
                }
              }
          }
          $("#destinationFields").html(strHTML);
          strHTML='';
          $("#div_loader").hide();
          $('#myGroupSummary').modal('show');
          $("#txtGroupName").val(grpname);
          $("#txtGroupName").attr('disabled',false);
          
          $sourceFields = $("#sourceFields");
          $destinationFields = $("#destinationFields");
          $chooser = $("#fieldChooser").fieldChooser(sourceFields, destinationFields);
          setTimeout(function()
          { 
            if($(".rightgroup").height()>$(".leftgroup").height())
            {
              $(".leftgroup").height($(".rightgroup").height());
            }
            else
            {
              $(".rightgroup").height($(".leftgroup").height());
            }
            $('.fc-field').mousedown(function(event) 
            {
              $(this).removeClass('fc-selected').addClass('fc-selected');
            });
            $('#fieldChooser').animate({ scrollTop: 0 }, 'slow'); 
            _groupName();
          }, 500);
        }
        catch (ex)
        {

        }
        
    }
}

function _validateGrouping(op,grpid)
{
    var arrSourceProfiles=[];
    var arrDestinationProfiles=[];
    if($.trim($("#txtGroupName").val())==="")
    {
      $("#txtGroupName").addClass('validateRed');
    }
    /*
    else if($("#destinationFields div").length===0)
    {
      $("#txtGroupName").removeClass('validateRed');
      $("#destinationFields").addClass('validateRed');
    }
    */
    else
    {
      $("#txtGroupName").removeClass('validateRed');
      $("#destinationFields").removeClass('validateRed');

      if($("#sourceFields div").length>0)
      {
        for(var k=0;k<$("#sourceFields div").length;k++)
        {
          arrSourceProfiles.push({'SourceProfile': $($("#sourceFields div")[k]).attr('id').split('_')[1]});
        }
      }
      else
      {
        arrSourceProfiles=[];
      }
      

      if($("#destinationFields div").length>0)
      {
        for(var k=0;k<$("#destinationFields div").length;k++)
        {
          arrDestinationProfiles.push({'DestinationProfile': $($("#destinationFields div")[k]).attr('id').split('_')[1]});
        }
      }
      else
      {
        arrDestinationProfiles=[];
      }


      if(arrDestinationProfiles.length>0)
      {
         var grpName=$.trim($("#txtGroupName").val());
        _updateGroup(arrDestinationProfiles,grpName,op,grpid);
      }
      else
      {
        //alert('Please select atleast one profile for a group');
        __alertfy('alertfy_Info','Please select atleast one profile for a group');
      }

    }

}


function _updateGroup(arrUpdateProfiles,grpName,op,grpid)
{
    var grpInfo=[];
    $('#myGroupSummary').modal('hide');
    $("#div_loader").show();
    grpInfo.push({'groupname':grpName,'profilesinfo':arrUpdateProfiles,'op':op,'groupid':grpid})
    var req = new XMLHttpRequest();
    
    req.open('POST', '/_api/updategroup');
    req.setRequestHeader('content-type', 'application/json');
    req.send(JSON.stringify(grpInfo));

    req.onload = function ()
    {
        $("#div_loader").hide();
        try
        {
          var obj = JSON.parse(req.response);
          //alert(obj.Result.Error);
          __alertfy('alertfy_error',obj.Result.Error);
          ReadPofileInfo();
        }
        catch (ex)
        {

        }
    }
}




function _checkGroupExistence()
{
    if($.trim($("#txtGroupName").val())!=='')
    {
      var req = new XMLHttpRequest();
      req.open('GET', '/_api/checkGroupExistence?groupname='+$.trim($("#txtGroupName").val()));
      req.send();
      req.onload = function () 
      {
          var obj = JSON.parse(req.response);
          if(obj.Result==='DuplicacyFound')
          {
            return "DuplicacyFound";
          }
          else if(obj.Result==='Valid')
          {
            return "Valid";
          }
      }
    }
    else
    {
      return "WrongSelection";
    }
}

function fnDeleteGroup(ctrl,profileid,event)
{
  if(confirm("All profiles will be deleted automatically which are associated with this group. Are you sure? You want to delete this group."))
  {
    var res=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(profileid)
    })
    $("#div_loader").show();
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/DeleteGroup?GroupName='+res[0].profile_name);
    req.send();
    req.onload = function () 
    {
      var obj = JSON.parse(req.response);
      $("#div_loader").hide();
      if(obj.Result==='Group_Deleted')
      {
         ReadPofileInfo();
      }
    };
  }
}


function _groupName()
{
  $(".grpName").keyup(function () 
    {
        var textValue = $(this).val();
        textValue =textValue.replace(/ /g,"_");
        var format = /[!@#$%^&*()+\=\[\]{};':"\\|<>\/?]+/;
        if(format.test(textValue))
        {
          var val=textValue.substring(0,textValue.length-1);
          $(this).val(val);
        } 
        else 
        {
          $(this).val(textValue);
        }
  });
}
