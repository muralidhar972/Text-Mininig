var arrAllProfiles=[];
var arrSourceData=[];
var arrSelectedProfileInfos=[];
var arrSelectedProfileData=[];
var iPageLoad=0;
var strSelectedProfileID='';
var arrColors=[];
var arrSearchFrequency=[];
var iColorCount=0;

var mark_container='';
var mark_keyword='';
var mark_color='';
var mark;
var actionDocId='';
var actionResponse='';
var clsRemoveSpace='';
var perPageDataLimit=50;
var startLimit=0;
var endLimit=0;
var selectedDB='';
var selectedDBAlias={};
var nxtItemID='';
var preItemID='';
var preProfileID='';
var nxtProfileID='';
var arrFiltered=new Array();
var arrCreatedItems=[];
var iScoreOrder=0;
var iTotalRecordCount=0;
var iSetCount=0;
var iCurrentSetNo=0;
var iNextPre=0;
var arrNextPre=[];
var arrFilteredData=[];
var iSelectedItemNo=0;
var arrSelectedProfileDetail=[];
var arrSelectedFilter=[
                        {"filter":'allitems',"keyColumn":'useraction','isApply':true,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'pending',"keyColumn":'useraction','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'relevant',"keyColumn":'useraction','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'not-relevant',"keyColumn":'useraction','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'read',"keyColumn":'modified','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'unread',"keyColumn":'modified','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'review',"keyColumn":'score_result','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'skip',"keyColumn":'score_result','isApply':false,'isChildNodeFilter':false,'childnode':[]},
                        {"filter":'Fields',"keyColumn":'fields','isApply':false,'isChildNodeFilter':false,'childnode':[]}
                      ];
var strSelectedSort='';
var ProgressPercentage=0;
var containerWidth=0;
var gotoNum=0;
var currentSelected='';
var applyCalendar=[];
var crtProName='';
var idecWidth=0;
var strSelectedItemID='';
var arrChildNode=[];
var arrDarkColors=['#FF8C00','#B8860B','#808000','#9ACD32','#6B8E23','#6A5ACD','#8B008B','#C12474','#F700F7','#1D88EA','#9400D3','#FF0000','#5C3317','#C71585','#7B7922','#6A287E','#E238EC','#4B0082','#F47D00','#CA226B','#7D0552','#800517','#657383','#413839','#2B1B17','#0C090A','#7E3517','#52D017','#5E7D7E','#3BB9FF','#6960EC','#151B54','#C11B17','#E41B17','#806517','#C7A317','#EAC117','#6C2DC7','#D2691E','#0000FF','#FF00FF','#800000','#008000','#800080','#008080','#000080','#DC143C','#FF4500','#2E473B','#D94D4A','#8B8989','#00FF00','#bfef45']

ReadPofileInfo();
/*
function ReadSourceDBsInfo() 
{
  $("#div_loader").show();
  var strHTML='';
  var req = new XMLHttpRequest();
  req.open('GET', '/_api/MstSourceDBsInfo');
  req.send();
  req.onload = function () 
  {
      selectedDBAlias = JSON.parse(req.response);
      ReadPofileInfo();
  };
}
*/

function ReadPofileInfo() 
{
  $("#div_loader").show();
  var strHTML='';
  var req = new XMLHttpRequest();
  req.open('GET', '/_api/MstProfiles');
  req.send();
  req.onload = function () 
  {
      var obj = JSON.parse(req.response);
      if(obj!==undefined && obj.length>0)
      {
        arrAllProfiles=obj;
        
        //arrAllProfiles.sort(GetSortOrder("profile_name"))
        arrChildNode=[];
        for(var c=0;c<arrAllProfiles.length;c++)
        {
          if(arrAllProfiles[c].type!==undefined)
          {
            if($.trim(arrAllProfiles[c].type)==='group')
            {
              for(var m=0;m<arrAllProfiles[c].childnode.length;m++)
              {
                arrChildNode.push({'childnode':$.trim(arrAllProfiles[c].childnode[m].node),'parentnode':$.trim(arrAllProfiles[c]._id)});
              }
            }
          }
        }
        for(var x=0;x<arrAllProfiles.length;x++)
        {
          var retPro=arrChildNode.filter(function(el)
          {
            return $.trim(el.childnode)===$.trim(arrAllProfiles[x]._id)
          })
          if(retPro.length===0)
          {
            if($.trim(arrAllProfiles[x].type)==='group')
            {
              strSelectedProfileID=$.trim(arrAllProfiles[x].childnode[0].node);
              var retdbName=arrAllProfiles.filter(function(el)
              {
                return $.trim(el._id)===$.trim(strSelectedProfileID)
              })
              selectedDB=retdbName[0].db_name;
            } 
            else
            {
              strSelectedProfileID=arrAllProfiles[x]._id;
              selectedDB=arrAllProfiles[x].db_name;
            }
            break;
          }
          else
          {
            if($.trim(arrAllProfiles[x].type)==='group')
            {
                if(arrAllProfiles[x].childnode.length>0)
                {
                  strSelectedProfileID=arrAllProfiles[x].childnode[0].node;
                  var checkGrp=arrAllProfiles.filter(function(el)
                  {
                    return $.trim(el._id)===$.trim(arrAllProfiles[x].childnode[0].node)
                  })
                  selectedDB=checkGrp[0].db_name;
                  break;
                }
            }
          }
        }
        containerWidth = $('.allprofiles').width()+$(".profiledetails").width()+$(".descriptiondetail").innerWidth();
        fnGetSelectedProfileInfos(strSelectedProfileID);
      }
      else
      {
        $("#div_loader").hide();
        arrAllProfiles=[];
        strHTML=strHTML+'<div class="profilecontent">No record found</div>';
        $("#div_ProfileWrapper").html('');
        $("#div_ProfileWrapper").html(strHTML);
        strHTML='';
      }
  };
}
function fnGetSelectedProfileInfos(profileId)
{
  $("#div_loader").show();
  //$("#ddlSort").val('allitems');
  $('#div_Items').animate({ scrollTop: 0 }, 'slow');
  arrFiltered=[];
  arrFilteredData=[];
  arrSelectedProfileInfos=[];
  iColorCount=0;
  arrColors=[];
  iPageLoad=0;
  strSelectedProfileID=profileId;
  iScoreOrder=0;
  iTotalRecordCount=0;
  startLimit=0;
  endLimit=0;
  iSetCount=0;
  iCurrentSetNo=1;
  iNextPre=0;
  iSelectedItemNo=0;
  arrSelectedProfileDetail=[];
  for(var em=0;em<arrSelectedFilter.length;em++)
  {
      if(arrSelectedFilter[em].filter==='allitems')
      {
        arrSelectedFilter[em].isApply=true;
        arrSelectedFilter[em].isChildNodeFilter=false;
        arrSelectedFilter[em].childnode=[];
      }
      else
      {
        arrSelectedFilter[em].isApply=false;
        arrSelectedFilter[em].isChildNodeFilter=false;
        arrSelectedFilter[em].childnode=[];
      }
  }
  strSelectedSort='score_asc';
  fnCancelGoTo();
  ResizeDocumentDetail();
  var res=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(profileId)
  })
  if(res.length>0)
  {
    arrSelectedProfileDetail=res;

    var req = new XMLHttpRequest();
    req.open('GET', '/_api/MstSelectedProfileInfos?dbName='+res[0].profile_name+'&Path=0');
    req.send();
    req.onload = function () 
    {
        var obj = JSON.parse(req.response);
        arrSelectedProfileInfos=obj;
        selectedDBAlias=arrSelectedProfileInfos[0].alias;
        $("#ul_filter").html('');
        $("#ul_sort").html('');
        var sHTML='';
        var flName='';

        //sHTML=sHTML+'<li class="selectedfilter" name="allitems" onclick=\'return applyFilter("allitems","filter","allitems");\'><a href="javascript:void(0);" >All documents</a></li>';
        sHTML=sHTML+'<li class="applyfilter"><a onclick=\'return applyFilter();\' href="javascript:void(0);" >Apply filter</a></li>';
        sHTML=sHTML+'<li><a name="pending" onclick=\'return __setFilter("pending","filter","pending");\' href="javascript:void(0);">Pending <i onclick=\'return __removeFilter("pending","filter","pending",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="relevant" onclick=\'return __setFilter("relevant","filter","relevant");\' href="javascript:void(0);">Relevant <i onclick=\'return __removeFilter("relevant","filter","relevant",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="not-relevant" onclick=\'return __setFilter("not-relevant","filter","not-relevant");\' href="javascript:void(0);">Non-Relevant <i onclick=\'return __removeFilter("not-relevant","filter","not-relevant",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="unread" onclick=\'return __setFilter("unread","filter","unread");\' href="javascript:void(0);">Unread <i onclick=\'return __removeFilter("unread","filter","unread",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="read" onclick=\'return __setFilter("read","filter","read");\' href="javascript:void(0);">Read <i onclick=\'return __removeFilter("read","filter","read",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="review" onclick=\'return __setFilter("review","filter","review");\' href="javascript:void(0);">Review <i onclick=\'return __removeFilter("review","filter","review",event);\' class="fa fa-times"></i></a></li>';
        sHTML=sHTML+'<li><a name="skip" onclick=\'return __setFilter("skip","filter","skip");\' href="javascript:void(0);">Skip <i onclick=\'return __removeFilter("skip","filter","skip",event);\' class="fa fa-times"></i></a></li>';
        applyCalendar=[];
        if(arrSelectedProfileInfos[0].fields.length>0)
        {
          sHTML=sHTML+'<li class="hasChildren" id="li_fields"><a name="Fields" href="javascript:void(0);" class="listFields">Fields<span class="fa fa-caret-right listFieldsArrow"></span></a>';
          sHTML=sHTML+'<ul id="ul_Fields" style="display:none;">';
          for(var m=0;m<arrSelectedProfileInfos[0].fields.length;m++)
          {
            if($.trim(arrSelectedProfileInfos[0].fields[m].name)!=='')
            {
              flName=$.trim(arrSelectedProfileInfos[0].fields[m].name);
              if($.trim(flName)!=="_id" && $.trim(flName)!=="__EMPTY" && $.trim(flName)!=="Unnamed__0" && $.trim(flName)!=="0" && $.trim(flName)!=="Unnamed: 0" && $.trim(flName)!=="")
              {
                sHTML=sHTML+'<li id="fields__li__'+flName+'"><a href="javascript:void(0);">'+flName+'</a>';
                if(arrSelectedProfileInfos[0].fields[m].type!==undefined)
                {
                  if($.trim(arrSelectedProfileInfos[0].fields[m].type[0])==='date')
                  {
                    applyCalendar.push({'FieldName':flName});
                    arrSelectedFilter[arrSelectedFilter.length-1].childnode.push({'FieldName':flName,'isApply':false,'parentNode':'Fields','ctrlType':'date','primaryCtrlId':'txt_startDT___'+flName+'','secondaryCtrlId':'txt_endDT___'+flName+'','primaryCtrlValue':'','secondaryCtrlValue':''});
                    sHTML=sHTML+'<input type="text" class="appCustomFilter txtStartDateFilter" id="txt_startDT___'+flName+'" placeholder="Start date" />';
                    sHTML=sHTML+'<input type="text" class="appCustomFilter txtEndDateFilter" id="txt_endDT___'+flName+'" placeholder="End date" />';
                    sHTML=sHTML+'<a href="javascript:void(0);" class="btnDateFilter itemtick" name="'+flName+'" id="anc_'+flName+'" onclick=\'return __setFilter("Fields","customfilter","'+flName+'");\'><i class="fa fa-plus" aria-hidden="true" title="Apply filter"></i></a>';
                    sHTML=sHTML+'<a href="javascript:void(0);" class="btnDateFilter itemtick" name="cancel_'+flName+'" id="anc_cancel_'+flName+'" onclick=\'return __setFilter("Fields","cancelCustomfilter","'+flName+'");\'><i class="fa fa-times" aria-hidden="true" title="Cancel filter"></i></a>';
                  }
                  else
                  {
                    arrSelectedFilter[arrSelectedFilter.length-1].childnode.push({'FieldName':flName,'isApply':false,'parentNode':'Fields','ctrlType':'text','primaryCtrlId':'txt___'+flName+'','secondaryCtrlId':'','primaryCtrlValue':'','secondaryCtrlValue':''});
                    sHTML=sHTML+'<input type="text" class="appCustomFilter" id="txt___'+flName+'" placeholder="Please enter filter keyword" />';
                    sHTML=sHTML+'<a href="javascript:void(0);" class="itemtick" name="'+flName+'" id="anc_'+flName+'" onclick=\'return __setFilter("Fields","customfilter","'+flName+'");\'><i class="fa fa-plus" aria-hidden="true" title="Apply filter"></i></a>';
                    sHTML=sHTML+'<a href="javascript:void(0);" class="itemtick" name="cancel_'+flName+'" id="anc_cancel_'+flName+'" onclick=\'return __setFilter("Fields","cancelCustomfilter","'+flName+'");\'><i class="fa fa-times" aria-hidden="true" title="Cancel filter"></i></a>';
                  }
                }
                else
                {
                  arrSelectedFilter[arrSelectedFilter.length-1].childnode.push({'FieldName':flName,'isApply':false,'parentNode':'Fields','ctrlType':'text','primaryCtrlId':'txt___'+flName+'','secondaryCtrlId':'','primaryCtrlValue':'','secondaryCtrlValue':''});
                  sHTML=sHTML+'<input type="text" class="appCustomFilter" id="txt___'+flName+'" placeholder="Please enter filter keyword" />';
                  sHTML=sHTML+'<a href="javascript:void(0);" class="itemtick" name="'+flName+'" id="anc_'+flName+'" onclick=\'return __setFilter("Fields","customfilter","'+flName+'");\'><i class="fa fa-plus" aria-hidden="true" title="Apply filter"></i></a>';
                  sHTML=sHTML+'<a href="javascript:void(0);" class="itemtick" name="cancel_'+flName+'" id="anc_cancel_'+flName+'" onclick=\'return __setFilter("Fields","cancelCustomfilter","'+flName+'");\'><i class="fa fa-times" aria-hidden="true" title="Cancel filter"></i></a>';
                }
                sHTML=sHTML+'</li>';
              }
            }
          }
          sHTML=sHTML+'</ul>';
          sHTML=sHTML+'</li>';
        }
        $("#ul_filter").append(sHTML);
        sHTML='';
     
        $(".appCustomFilter").on('blur change', function(e) //keyup keypress blur change
        {
          $("#ul_filter").css('display','block');
        });
        for(var t=0;t<applyCalendar.length;t++)
        {
          var valid=applyCalendar.filter(function(em)
          {
            return $.trim(em.FieldName)===$.trim(applyCalendar[t].FieldName)
          });
          if(valid.length>0)
          {
            $("#txt_startDT___"+applyCalendar[t].FieldName).datepicker({
              changeMonth: true,
              changeYear: true,
              yearRange: "-50:+0"
            });
            $("#txt_endDT___"+applyCalendar[t].FieldName).datepicker({
              changeMonth: true,
              changeYear: true,
              yearRange: "-50:+0"
            });
          }
          else
          {
            $("#txt___"+applyCalendar[t].FieldName).datepicker();
          }
        }
        $("#ul_Fields li").hover(function(e)
        {
            e.preventDefault();
            $(".appCustomFilter").css('display','none');
            $(".itemtick").css('display','none');
            $(".appCustomFilter").parent().css('background','#fff');
            
            var id=$.trim($(this).attr('id').split('__')[2]);
            $("#ul_filter").css('display','block');
            var chk=applyCalendar.filter(function(ee)
            {
              return $.trim(ee.FieldName)===$.trim(id)
            });
            if(chk.length>0)
            {
              $("#txt_startDT___"+id).css('display','block');
              $("#txt_endDT___"+id).css('display','block');
              $($("#txt_startDT___"+id).siblings()[2]).css('display','block');
              $(this).css('background','#edf2ff');
              currentSelected=id;
            }
            else
            {
              $("#txt___"+id).css('display','block');
              $($("#txt___"+id).siblings()[1]).css('display','block');
              $(this).css('background','#edf2ff');
              currentSelected='';
            }
            $(".ui-datepicker-prev").click(function(ev){
              ev.preventDefault();
            })
            $(".ui-datepicker-next").click(function(evt){
              evt.preventDefault();
            })
        })
        
        $(".ui-datepicker").hover(function(e)
        {
            e.preventDefault();
            if(currentSelected!=='')
            {
              $("#ul_filter").css('display','block');
              $("#ul_Fields").css('display','block');
              var chk=applyCalendar.filter(function(ee)
              {
                return $.trim(ee.FieldName)===$.trim(currentSelected)
              });
              if(chk.length>0)
              {
                $("#txt_startDT___"+currentSelected).css('display','block');
                $("#txt_endDT___"+currentSelected).css('display','block');
                $($("#txt_startDT___"+currentSelected).siblings()[2]).css('display','block');
              }
              else
              {
                $("#txt___"+currentSelected).css('display','block');
                $($("#txt___"+currentSelected).siblings()[1]).css('display','block');
              }
            }
        })
      
        sHTML=sHTML+'<li name="score" onclick=\'return applySort("score_asc","sort","score");\'><a href="javascript:void(0);" >Score &nbsp; <span style="color:#fff;" class="glyphicon glyphicon-sort-by-alphabet asc score" ></span></a></li>';
        if(arrSelectedProfileInfos[0].alias!==undefined)
        {
          sHTML=sHTML+'<li name="Title" onclick=\'return applySort("Title_asc","customsort","'+arrSelectedProfileInfos[0].alias.Title+'");\'><a href="javascript:void(0);" >'+arrSelectedProfileInfos[0].alias.Title+' &nbsp; <span style="color:#fff;" class="glyphicon" ></span></a></li>';
          sHTML=sHTML+'<li name="ID" onclick=\'return applySort("ID_asc","customsort","'+arrSelectedProfileInfos[0].alias.ID+'");\'><a href="javascript:void(0);" >'+arrSelectedProfileInfos[0].alias.ID+' &nbsp; <span style="color:#fff;" class="glyphicon" ></span></a></li>';
          sHTML=sHTML+'<li name="Date" onclick=\'return applySort("Date_asc","customsort","'+arrSelectedProfileInfos[0].alias.Date+'");\'><a href="javascript:void(0);" >'+arrSelectedProfileInfos[0].alias.Date+' &nbsp; <span style="color:#fff;" class="glyphicon" ></span></a></li>';
          sHTML=sHTML+'<li name="Link" onclick=\'return applySort("Link_asc","customsort","'+arrSelectedProfileInfos[0].alias.Link+'");\'><a href="javascript:void(0);" >'+arrSelectedProfileInfos[0].alias.Link+' &nbsp; <span style="color:#fff;" class="glyphicon" ></span></a></li>';
        }
        $("#ul_sort").append(sHTML);
        sHTML='';
        
        var applySetFilter=arrSelectedFilter.filter(function(ee)
        {
          return $.trim(ee.filter)===$.trim('allitems')
        });
        applySetFilter[0].isApply=true;
        strSelectedSort=$("#ul_sort li.selectedSort").attr('name')===undefined?'':$("#ul_sort li.selectedSort").attr('name');
        fnSetCategoryColor(iColorCount);
    };
  }
  else
  {
     //alert('Selected profile not found in database');
     __alertfy('alertfy_warning','Selected profile not found in database');
  }
}

function __alertfy(clname,msg)
{
  $( "#div_bucketcomment" ).dialog( "close" ).dialog( "open" );
  $(".ui-dialog-titlebar").removeClass('alertfy_success').removeClass('alertfy_error').removeClass('alertfy_warning').removeClass('alertfy_Info');
  $(".ui-dialog-titlebar").addClass(clname);
  $(".ui-dialog-titlebar-close").removeClass('alertfy_closebtn').addClass('alertfy_closebtn');
  $("#div_bucketcomment p").html(msg);
  $( "#div_bucketcomment" ).parent().removeClass('alertfy_success_parent').removeClass('alertfy_error_parent').removeClass('alertfy_warning_parent').removeClass('alertfy_Info_parent');
  $( "#div_bucketcomment" ).parent().addClass(clname+'_parent');
}

function ResizeDocumentDetail()
{
    var resize= $(".isresize");
    //var containerWidth = $('.allprofiles').width()+$(".profiledetails").width()+$(".descriptiondetail").width();
    var timeoutvar = 0;
    $(resize).resizable({
          handles: 'e',
          maxWidth: containerWidth,   //700
          minWidth: 250,
          resize: function(event, ui){
              var _this = this;
              var currentWidth = ui.size.width;
              var padding = 60; 
              $(_this).width(currentWidth);
              if($(_this).attr('name')==='allprofiles')
              {
                $(".descriptiondetail").width(containerWidth - (currentWidth+$('.profiledetails').width()) - padding);
                $(".profiledetails").width(containerWidth - (currentWidth+$('.descriptiondetail').width()) - padding);
              }
              else if($(_this).attr('name')==='profiledetails')
              {
                $(".descriptiondetail").width(containerWidth - (currentWidth+$('.allprofiles').width()) - padding);
                $(".allprofiles").width(containerWidth - (currentWidth+$('.descriptiondetail').width()) - padding);
              }
              else if($(_this).attr('name')==='descriptiondetail')
              {
                $(".allprofiles").width(containerWidth - (currentWidth+$('.profiledetails').width()) - padding);
                $(".profiledetails").width(containerWidth - (currentWidth+$('.allprofiles').width()) - padding);
              }
          }
    });
}
function fnSlideProfilePanel(ctrlID,id,event)
{
  event.preventDefault();
  $("."+ctrlID).animate({
    width: "toggle"
  });
  setTimeout(function()
  { 
      if($('.allprofiles').css('display') == 'none' && $('.profiledetails').css('display') == 'none')
      {
        var padding = 60;
        //$(".descriptiondetail").width($(".descriptiondetail").width() + $('.allprofiles').width()+$('.profiledetails').width() - padding);
        $(".descriptiondetail").css('width','100%');
        $("#spn_AllProfileSection").css('display','');
        $("#spn_DocumentSection").css('display','');
      }
      else if($('.allprofiles').css('display') != 'none' && $('.profiledetails').css('display') == 'none')
      {
        var padding = 60;
        //$(".descriptiondetail").width($(".descriptiondetail").width() + $('.profiledetails').width() - padding);
        $(".allprofiles").css('width','22%');
        $(".descriptiondetail").css('width','78%');
        $("#spn_AllProfileSection").css('display','none');
        $("#spn_DocumentSection").css('display','');
      }
      else if($('.allprofiles').css('display') == 'none' && $('.profiledetails').css('display') != 'none')
      {
        $(".descriptiondetail").css('width','56%');
        $(".profiledetails").css('width','44%');
        var padding = 60;
        //$(".profiledetails").width($(".profiledetails").width() + $('.allprofiles').width() - padding);
        $("#spn_AllProfileSection").css('display','');
        $("#spn_DocumentSection").css('display','none');
      }
      else if($('.allprofiles').css('display') != 'none' && $('.profiledetails').css('display') != 'none')
      {
        $(".descriptiondetail").css('width','56%');
        $(".profiledetails").css('width','22%');
        $(".allprofiles").css('width','22%');
        var padding = 60;
        $("#spn_AllProfileSection").css('display','none');
        $("#spn_DocumentSection").css('display','none');
      }
      /*
      var totalWidth=$('.allprofiles').width()+$('.profiledetails').width()+$('.descriptiondetail').innerWidth();
      if(totalWidth<containerWidth)
      {
        var padding = 60;
        var diff=containerWidth-totalWidth;
        var addedWidth=$('.descriptiondetail').width()+diff-padding;
        $('.descriptiondetail').width(addedWidth);
      }
      else if(totalWidth>containerWidth)
      {
        var padding = 60;
        var diff=totalWidth-containerWidth;
        var addedWidth=$('.descriptiondetail').width()-diff-padding;
        $('.descriptiondetail').width(addedWidth);
      }
      */
      
   }, 500);
}
function fnToggle(ctrlID)
{
  currentSelected='';
  $(".appCustomFilter").css('display','none');
  $(".itemtick").css('display','none');
  $(".appCustomFilter").parent().css('background','#fff');
  if((ctrlID)==='ul_filter')
  {
    $("#ul_sort").css('display','none');
    $("#ul_Fields").css('display','none');
    //$("#"+ctrlID).slideToggle();
    $("#"+ctrlID).show();
  }
  else if((ctrlID)==='ul_sort')
  {
    $("#ul_filter").css('display','none');
    $("#"+ctrlID).slideToggle();
  }
  else if((ctrlID)==='clear_sort_filter')
  {
    fnClearFilterSort();
  }
  
  $('#ul_filter').click(function(e) 
  {
      e.stopPropagation();
  });
}

$(document).click(function(e)
{
  $("#ul_filter").css('display','none');
  $("#ul_sort").css('display','none');
  $("#ul_Fields").css('display','none');
  $("#div_profileNavigation").hide();
  //$("#spninformation").hide();
})



$('.sortby').click(function(e) {
  e.stopPropagation();
})

function fnChangeProgressBarStatus(proName)
{
  if(ProgressPercentage===1)
  {
    crtProName=proName;
    //blockMsg();
  }
  var req = new XMLHttpRequest();
  req.open('GET', '/_api/CheckProfileCreationStatus?ProfileName='+crtProName);
  req.send();
  req.onload = function () 
  {
      var obj = JSON.parse(req.response);
      if(obj.ReqStatus==='completed')
      {
        $('#blockUIMsg').html('Profile - '+crtProName+' has been created successfully. Thank you for your patience.');
        blockMsg();

        setTimeout($.unblockUI, 2000);
        ReadPofileInfo();
      }
      else
      {
        if(obj.ReqStatus==='Mst_DB_profile_creation' || obj.ReqStatus==='Infos_collection_creation' || obj.ReqStatus==='data_collection_creation' || obj.ReqStatus==='score_updating')
        {
          if(obj.ReqStatus==='Mst_DB_profile_creation')
            $('#blockUIMsg').html('We are creating your profile. Please be patient.');
          else if(obj.ReqStatus==='Infos_collection_creation')
            $('#blockUIMsg').html('We are saving profile information. Please be patient.');
          else if(obj.ReqStatus==='data_collection_creation')
            $('#blockUIMsg').html('We are applying filter for your profile. Please be patient.');
          else if(obj.ReqStatus==='score_updating')
            $('#blockUIMsg').html('We are updating score for your profile. Please be patient.');

          blockMsg();
          if(ProgressPercentage===1)
          {
            setTimeout(function()
            { 
              ProgressPercentage=parseInt(ProgressPercentage)+1;
              fnChangeProgressBarStatus(); 
            }, 1000);
          }
          else if(ProgressPercentage===2)
          {
            setTimeout(function()
            { 
              ProgressPercentage=parseInt(ProgressPercentage)+1;
              fnChangeProgressBarStatus(); 
            }, 3000);
          }
          else
          {
            setTimeout(function()
            { 
              ProgressPercentage=parseInt(ProgressPercentage)+1;
              fnChangeProgressBarStatus(); 
            }, 8000);
          }
        }
        else
        {
          $('#blockUIMsg').html('Something went wrong. Kindly refresh the page or contact to site administrator.');
          blockMsg();
          setTimeout($.unblockUI, 3000);
        }
      }
  };
}

function blockMsg()
{
  $.blockUI({
    css: {
      border: '5px solid #3c8dbc',
      borderRadius: '5px',
      padding: '20px 0'
    },
    message: $('#domMessage')
  });
}

/*
function fnChangeProgressBarStatus()
{
  ProgressPercentage=parseInt(ProgressPercentage)+5;
  if(ProgressPercentage>=100)
  {
    $("#div_Progressbar").css('display','none');
    ReadPofileInfo();
  }
  else
  {
    $("#div_Progressbar").css('display','block');
    $("#div_Progressbar .progress .progress-bar").attr('aria-valuenow',ProgressPercentage);
    var p=ProgressPercentage+'%';
    $("#div_Progressbar .progress .progress-bar").css('width',p);
    $("#div_Progressbar .progress .progress-bar").html(ProgressPercentage+'%')
    if(ProgressPercentage<100)
    {
      setTimeout(function()
      { 
        fnChangeProgressBarStatus(); 
      }, 1000);
    }
  }
}
*/


function fnSetCategoryColor(iColorCount)
{
    if(parseInt(iColorCount)>arrSelectedProfileInfos[0].categories.length-1)
    {
       fnGetSelectedProfileData(strSelectedProfileID,arrSelectedFilter,strSelectedSort,'filter');
    }
    else
    {
      fnRandUniqueColor(arrSelectedProfileInfos[0].categories[iColorCount].catname);
    }
}

function fnRandUniqueColor(catName) 
{
    var lum = -0.25;
    var hex = String('#' + Math.random().toString(16).slice(2, 8).toUpperCase()).replace(/[^0-9a-f]/gi, '');
    if (hex.length < 6) 
    {
        hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
    }
    var rgb = "#",
        c, i;
    for (i = 0; i < 3; i++) 
    {
        c = parseInt(hex.substr(i * 2, 2), 16);
        c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
        rgb += ("00" + c).substr(c.length);
    }
    if(arrColors.length>0)
    {
      var chk=arrColors.filter(function(ee)
      {
        return $.trim(ee.color)===$.trim(rgb)
      });
      if(chk.length===0)
      {
        arrColors.push({'CatName':catName,'color':rgb});
        iColorCount++;
        fnSetCategoryColor(iColorCount);
      }
      else
      {
        fnRandUniqueColor();
      }
    }
    else
    {
      arrColors.push({'CatName':catName,'color':rgb});
      iColorCount++;
      fnSetCategoryColor(iColorCount);
    }
}

function fnClearFilterSort()
{
  strSelectedSort='';
  for(var em=0;em<arrSelectedFilter.length;em++)
  {
    if(arrSelectedFilter[em].filter==='allitems')
    {
      arrSelectedFilter[em].isApply=true;
      arrSelectedFilter[em].isChildNodeFilter=false;
      //arrSelectedFilter[em].childnode=[];
    }
    else
    {
      arrSelectedFilter[em].isApply=false;
      arrSelectedFilter[em].isChildNodeFilter=false;
      //arrSelectedFilter[em].childnode=[];
    }
  }

  var childFilter=arrSelectedFilter[arrSelectedFilter.length-1];
  for(var t=0;t<childFilter.length;t++)
  {
    childFilter[t].isApply=false;
    childFilter[t].primaryCtrlValue='';
    childFilter[t].secondaryCtrlValue='';
  }

  iScoreOrder=0;
  iTotalRecordCount=0;
  startLimit=0;
  endLimit=0;
  iSetCount=0;
  iCurrentSetNo=1;
  iNextPre=0;
  iSelectedItemNo=0;
  arrFilteredData=[];
  $(".sortby span.glyphicon-filter").removeClass('activate')
  $(".sortby span.glyphicon-sort").removeClass('activate')
  $(".sortby span.glyphicon-remove").removeClass('activate').addClass('activate')
  $("#ul_sort li").removeClass('selectedSort');
  $("#ul_filter li").removeClass('selectedfilter');

  $("#ul_Fields input[type=text]").removeClass('validateRed');
  $("#ul_Fields input[type=text]").val('');

  $("#taRight_Comment").val('');
  $('#div_Items').animate({ scrollTop: 0 }, 'slow');
  $("#div_loader").show();
  fnGetSelectedProfileData(strSelectedProfileID,arrSelectedFilter,strSelectedSort,"filter");
}

function __removeFilter(param,action,nameAttr,event)
{
    var applySetFilter=arrSelectedFilter.filter(function(ee)
    {
      return $.trim(ee.filter)===$.trim(param)
    });
    if(applySetFilter.length>0 && applySetFilter[0].isApply)
    {
      applySetFilter[0].isApply=false;
    }

    $("#ul_filter li").removeClass('selectedfilter');
    for(var c=0;c<arrSelectedFilter.length;c++)
    {
      if(arrSelectedFilter[c].isApply)
        $("#ul_filter [name="+arrSelectedFilter[c].filter+"]").parent().addClass('selectedfilter');
    }
    event.cancelBubble=true;
}

function __setFilter(param,action,nameAttr)
{
    if($.trim(action)==='filter')
    {
        var applySetFilter=arrSelectedFilter.filter(function(ee)
        {
          return $.trim(ee.filter)===$.trim(param)
        });
        if(applySetFilter[0].isApply)
        {
          //applySetFilter[0].isApply=false;
          //arrFilteredData=arrSelectedProfileData;
        }
        else
        {
          applySetFilter[0].isApply=true;
        }
    }
    else
    {
        if($.trim(action)==='cancelCustomfilter')
        {
            var childFilter=arrSelectedFilter[arrSelectedFilter.length-1];
            var applySetFilter=childFilter.childnode.filter(function(ee)
            {
              return $.trim(ee.FieldName)===$.trim(nameAttr)
            });

            applySetFilter[0].isApply=false;
            if(applySetFilter[0].ctrlType==="date")
            {
              $("#"+applySetFilter[0].primaryCtrlId).val('');
              $("#"+applySetFilter[0].secondaryCtrlId).val('');

              $("#"+applySetFilter[0].primaryCtrlId).removeClass('validateRed');
              $("#"+applySetFilter[0].secondaryCtrlId).removeClass('validateRed');
            }
            else
            {
              $("#"+applySetFilter[0].primaryCtrlId).val('');
              $("#"+applySetFilter[0].primaryCtrlId).removeClass('validateRed');
            }
            arrFilteredData=arrSelectedProfileData;

            $("#anc_"+nameAttr).parent().removeClass('itemtickactive');
        }
        else
        {
            var childFilter=arrSelectedFilter[arrSelectedFilter.length-1];
            childFilter.isApply=true;

            var applySetFilter=childFilter.childnode.filter(function(ee)
            {
              return $.trim(ee.FieldName)===$.trim(nameAttr)
            });

            if(applySetFilter[0].ctrlType==='date')
            {
              if($.trim($("#"+applySetFilter[0].primaryCtrlId).val())!=='' && $.trim($("#"+applySetFilter[0].secondaryCtrlId).val())!=='')
              {
                  applySetFilter[0].isApply=true;
                  $("#anc_"+nameAttr).parent().addClass('itemtickactive');
                  $("#"+applySetFilter[0].primaryCtrlId).removeClass('validateRed');
                  $("#"+applySetFilter[0].secondaryCtrlId).removeClass('validateRed');
                  applySetFilter[0].primaryCtrlValue=$("#"+applySetFilter[0].primaryCtrlId).val();
                  applySetFilter[0].secondaryCtrlValue=$("#"+applySetFilter[0].secondaryCtrlId).val();
              }
              else
              {
                  $("#"+applySetFilter[0].primaryCtrlId).addClass('validateRed');
                  $("#"+applySetFilter[0].secondaryCtrlId).addClass('validateRed');
                  //alert('Please select start date and end date');
              }
            }
            else
            {
                if($.trim($("#"+applySetFilter[0].primaryCtrlId).val())!=='')
                {
                  applySetFilter[0].isApply=true;
                  $("#anc_"+nameAttr).parent().addClass('itemtickactive');
                  $("#"+applySetFilter[0].primaryCtrlId).removeClass('validateRed');
                  applySetFilter[0].primaryCtrlValue=$("#"+applySetFilter[0].primaryCtrlId).val();
                }
                else
                {
                  $("#"+applySetFilter[0].primaryCtrlId).addClass('validateRed');
                  //alert('Please enter filter text');
                }
            }
        }
    }

    var childFilter=arrSelectedFilter[arrSelectedFilter.length-1];
    var checkCustomFilter=childFilter.childnode.filter(function(ee)
    {
      return ee.isApply===true
    });
    if(checkCustomFilter.length===0)
    {
      childFilter.isApply=false;
    }

    $("#ul_filter li").removeClass('selectedfilter');
    for(var c=0;c<arrSelectedFilter.length;c++)
    {
      if(arrSelectedFilter[c].isApply)
        $("#ul_filter [name="+arrSelectedFilter[c].filter+"]").parent().addClass('selectedfilter');
    }
}

function applySort(param,action,nameAttr)
{
    iNextPre=0;
    $(".sortby span.glyphicon-remove").removeClass('activate')

    if(action==='sort' || action==='customsort')
    {
      $("#div_loader").show();
      $("#ul_sort li").removeClass('selectedSort');
      $("#ul_sort li a span").removeClass('glyphicon-sort-by-alphabet').removeClass('glyphicon-sort-by-alphabet-alt');
      $('#div_Items').animate({ scrollTop: 0 }, 'slow');
      var sortOpt=$.trim(param).split('_');
      if($.trim(sortOpt[1])==='asc')
      {
        strSelectedSort=$.trim(param).split('_')[0]+'_desc';
        $("#ul_sort [name="+sortOpt[0]+"] a span").removeClass('glyphicon-sort-by-alphabet').removeClass('glyphicon-sort-by-alphabet-alt');
        $("#ul_sort [name="+sortOpt[0]+"] a span").addClass('glyphicon-sort-by-alphabet-alt');
      }
      else if($.trim(sortOpt[1])==='desc')
      {
        strSelectedSort=$.trim(param).split('_')[0]+'_asc';
        $("#ul_sort [name="+sortOpt[0]+"] a span").removeClass('glyphicon-sort-by-alphabet').removeClass('glyphicon-sort-by-alphabet-alt');
        $("#ul_sort [name="+sortOpt[0]+"] a span").addClass('glyphicon-sort-by-alphabet');
      }
      $("#ul_sort [name="+sortOpt[0]+"] a span").css('color','#fff');
      $("#ul_sort li").removeClass('selectedSort');
      $("#ul_sort [name="+sortOpt[0]+"]").addClass('selectedSort');
      var srt=$.trim(strSelectedSort).split('_')[0];
      if(srt==='score')
      {
          $("#ul_sort [name="+sortOpt[0]+"]").attr('onClick','applySort("'+strSelectedSort+'","sort","'+srt+'")');
      }
      else
      {
          $("#ul_sort [name="+sortOpt[0]+"]").attr('onClick','applySort("'+strSelectedSort+'","customsort","'+arrSelectedProfileInfos[0].alias[srt]+'")');
      }
      if($.trim(action)==='customsort')
      {
        fnGetCustomSortItems(strSelectedProfileID,arrSelectedFilter,strSelectedSort,action);
      }
      else
      {
        __applySort(arrFilteredData,strSelectedProfileID,arrSelectedFilter,strSelectedSort,action)
      }
    }
}


function __applySort(retResult,profileId,filter,sortOpt,action)
{
    var sortval=$.trim(sortOpt).split('_');
    if($.trim(sortval[1])==='desc' && $.trim(action)!=='customsort')
    {
      retResult = retResult.sort(function(a, b)
      {
          return parseInt(a[sortval[0]]) - parseInt(b[sortval[0]]);
      });
      retResult.reverse();
      retResult=retResult.filter(function(n)
      {
          return (n.score!==undefined && n.score!==null && $.trim(n.score)!=='')
      });
    }
    else if($.trim(sortval[1])==='asc' && $.trim(action)!=='customsort')
    {
      retResult = retResult.sort(function(a, b)
      {
          return parseInt(a[sortval[0]]) - parseInt(b[sortval[0]]);
      });
      retResult=retResult.filter(function(n)
      {
        return (n.score!==undefined && n.score!==null && $.trim(n.score)!=='')
      });
    }
      arrNextPre=retResult;
    __applyPagging(retResult,profileId,filter,sortOpt,action);
}


function fnGetCustomSortItems(profileId,filter,sortOpt,action)
{
  var srt=$.trim(sortOpt).split('_')[0];
  var fieldName=arrSelectedProfileInfos[0].alias[srt];

  var objIds=[];
  for(var s=0;s<arrFilteredData.length;s++)
  {
    objIds.push(arrFilteredData[s].parent);
  }

  var arrQuery={'objIds':objIds,'dbName':arrSelectedProfileDetail[0].db_name,'PfName':arrSelectedProfileDetail[0].profile_name,'fieldName':fieldName,'sortOption':sortOpt};

  var req = new XMLHttpRequest();
  req.open('POST', '/_api/MstCustomSortItems');//?dbName='+res[0].db_name+'&dbPath=0&PfName='+res[0].profile_name+'&PfPath=0&fieldName='+fieldName+'&sortOption='+sortOpt);
  req.setRequestHeader('content-type', 'application/json');
  req.send(JSON.stringify(arrQuery));
  req.onload = function () 
  {
    var obj = JSON.parse(req.response);
    if(obj.length>0 && obj!==null)
    {
      var arrResult=[];
      if(arrFilteredData.length===0)
      {
        arrFilteredData=[];
      }
      for(var k=0;k<obj.length;k++)
      {
          var res=arrFilteredData.filter(function(el)
          {
            return $.trim(el.parent)===$.trim(obj[k]._id)
          })
          if(res.length>0)
          {
            arrResult.push(res[0]);
          }
      }
      if(arrResult.length>0)
      {
        $("#ul_filter").css('display','none');
        $("#ul_Fields").css('display','none');
      }

      //arrSelectedProfileData=[];
      //arrSelectedProfileData=arrResult;

      arrFilteredData=[];
      arrFilteredData=arrResult;

      arrNextPre=arrResult;

      //fnGetItems(profileId,filter,sortOpt,action);
      __applyPagging(arrFilteredData,profileId,filter,sortOpt,action);
    }
    else
    {
      $("#div_loader").hide();
      $("#txt___"+fieldName).val('');
      $("#div_Items").html('');
      $("#div_columns").html('');
      $("#divRight_Title h4").html('');
      $("#divRight_Title a").attr('href','#')
      $("#tblSignificance").html('');
      $("#spnRecordCount").html('(Records: 0)');
      __alertfy('alertfy_Info','record not found');
    }
  };
}


function applyFilter()
{
    iNextPre=0;
    $(".sortby span.glyphicon-remove").removeClass('activate')
    arrFilteredData=[];
    iScoreOrder=0;
    iTotalRecordCount=0;
    startLimit=0;
    endLimit=0;
    iSetCount=0;
    iCurrentSetNo=1;
    iSelectedItemNo=0;
    $("#div_loader").show();

    $("#ul_sort li").removeClass('selectedSort');
    $("#ul_sort li a span").removeClass('glyphicon-sort-by-alphabet').removeClass('glyphicon-sort-by-alphabet-alt');
    strSelectedSort="";

    $("#taRight_Comment").val('');
    $('#div_Items').animate({ scrollTop: 0 }, 'slow');
    //$("#ul_filter li").removeClass('selectedfilter');

    //$("#ul_filter").slideToggle();
    $("#ul_filter").hide();
    fnCancelGoTo();

    fnGetSelectedProfileData(strSelectedProfileID,arrSelectedFilter,strSelectedSort,'filter');
}


function fnGetSelectedProfileData(profileId,filter,sortOpt,action)
{
  if(action==='filter' || action==='customfilter')
  {
    startLimit=0;
    endLimit=0;
  }
  arrSelectedProfileData=[];
  var res=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(profileId)
  })
  if(res.length>0)
  {
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/MstSelectedProfileData?dbName='+res[0].profile_name+'&Path=0&action='+filter[0].filter);
    req.send();
    req.onload = function () 
    {
        var obj = JSON.parse(req.response);
        arrSelectedProfileData=obj;
        if($.trim(action)==='customfilter')
        {
          //fnGetCustomFilterItems(profileId,filter,sortOpt,action);
          fnGetItems(profileId,filter,sortOpt,action);
        }
        else if($.trim(action)==='customsort')
        {
          fnGetCustomSortItems(profileId,filter,sortOpt,action);
        }
        else
        {
          fnGetItems(profileId,filter,sortOpt,action);
        }
    };
  }
}

function fnGetCustomFilterItems(profileId,filter,sortOpt,action)
{
  var fieldName=filter;
  var fieldValue='';
  var iValidate=0;
  var res=arrSelectedProfileDetail;
  var chk=applyCalendar.filter(function(ee)
  {
    return $.trim(ee.FieldName)===$.trim(fieldName)
  });
  var isDate='No';
  if(chk.length>0)
  {
    isDate='Yes';

    var strStartDate=$.trim($("#txt_startDT___"+fieldName).val());
    var strEndDate=$.trim($("#txt_endDT___"+fieldName).val());

    if($.trim(strStartDate)==='')
    {
      iValidate=1;
      $("#txt_startDT___"+fieldName).css('border','1px solid red');
      //alert('Please enter start date for '+fieldName+'.');
      __alertfy('alertfy_error','Please enter start date for '+fieldName+'.');
    }
    else if($.trim(strEndDate)==='')
    {
      iValidate=1;
      $("#txt_startDT___"+fieldName).css('border','1px solid #ababab');
      $("#txt_endDT___"+fieldName).css('border','1px solid red');
      //alert('Please enter end date for '+fieldName+'.');
      __alertfy('alertfy_error','Please enter end date for '+fieldName+'.');
    }
    else
    {
      $("#txt_startDT___"+fieldName).css('border','1px solid #ababab');
      $("#txt_endDT___"+fieldName).css('border','1px solid #ababab');

      var dtStart=new Date(strStartDate);
      var dtEnd=new Date(strEndDate);

      var startDT=dtStart.getFullYear()+"-"+fnFormatedDate(dtStart.getMonth()+1)+"-"+fnFormatedDate(dtStart.getDate())+"T00:00:00.000Z";
      var endDT=dtEnd.getFullYear()+"-"+fnFormatedDate(dtEnd.getMonth()+1)+"-"+fnFormatedDate(dtEnd.getDate())+"T00:00:00.000Z";

      fieldValue = startDT+'___'+endDT;
    }
  }
  else
  {
    isDate='No';
    if($.trim($("#txt___"+fieldName).val())==='')
    {
      iValidate=1;
      $("#txt___"+fieldName).css('border','1px solid red');
      //alert('Please enter filter value for '+fieldName+'.');
      __alertfy('alertfy_error','Please enter filter value for '+fieldName+'.');
    }
    else
    {
      fieldValue=$("#txt___"+fieldName).val();
      fieldValue=$.trim(fieldValue).replace(/\s/g,'----').replace(/[&]/ig, "____");
      $("#txt___"+fieldName).css('border','1px solid #ababab');
    }
  }

  if(parseInt(iValidate)===0)
  {
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/MstCustomFilterItems?dbName='+res[0].db_name+'&Path=0&fieldName='+fieldName+'&fieldValue='+fieldValue+'&isDate='+isDate);
    req.send();
    req.onload = function () 
    {
      var obj = JSON.parse(req.response);
      if(obj.length>0)
      {
        var arrResult=[];
        for(var k=0;k<arrSelectedProfileData.length;k++)
        {
            var res=obj.filter(function(el)
            {
              return $.trim(el._id)===$.trim(arrSelectedProfileData[k].parent)
            })
            if(res.length>0)
            {
              arrResult.push(arrSelectedProfileData[k]);
            }
        }
        if(arrResult.length>0)
        {
          $("#ul_filter").css('display','none');
          $("#ul_Fields").css('display','none');
        }
        arrSelectedProfileData=[];
        arrSelectedProfileData=arrResult;
        fnGetItems(profileId,arrSelectedFilter,sortOpt,action);
      }
      else
      {
        $("#div_loader").hide();
        $("#div_Items").html('');
        $("#div_columns").html('');
        $("#divRight_Title h4").html('');
        $("#divRight_Title a").attr('href','#')
        $("#tblSignificance").html('');
        //alert('record not found');
        $("#spnRecordCount").html('(Records: 0)');
        __alertfy('alertfy_Info','record not found');
      }
    };
  }
  else
  {
    $("#div_loader").hide();
    //alert('Please fill filter value');
    __alertfy('alertfy_warning','Please fill filter value');
  }
}

function __applyfilter(resultArray,filter,rowcount,checkApply,sortOpt,action)
{
  if(filter[rowcount].isApply===true && rowcount<filter.length-1)
  {
    var criteria=[];
    for(var x=0;x<filter.length-1;x++)
    {
      if(filter[x].isApply===true)
      {
        var retResponse=criteria.filter(function(n)
        {
            return ($.trim(n.Field)===$.trim(filter[x].keyColumn))
        });
        if(retResponse.length>0)
        {
          var arrResponse=retResponse[0].Values;
          var resultret=arrResponse.filter(function(n)
          {
              return (n===filter[x].filter)
          });
          if(resultret.length===0)
          {
            if(filter[x].filter==='read')
            {
              retResponse[0].Values.push(function(val){return val!==null && val!==undefined && val!==''});
            }
            else if(filter[x].filter==='unread')
            {
              retResponse[0].Values.push(null);
              retResponse[0].Values.push("");
            }
            else
            {
              retResponse[0].Values.push(filter[x].filter);
            }
          }
        }
        else
        { 
            if(filter[x].filter==="allitems")
            {
              //criteria.push({ Field: filter[x].keyColumn, Values: ["allitems","relevant","not-relevant","",null] });
            }
            else if(filter[x].filter==="pending")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["",null] });
            }
            else if(filter[x].filter==="relevant")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["relevant"] });
            }
            else if(filter[x].filter==="not-relevant")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["not-relevant"] });
            }
            else if(filter[x].filter==="unread")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["",null] });
            }
            else if(filter[x].filter==="read")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: [function(val){return val!==null && val!==undefined && val!==''}] });
            }
            else if(filter[x].filter==="review")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["review","Review","REVIEW"] });
            }
            else if(filter[x].filter==="skip")
            {
              criteria.push({ Field: filter[x].keyColumn, Values: ["skip","Skip","SKIP"] });
            }
        }
        
      }
    }
    var filtered = resultArray.flexFilter(criteria);
    resultArray=filtered;
    rowcount=filter.length-1;
    __applyfilter(resultArray,filter,rowcount,checkApply,sortOpt,action);
  }
  else
  {
      if(rowcount===filter.length-1)
      {
        if(filter[filter.length-1].isApply)
        {
            var childnodes=filter[filter.length-1].childnode;
            if(childnodes.length>0)
            {
              var nodes=[];
              for(var k=0;k<childnodes.length;k++)
              {
                if(childnodes[k].isApply)
                {
                  if(childnodes[k].ctrlType==='date')
                  {
                    var strStartDate=$.trim($("#"+childnodes[k].primaryCtrlId).val());
                    var strEndDate=$.trim($("#"+childnodes[k].secondaryCtrlId).val());

                    if($.trim(strStartDate)!=='' && $.trim(strEndDate)!=='')
                    {
                        var dtStart=new Date(strStartDate);
                        var dtEnd=new Date(strEndDate);
    
                        var startDT=dtStart.getFullYear()+"-"+fnFormatedDate(dtStart.getMonth()+1)+"-"+fnFormatedDate(dtStart.getDate())+"T00:00:00.000Z";
                        var endDT=dtEnd.getFullYear()+"-"+fnFormatedDate(dtEnd.getMonth()+1)+"-"+fnFormatedDate(dtEnd.getDate())+"T00:00:00.000Z";
    
                        nodes.push({
                                    'fieldName':childnodes[k].FieldName,
                                    'ctrlType':'date',
                                    'startDT':startDT,
                                    'endDT':endDT
                                  });
                    }
                  }
                  else
                  {
                    var fieldValue=$("#"+childnodes[k].primaryCtrlId).val();
                    if($.trim(fieldValue)!=='')
                    {
                      fieldValue=$.trim(fieldValue).replace(/\s/g,'----').replace(/[&]/ig, "____");

                      nodes.push({
                        'fieldName':childnodes[k].FieldName,
                        'ctrlType':'text',
                        'value':fieldValue
                      });
                    }
                  }
                }
              }
              if(nodes.length>0)
              {
                  var objIds=[];
                  for(var s=0;s<resultArray.length;s++)
                  {
                    objIds.push(resultArray[s].parent);
                  }
                  var arrQuery={'objIds':objIds,'nodes':nodes,'db_name':arrSelectedProfileDetail[0].db_name};
                  var req = new XMLHttpRequest();
                  req.open('POST', '/_api/MstCustomFilterItems');
                  req.setRequestHeader('content-type', 'application/json');
                  req.send(JSON.stringify(arrQuery));

                  req.onload = function ()
                  {
                      var obj = JSON.parse(req.response);
                      if(obj.length>0)
                      {
                        var arrResult=[];
                        for(var k=0;k<arrSelectedProfileData.length;k++)
                        {
                            var res=obj.filter(function(el)
                            {
                              return $.trim(el._id)===$.trim(arrSelectedProfileData[k].parent)
                            })
                            if(res.length>0)
                            {
                              arrResult.push(arrSelectedProfileData[k]);
                            }
                        }
                        __applyAction(arrResult,sortOpt,action);
                      }
                      else
                      {
                          resultArray=[];
                        __applyAction(resultArray,sortOpt,action);
                      }
                  }
              }
              else
              {
                __applyAction(resultArray,sortOpt,action);
              }
            }
            else
            {
              __applyAction(resultArray,sortOpt,action);
            }
        }
        else
        {
          __applyAction(resultArray,sortOpt,action);
        }
      }
      else
      {
        rowcount++;
        __applyfilter(resultArray,filter,rowcount,checkApply,sortOpt,action);
      }
  }
}

function fnGetItems(profileId,filter,sortOpt,action)
{
  $("#div_loader").show();
  $("#div_ProfileWrapper .profilecontent").removeClass('active');
  $("#"+profileId).addClass('active');
  
  var retResult=[];
  var res=arrSelectedProfileDetail;
  var chkApplyFilter=false;
  for(var m=0;m<arrSelectedFilter.length;m++)
  {
    if(arrSelectedFilter[m].isApply)
      chkApplyFilter=true;
  }

  if(!chkApplyFilter)
  {
    $("#div_loader").hide();
    //alert('Kindly apply atleast one filter');
    __alertfy('alertfy_Info','Kindly apply atleast one filter');
  }
  else
  {
        if(chkApplyFilter===true && arrFilteredData.length===0 && ($.trim(action)==='filter' || $.trim(action)==='customfilter'))
        {
          arrFilteredData=arrSelectedProfileData;
        }
      
        if(iNextPre===0)
        {
            arrNextPre=[];
            
            __applyfilter(arrFilteredData,filter,0,false,sortOpt,action);
            
        }
        else
        {
          retResult=arrNextPre;

          __applyPagging(retResult,profileId,filter,sortOpt,action);

        }
  }
}

function __applyAction(retResult,sortOpt,action)
{
  if(retResult.length>0)
  {
      if($.trim(action)==='filter' || $.trim(action)==='customfilter')
      {
        arrFilteredData=retResult;
      }
      else
      {
        retResult=arrFilteredData;
      }
      
      //retResult=__applySort(retResult,strSelectedProfileID,arrSelectedFilter,sortOpt,action);

      arrNextPre=retResult;

      __applyPagging(retResult,strSelectedProfileID,arrSelectedFilter,sortOpt,action);
  }
  else
  {
      $("#div_loader").hide();
      $("#div_Items").html('');
      $("#div_columns").html('');
      $("#divRight_Title h4").html('');
      $("#divRight_Title a").attr('href','#')
      $("#tblSignificance").html('');
      //alert('record not found');
      $("#spnRecordCount").html('(Records: 0)');
      __alertfy('alertfy_Info','record not found');
  }
}



function __applyPagging(retResult,profileId,filter,sortOpt,action)
{
  var inId='';
  if(retResult.length>0)
  {
    iSetCount=Math.ceil(retResult.length/perPageDataLimit);
    if(iSetCount>0)
    {
      if(action==='GoTo' || action==='sort')
      {
        //startLimit=startLimit+1;
        //endLimit=endLimit+1;
      }
      else if(iCurrentSetNo<=1)
      {
        startLimit=1;
        if(retResult.length<perPageDataLimit)
        {
          endLimit=retResult.length;
        }
        else
        {
          endLimit=perPageDataLimit;
        }
      }
      else if(iCurrentSetNo<iSetCount)
      {
        if(iNextPre===1)
        {
          startLimit=endLimit+1;
          endLimit=(startLimit+perPageDataLimit)-1;
          if(endLimit>retResult.length)
          {
            endLimit=retResult.length;
          }
        }
        else
        {
          startLimit=(startLimit-perPageDataLimit);
          endLimit=endLimit-perPageDataLimit;
        }
      }
      else if(iSetCount<iCurrentSetNo)
      {
        iCurrentSetNo=iCurrentSetNo-1;
      }
      else
      {
        startLimit=(perPageDataLimit*iCurrentSetNo)+1;
        if(startLimit>retResult.length)
        {
          startLimit=startLimit-perPageDataLimit;
          endLimit=retResult.length;
        }
        else
        {
          endLimit=retResult.length;
        }
      }

      for(var k=startLimit-1;k<endLimit;k++)
      {
        if($.trim(inId)==='')
          inId=retResult[k].parent;
        else
        {
          inId=inId+','+retResult[k].parent;
        }
      }
      iSelectedItemNo=startLimit-1;
      $("#div_pagination").css('display','');
      $("#btnNextRecord").css('display','');
      $("#btnPreviousRecord").css('display','');
      var recordSet='<span id="spn_SelectedItemNo"></span> / ['+startLimit+" - "+endLimit+"]";
      $("#lblRecordSet").html(recordSet);
      
      iTotalRecordCount=retResult.length;
      var strHTML='';
      var req = new XMLHttpRequest();
      req.open('GET', '/_api/MstItems?dbName='+arrSelectedProfileDetail[0].db_name+'&Path=0&inId='+inId);
      req.send();
      req.onload = function () 
      {
        var obj = JSON.parse(req.response);
        arrSourceData=obj;
        if(iPageLoad===0)
        {
          iPageLoad=1;
          fnBindLeftPanel(retResult);
        }
        else
        {
          fnBindMiddlePanel(retResult,action);
        }
      };
    }
    else
    {
      $("#div_loader").hide();
      $("#div_Items").html('');
      $("#div_columns").html('');
      $("#divRight_Title h4").html('');
      $("#divRight_Title a").attr('href','#')
      $("#tblSignificance").html('');
      //alert('record not found');
      $("#spnRecordCount").html('(Records: 0)');
      __alertfy('alertfy_Info','record not found');
    }
  }
  else
  {
    inId='';
    $("#div_loader").hide();
    $("#div_Items").html('');
    $("#div_columns").html('');
    $("#divRight_Title h4").html('');
    $("#divRight_Title a").attr('href','#')
    $("#tblSignificance").html('');
    //alert('record not found');
    $("#spnRecordCount").html('(Records: 0)');
    __alertfy('alertfy_Info','record not found');
  }
}

function fnShowNextDataSet()
{
  iCurrentSetNo=iCurrentSetNo+1;
  iNextPre=1;
  $('#div_Items').animate({ scrollTop: 0 }, 'slow');
  fnCancelGoTo();
  fnGetItems(strSelectedProfileID,arrSelectedFilter,strSelectedSort,'Next');
}
function fnShowPreviousDataSet()
{
  iCurrentSetNo=iCurrentSetNo-1;
  if(iCurrentSetNo<=0)
  {
    iCurrentSetNo=1;
  }
  iNextPre=2;
  $('#div_Items').animate({ scrollTop: 0 }, 'slow');
  fnCancelGoTo();
  fnGetItems(strSelectedProfileID,arrSelectedFilter,strSelectedSort,'Previous');
}



function fnBindLeftPanel(retResult)
{
    var strHTML='';
    $("#div_ProfileWrapper").html('');
    /*  Left section html binding   */
    $("#spn_TotalNoOfProfiles").html('Total: '+arrAllProfiles.length);
    $("#div_ProfileWrapper").html('');
    arrChildNode=[];
    for(var c=0;c<arrAllProfiles.length;c++)
    {
      if(arrAllProfiles[c].type!==undefined)
      {
        if($.trim(arrAllProfiles[c].type)==='group')
        {
          for(var m=0;m<arrAllProfiles[c].childnode.length;m++)
          {
            arrChildNode.push({'childnode':$.trim(arrAllProfiles[c].childnode[m].node),'parentnode':$.trim(arrAllProfiles[c]._id)});
          }
        }
      }
    }
    for(var i=0;i<arrAllProfiles.length;i++)
    {
      if(arrAllProfiles[i].type!==undefined)
      {
        if($.trim(arrAllProfiles[i].type)==='group')
        {
            strHTML=strHTML+'<div class="profile_group">';
            strHTML=strHTML+_getProfile(arrAllProfiles[i],arrAllProfiles[i].type);

            var cnode=arrAllProfiles[i].childnode;
            if(cnode.length>0)
            {
              strHTML=strHTML+'<div class="profiletoggles">';
              for(var t=0;t<cnode.length;t++)
              {
                var retResults=arrAllProfiles.filter(function(el)
                {
                  return $.trim(el._id)===$.trim(cnode[t].node)
                })
                if(retResults.length>0)
                {
                  strHTML=strHTML+_getProfile(retResults[0],'profile');
                }
              }
              strHTML=strHTML+'</div>';
            }
            strHTML=strHTML+'</div>';
            $("#div_ProfileWrapper").append(strHTML);
            strHTML='';
        }
        else
        {
          var retPro=arrChildNode.filter(function(el)
          {
            return $.trim(el.childnode)===$.trim(arrAllProfiles[i]._id)
          })
          if(retPro.length===0)
          {
            strHTML=_getProfile(arrAllProfiles[i],arrAllProfiles[i].type);
            $("#div_ProfileWrapper").append(strHTML);
            strHTML='';
          }
        }
      }
      else if($.trim(arrAllProfiles[i].type)==='profile')
      {
          var retPro=arrChildNode.filter(function(el)
          {
            return $.trim(el.childnode)===$.trim(arrAllProfiles[i]._id)
          })
          if(retPro.length===0)
          {
            strHTML=_getProfile(arrAllProfiles[i],arrAllProfiles[i].type);
            $("#div_ProfileWrapper").append(strHTML);
            strHTML='';
          }
      }
    }
    $('.profile_group .profilecontent .grp').click(function()
    {
      $($(this).parent().siblings()).slideToggle();
      $(this).parent().toggleClass('activegroup');
    });
    $(".ProfileName").keyup(function () {
        var textValue = $(this).val();
        textValue =textValue.replace(/ /g,"_");
        $(this).val(textValue);
    });
    
    var chld=arrChildNode.filter(function(el)
    {
      return $.trim(el.childnode)===$.trim(strSelectedProfileID)
    })
    if(chld.length>0)
    {
      $($("#"+chld[0].parentnode).siblings()).show();
      $("#"+chld[0].parentnode).toggleClass('activegroup');
    }

    $('#div_ProfileWrapper').scroll(function(){$("#div_profileNavigation").hide();$("#spninformation").hide();});
    $('.profiledetails').hover(function(){$("#div_profileNavigation").hide();$("#spninformation").hide();});
    $('.descriptiondetail').hover(function(){$("#div_profileNavigation").hide();$("#spninformation").hide();});
    $('.diffclr').hover(function(){$("#div_profileNavigation").hide();$("#spninformation").hide();});
    $('.pdr3').hover(function(){$("#div_profileNavigation").hide();$("#spninformation").hide();});
    
    fnBindMiddlePanel(retResult,'');
}



function _getProfile(arrAllProfiles,type)
{
    var strProfileHTML='';

    if($.trim(strSelectedProfileID)==='')
    strProfileHTML=strProfileHTML+'<div class="profilecontent active" id='+arrAllProfiles._id+' >';
    else
    {
      if($.trim(strSelectedProfileID)===$.trim(arrAllProfiles._id))
      {
        strProfileHTML=strProfileHTML+'<div class="profilecontent active" id='+arrAllProfiles._id+' >';
      }
      else
      {
        strProfileHTML=strProfileHTML+'<div class="profilecontent" id='+arrAllProfiles._id+' >';
      }
    }
    if(type==='group')
      strProfileHTML=strProfileHTML+'<span class="diffclr grp"><i class="fa fa-folder profilegroup"></i> '+arrAllProfiles.profile_name+' <i class="fa fa-caret-right groupForwardArrow"></i></span>';
    else
      strProfileHTML=strProfileHTML+'<span class="diffclr" onclick=\'fnGetSelectedProfileInfos("'+arrAllProfiles._id+'");\'>'+arrAllProfiles.profile_name+'</span>';

    strProfileHTML=strProfileHTML+'<div class="edwnldicons">';
    /*
    if(arrAllProfiles.total_record_count!==undefined && arrAllProfiles.total_record_count!==null && arrAllProfiles.total_record_count!=="")
    {
      if(type==='group')
          strProfileHTML=strProfileHTML+'<span class="clr-violet pdr3" id="spn_TotalNoOfRecords_'+arrAllProfiles._id+'">'+arrAllProfiles.total_record_count+' profiles</span>';
      else
          strProfileHTML=strProfileHTML+'<span class="clr-violet pdr3" id="spn_TotalNoOfRecords_'+arrAllProfiles._id+'">'+arrAllProfiles.total_record_count+' records</span>';
    }
    else
    {
      if(type==='group')
        strProfileHTML=strProfileHTML+'<span class="clr-violet pdr3" id="spn_TotalNoOfRecords_'+arrAllProfiles._id+'">0 profiles</span>';
      else
        strProfileHTML=strProfileHTML+'<span class="clr-violet pdr3" id="spn_TotalNoOfRecords_'+arrAllProfiles._id+'">0 records</span>';
    }
    */
    if(type==='group')
    {
        strProfileHTML=strProfileHTML+'<span class="profileicons">';
        strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" onmouseover=\'__hideInfotooltip()\' onclick=\'_RefreshProfiles("updategroup","'+arrAllProfiles._id+'");\' class="fa" aria-hidden="true">&#xf044;</i></span>';
        strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" onclick=\'__showProfileInfo(event,"spninformation",this,"'+arrAllProfiles._id+'","'+type+'")\' id="spninfo_'+arrAllProfiles._id+'" class="fa fa-info-circle spninfo" aria-hidden="true"></i></span>';
        //strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" id='+arrAllProfiles._id+' class="fa fa-ellipsis-v" onmouseover=\'fnProfileNavigationInfo(event,"div_profileNavigation",this,"'+type+'")\' aria-hidden="true"></i>';
        /*strProfileHTML=strProfileHTML+'<span class="fa fa-trash" style="display:none;" onclick=\'fnDeleteGroup(this,"'+arrAllProfiles._id+'",event);\'></span>';*/
        strProfileHTML=strProfileHTML+'</span>';
        strProfileHTML=strProfileHTML+'</span>';
    }
    else
    {
      strProfileHTML=strProfileHTML+'<span class="profileicons">';
      strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" onmouseover=\'__hideInfotooltip()\' onclick=\'fnEditProfile(this,"'+arrAllProfiles._id+'",event);\' class="fa" aria-hidden="true">&#xf044;</i></span>';
      strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" id="spninfo_'+arrAllProfiles._id+'" onclick=\'__showProfileInfo(event,"spninformation",this,"'+arrAllProfiles._id+'","'+type+'")\' class="fa fa-info-circle spninfo" aria-hidden="true"></i></span>';
      strProfileHTML=strProfileHTML+'<span><i style="font-size:16px;" id='+arrAllProfiles._id+' class="fa fa-ellipsis-v" onmouseover=\'fnProfileNavigationInfo(event,"div_profileNavigation",this,"'+type+'")\' aria-hidden="true"></i>';
      strProfileHTML=strProfileHTML+'</span>';
      strProfileHTML=strProfileHTML+'</span>';
    }
    
    
    strProfileHTML=strProfileHTML+'</div>';
    strProfileHTML=strProfileHTML+'</div>';

    return strProfileHTML;
}

function __hideInfotooltip()
{
  $("#spninformation").hide();
  $("#div_profileNavigation").hide();
}

function __showProfileInfo(e,divid,ctrl,proid,type)
{
    $("#spninformation").hide();
    var res=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(proid)
    })
       
    var xHTML='';

    xHTML=xHTML+'<table class="table">';

    xHTML=xHTML+'<thead class="thead-light">';
    xHTML=xHTML+'<tr><th colspan="3">Profile info</th></tr>';
    xHTML=xHTML+'</thead>';

    xHTML=xHTML+'<tbody>';
    if(res[0].total_record_count!==undefined && res[0].total_record_count!==null && res[0].total_record_count!=="")
    {
        if(type==='group')
        {
          xHTML=xHTML+'<tr><td>Total profiles</td><td>:</td><td>'+res[0].total_record_count+' profiles</td></tr>';
        }
        else
        {
          xHTML=xHTML+'<tr><td>Total records</td><td>:</td><td>'+res[0].total_record_count+' records</td></tr>';
        }
    }
    else
    {
        if(type==='group')
        {
          xHTML=xHTML+'<tr><td>Total profiles</td><td>:</td><td>0 profiles</td></tr>';
        }
        else
        {
          xHTML=xHTML+'<tr><td>Total records</td><td>:</td><td>0 records</td></tr>';
        }
    }
    
    if(res[0].createdby!==undefined && res[0].createdby!==null)
      xHTML=xHTML+'<tr><td>Created by</td><td>:</td><td>'+res[0].createdby+'</td></tr>';
    else
      xHTML=xHTML+'<tr><td>Created by</td><td>:</td><td>N/A</td></tr>';

    if(res[0].created!==undefined && res[0].created!==null)
      xHTML=xHTML+'<tr><td>Created date</td><td>:</td><td>'+makeFormatedDate(res[0].created)+'</td></tr>';
    else
      xHTML=xHTML+'<tr><td>Created date</td><td>:</td><td>N/A</td></tr>';

    if(res[0].modifiedby!==undefined && res[0].modifiedby!==null)
      xHTML=xHTML+'<tr><td>Last modified by</td><td>:</td><td>'+res[0].modifiedby+'</td></tr>';
    else
      xHTML=xHTML+'<tr><td>Last modified by</td><td>:</td><td>N/A</td></tr>';

    if(res[0].modified!==undefined && res[0].modified!==null)
      xHTML=xHTML+'<tr><td>modified date</td><td>:</td><td>'+makeFormatedDate(res[0].modified)+'</td></tr>';
    else
      xHTML=xHTML+'<tr><td>modified date</td><td>:</td><td>N/A</td></tr>';

    xHTML=xHTML+'</tbody>';

    xHTML=xHTML+'</table>';

    $("#div_profileNavigation").hide();
    
    var left  = e.clientX+20  + "px";
    var top  = e.clientY-120  + "px";

    $("#"+divid).html('');
    $("#"+divid).html(xHTML);
    xHTML='';

    var div = document.getElementById(divid);

    div.style.left = left;
    div.style.top = top;

    $("#"+divid).toggle();
    //return false;
}


function fnProfileNavigationInfo(e,divid,ctrl,type)
{
  $("#div_profileNavigation").hide();
  $("#spninformation").hide();
  var profileID=$(ctrl).attr('id');
  var xHTML='';
  var left;
  var top;

  xHTML=xHTML+'<ul>';
  if(type==='group')
  {
    left  = e.clientX-190  + "px";
    top  = e.clientY-10  + "px";

    //xHTML=xHTML+'<li><a href="javascript:void(0);" onclick=\'_RefreshProfiles("updategroup","'+profileID+'");\'><i  class=\'fa\'>&#xf044;</i> Edit profile</a></li>';      
  }
  else
  {
    left  = e.clientX+5  + "px";
    top  = e.clientY+7  + "px";

    //xHTML=xHTML+'<li><a href="javascript:void(0);" onclick=\'fnEditProfile(this,"'+profileID+'",event);\'><i  class=\'fa\'>&#xf044;</i> Edit profile</a></li>';
    
    xHTML=xHTML+'<li><a href="javascript:void(0);" onclick=\'fnDownload("'+profileID+'",event);\'><i class="fa fa-download" aria-hidden="true"></i> download all documents</a></li>';
    xHTML=xHTML+'<li><a href="javascript:void(0);" onclick=\'return fnCustomExcelExport("'+profileID+'");\'><i class="fa fa-download" aria-hidden="true"></i> Custom Download</a></li>';
    xHTML=xHTML+'<li><a href="javascript:void(0);" onclick=\'fnDeleteProfile(this,"'+profileID+'",event);\'><i class="fa fa-trash" aria-hidden="true"></i> Delete</a></li>';      
  }
 
  xHTML=xHTML+'</ul>';

  $("#"+divid).html('');
  $("#"+divid).html(xHTML);
  xHTML='';

  var div = document.getElementById(divid);

  div.style.left = left;
  div.style.top = top;

  $("#"+divid).toggle();
  return false;
}

function fnCustomExcelExport(proid)
{
  var xHTML='';
  var arrCommonDefaultFilter=[];
  var arrActionFilterColumn=[];
  var arrBucketColumn=[];

  var req = new XMLHttpRequest();
  req.open('GET', '/_api/getProfileInfo/'+proid+'');
  req.send();
  req.onload = function () 
  {
    var obj = JSON.parse(req.response);
      
  

    $("#btnCustomExcelExport").attr('onclick','return __exportToExcel("'+proid+'");')

    arrCommonDefaultFilter.push({'name':'pending','value':'Pending'});
    arrCommonDefaultFilter.push({'name':'relevant','value':'Relevant'});
    arrCommonDefaultFilter.push({'name':'not-relevant','value':'Non-Relevant'});
    arrCommonDefaultFilter.push({'name':'unread','value':'Unread'});
    arrCommonDefaultFilter.push({'name':'read','value':'Read'});
    arrCommonDefaultFilter.push({'name':'review','value':'Review'});
    arrCommonDefaultFilter.push({'name':'skip','value':'Skip'});

    //arrActionFilterColumn.push({'name':'useraction','value':'User action'});
    arrActionFilterColumn.push({'name':'score','value':'Score'});
    //arrActionFilterColumn.push({'name':'score_result','value':'Action result'});
    //arrActionFilterColumn.push({'name':'modified','value':'Action date'});
    arrActionFilterColumn.push({'name':'comment','value':'Comment'});

    if(obj.bucket!=undefined)
    {
        if(obj.bucket.length>0)
        {
            for(var l=0;l<obj.bucket.length;l++)
            {
                keyname=obj.bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                arrBucketColumn.push({ 'name': keyname,'value':keyname });
            }
        }
    }

    for(var c=0;c<arrCommonDefaultFilter.length;c++)
    {
        xHTML=xHTML+'<li>';
        xHTML=xHTML+'<input class="styled-checkbox" id="chk___filters___'+arrCommonDefaultFilter[c].name+'" onchange="return __checkProperty(this.id);" type="checkbox" value="">';
        xHTML=xHTML+'<label for="chk___filters___'+arrCommonDefaultFilter[c].name+'">'+arrCommonDefaultFilter[c].value+'</label>';
        xHTML=xHTML+'</li>';
    }

    $("#ul_dbFilters").html('');
    $("#ul_dbFilters").html(xHTML);
    xHTML='';

    if(obj.fields.length>0)
    {
      for(var m=0;m<obj.fields.length;m++)
      {
          if($.trim(obj.fields[m].name)!=='')
          {
            var flName=$.trim(obj.fields[m].name);
            if($.trim(flName)!=="_id" && $.trim(flName)!=="__EMPTY" && $.trim(flName)!=="Unnamed__0" && $.trim(flName)!=="0" && $.trim(flName)!=="Unnamed: 0" && $.trim(flName)!=="")
            {
              xHTML=xHTML+'<li>';
              xHTML=xHTML+'<input class="styled-checkbox" id="chk___columns___'+flName+'" onchange="return __checkProperty(this.id);" type="checkbox" value="">';
              xHTML=xHTML+'<label for="chk___columns___'+flName+'">'+flName+'</label>';
              xHTML=xHTML+'</li>';
            }
          }
      }
      $("#ul_dbColumns").html('');
      $("#ul_dbColumns").html(xHTML);
      xHTML='';
    }

    for(var n=0;n<arrActionFilterColumn.length;n++)
    {
        xHTML=xHTML+'<li>';
        xHTML=xHTML+'<input class="styled-checkbox" id="chk___useraction___'+arrActionFilterColumn[n].name+'" onchange="return __checkProperty(this.id);" type="checkbox" value="">';
        xHTML=xHTML+'<label for="chk___useraction___'+arrActionFilterColumn[n].name+'">'+arrActionFilterColumn[n].value+'</label>';
        xHTML=xHTML+'</li>';
    }

    $("#ul_dbUserAction").html('');
    $("#ul_dbUserAction").html(xHTML);
    xHTML='';


    for(var u=0;u<arrBucketColumn.length;u++)
    {
      xHTML=xHTML+'<li>';
      xHTML=xHTML+'<input class="styled-checkbox" id="chk___bucket___'+arrBucketColumn[u].name+'" onchange="return __checkProperty(this.id);" type="checkbox" value="">';
      xHTML=xHTML+'<label for="chk___bucket___'+arrBucketColumn[u].name+'">'+arrBucketColumn[u].value+'</label>';
      xHTML=xHTML+'</li>';
    }

    $("#ul_dbBucket").html('');
    $("#ul_dbBucket").html(xHTML);
    xHTML='';


    $("#chk_filter_all").change(function()
    {
        if($(this).prop('checked'))
        {
          for(var c=0;c<arrCommonDefaultFilter.length;c++)
          {
              $("#chk___filters___"+arrCommonDefaultFilter[c].name).prop('checked',true);
          }
        }
        else
        {
          for(var c=0;c<arrCommonDefaultFilter.length;c++)
          {
              $("#chk___filters___"+arrCommonDefaultFilter[c].name).prop('checked',false);
          }
        }
        $('#ul_dbFilters').animate({ scrollTop: 0 }, 'slow');
    })


    $("#chk_useraction_all").change(function()
    {
        if($(this).prop('checked'))
        {
          for(var n=0;n<arrActionFilterColumn.length;n++)
          {
              $("#chk___useraction___"+arrActionFilterColumn[n].name).prop('checked',true);
          }
        }
        else
        {
          for(var n=0;n<arrActionFilterColumn.length;n++)
          {
              $("#chk___useraction___"+arrActionFilterColumn[n].name).prop('checked',false);
          }
        }
        $('#ul_dbUserAction').animate({ scrollTop: 0 }, 'slow');
    })


    $("#chk_bucket_all").change(function()
    {
        if($(this).prop('checked'))
        {
          for(var u=0;u<arrBucketColumn.length;u++)
          {
              $("#chk___bucket___"+arrBucketColumn[u].name).prop('checked',true);
          }
        }
        else
        {
          for(var u=0;u<arrBucketColumn.length;u++)
          {
              $("#chk___bucket___"+arrBucketColumn[u].name).prop('checked',false);
          }
        }
        $('#ul_dbBucket').animate({ scrollTop: 0 }, 'slow');
    })


    $("#chk_columns_all").change(function()
    {
        if($(this).prop('checked'))
        {
            for(var c=0;c<obj.fields.length;c++)
            {
              var flName=$.trim(obj.fields[c].name);
              if($.trim(flName)!=="_id" && $.trim(flName)!=="__EMPTY" && $.trim(flName)!=="Unnamed__0" && $.trim(flName)!=="0" && $.trim(flName)!=="Unnamed: 0" && $.trim(flName)!=="")
              {
                $("#chk___columns___"+flName).prop('checked',true);
              }
            }
        }
        else
        {
            for(var c=0;c<obj.fields.length;c++)
            {
              var flName=$.trim(obj.fields[c].name);
              if($.trim(flName)!=="_id" && $.trim(flName)!=="__EMPTY" && $.trim(flName)!=="Unnamed__0" && $.trim(flName)!=="0" && $.trim(flName)!=="Unnamed: 0" && $.trim(flName)!=="")
              {
                $("#chk___columns___"+flName).prop('checked',false);
              }
            }
        }
        $('#ul_dbColumns').animate({ scrollTop: 0 }, 'slow');
    })
    $("#CustomExcelExport").show();
    $("#chk_filter_all").prop('checked',false);
    $("#chk_columns_all").prop('checked',false);
    $("#chk_useraction_all").prop('checked',false);
    $("#chk_bucket_all").prop('checked',false);
};
}


$(".CloseCustomExportExcelPopup").click(function()
{
  $("#CustomExcelExport").hide();
})

function __checkProperty(id)
{
    if(!$("#"+id).prop('checked'))
    {
        var splitid=id.split('___')[1];
        if(splitid==='filters')
        {
          $("#chk_filter_all").prop('checked',false);
        }
        else if(splitid==='columns')
        {
          $("#chk_columns_all").prop('checked',false);
        }
        else if(splitid==='useraction')
        {
          $("#chk_useraction_all").prop('checked',false);
        }
        else if(splitid==='bucket')
        {
          $("#chk_bucket_all").prop('checked',false);
        }
    }
}

function __exportToExcel(profileid)
{
    var appliedFilters=[];
    var checkedColumns=[];
    var checkedUserAction=[];
    var checkedBuckets=[];
    var arrCombineCols=[];
    var iValidate=0;
    if($('#ul_dbFilters input:checked').length>0)
    {
        for(var t=0;t<$('#ul_dbFilters input:checked').length;t++)
        {
            var colname=$.trim($($('#ul_dbFilters input:checked')[t]).attr('id').split('___')[2]);
            appliedFilters.push({'Column':colname});
        }
    }
    else
    {
      __alertfy('alertfy_error','Kindly select atleast one filter from left panel');
      iValidate=1;
    }
    if($('#ul_dbColumns input:checked').length>0)
    {
        for(var m=0;m<$('#ul_dbColumns input:checked').length;m++)
        {
            var colname=$.trim($($('#ul_dbColumns input:checked')[m]).attr('id').split('___')[2]);
            checkedColumns.push({'Column':colname});
        }
    }
    else
    {
      __alertfy('alertfy_error','Kindly select atleast one column from right panel');
      iValidate=1;
    }

    if($('#ul_dbUserAction input:checked').length>0)
    {
        for(var t=0;t<$('#ul_dbUserAction input:checked').length;t++)
        {
            var colname=$.trim($($('#ul_dbUserAction input:checked')[t]).attr('id').split('___')[2]);
            checkedUserAction.push({'Column':colname});
        }
    }

    if($('#ul_dbBucket input:checked').length>0)
    {
        for(var t=0;t<$('#ul_dbBucket input:checked').length;t++)
        {
            var colname=$.trim($($('#ul_dbBucket input:checked')[t]).attr('id').split('___')[2]);
            checkedBuckets.push({'Column':colname});
        }
    }

    if(iValidate===0)
    {
        arrCombineCols.push({'appliedFilter':appliedFilters,'appliedColumns':checkedColumns,'appliedUserAction':checkedUserAction,'appliedBuckets':checkedBuckets});
        var res=arrAllProfiles.filter(function(el)
        {
          return $.trim(el._id)===$.trim(profileid)
        })
        if(res.length>0)
        {
            $("#CustomExcelExport").hide();
            var totalrecordcount=res[0].total_record_count;
            var page=Math.ceil(parseInt(totalrecordcount)/500);
            var perPage=500;
            var strdata=JSON.stringify(arrCombineCols);
            window.open('/_api/ExcelExport_exceljs/'+res[0].profile_name.replace(/[^A-Z0-9]+/ig, "_")+'.xlsx/'+page+'/'+perPage+'/'+strdata+'?SourceDBName='+res[0].db_name+'&SourceDBPath=0&ProfileDBName='+res[0].profile_name+'&ProfileDBPath=0')
        }
    }
}


function fnBindMiddlePanel(retResult,action)
{
    nxtItemID='';
    preItemID='';
    var strHTML='';
    arrFiltered=[];
    arrCreatedItems=[];
    $("#div_Items").html('');

    $(".sortby span.glyphicon-filter").removeClass('activate')
    if($("#ul_filter li.selectedfilter").length>0)
    {
      $(".sortby span.glyphicon-filter").addClass('activate')
    }

    $(".sortby span.glyphicon-sort").removeClass('activate')
    if($("#ul_sort li.selectedSort").length>0)
    {
      $(".sortby span.glyphicon-sort").addClass('activate')
    }
   
    /*  middle section html binding   */
    var retPro=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(strSelectedProfileID)
    })
    var dbAlias=selectedDBAlias;
    //var retResult=[];
    //retResult=retResult;
    arrFiltered=retResult;

    $("#spn_itemsInfo").html('<i class="fa fa-bars" aria-hidden="true"></i> '+retPro[0].profile_name+' <br /><span style="font-size:12px;" id="spnRecordCount">(Records: '+retResult.length+')</span>');
    //iTotalRecordCount=retResult.length;
    if(retResult.length>0)
    {
      for(var k=0;k<retResult.length;k++)
      {
        var ret=arrSourceData.filter(function(em)
        {
          return $.trim(em._id)===$.trim(retResult[k].parent)
        })
        if(ret.length>0)
        {
          iSelectedItemNo=iSelectedItemNo+1;
          arrCreatedItems.push(retResult[k]);
          if(k===0)
          {
            if($.trim(retResult[k].modified)==='' || retResult[k].modified===null)
            {
              if($.trim(retResult[k].useraction)==='relevant')
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent relevant profilecontent_unread_bold selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
              else if($.trim(retResult[k].useraction)==='not-relevant')
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent nonrelevant profilecontent_unread_bold selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
              else
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent profilecontent_unread_bold selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
            }
            else
            {
              if($.trim(retResult[k].useraction)==='relevant')
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent relevant selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
              else if($.trim(retResult[k].useraction)==='not-relevant')
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent nonrelevant selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
              else
                  strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent selected" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
            }
          }
          else if($.trim(retResult[k].modified)==='' || retResult[k].modified===null)
          {
            if($.trim(retResult[k].useraction)==='relevant')
                strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent profilecontent_unread_bold relevant" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
            else if($.trim(retResult[k].useraction)==='not-relevant')
                strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent profilecontent_unread_bold nonrelevant" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
            else
                strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent profilecontent_unread_bold" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';

          }
          else if($.trim(retResult[k].useraction)==='relevant')
            strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent relevant" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
          else if($.trim(retResult[k].useraction)==='not-relevant')
            strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent nonrelevant" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';
          else if($.trim(retResult[k].useraction)==='' && $.trim(retResult[k].modified)!=='')
            strHTML=strHTML+'<div name='+iSelectedItemNo+' class="profilecontent" id="item_'+retResult[k].parent+'" onclick=\'return fnBindRightPanel(this.id,"'+retResult[k].parent+'",1,"MouseClick");\'>';


          strHTML=strHTML+'<div class="diffclr custpd">'+ret[0][dbAlias.Title]+'</div>';
          if(ret[0][dbAlias.Description]!==null && ret[0][dbAlias.Description]!==undefined)
          {
             if($.trim(ret[0][dbAlias.Description]).length<=99)
            {
              strHTML=strHTML+'<p>'+ret[0][dbAlias.Description]+'</p>';
            }
            else
            {
              strHTML=strHTML+'<p>'+ret[0][dbAlias.Description].substring(0, 99)+'...</p>';
            }
          }
          else
          {
            strHTML=strHTML+'<p>&nbsp;</p>';
          }
          strHTML=strHTML+'<div>';
          strHTML=strHTML+'<span class="text-success">'+dbAlias.Date.toUpperCase().replace(/[^a-zA-Z0-9]/ig, " ").replace(/  +/g, ' ')+': </span><span class="text-muted date">'+makeFormatedDate(ret[0][dbAlias.Date])+'</span>';
          strHTML=strHTML+'<span class="text-success patentno">'+dbAlias.ID.toUpperCase().replace(/[^a-zA-Z0-9]/ig, " ").replace(/  +/g, ' ')+'.</span><span class="text-muted"> '+ret[0][dbAlias.ID]+'</span>';
          strHTML=strHTML+'<span class="dot-section"><a href="javascript:void(0);" class="dots"><div class="dot"></div></a><div class="listOption"><ul><li id="li_markread_'+retResult[k].parent+'" onclick=\'return lastSeen("'+retResult[k].parent+'","N","T")\'>Mark unread</li></ul></div></span>';
          strHTML=strHTML+'</div>';
          strHTML=strHTML+'<span class="review grn-clr"></span>';

          
          
          if($.trim(retResult[k].useraction)==='relevant')
          {
            strHTML=strHTML+'<button type="button" id="btn_rel_'+retResult[k].parent+'" class="btn relevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick fa fa-check"></i> Relevant</button>';
            strHTML=strHTML+'<button type="button" id="btn_notrel_'+retResult[k].parent+'" class="btn nonrelevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","not-relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick"></i> Non-Relevant</button>';
          }
          else if($.trim(retResult[k].useraction)==='not-relevant')
          {
            strHTML=strHTML+'<button type="button" id="btn_rel_'+retResult[k].parent+'" class="btn relevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick"></i> Relevant</button>';
            strHTML=strHTML+'<button type="button" id="btn_notrel_'+retResult[k].parent+'" class="btn nonrelevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","not-relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick fa fa-check"></i> Non-Relevant</button>';
          }
          else
          {
            strHTML=strHTML+'<button type="button" id="btn_rel_'+retResult[k].parent+'" class="btn relevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick"></i> Relevant</button>';
            strHTML=strHTML+'<button type="button" id="btn_notrel_'+retResult[k].parent+'" class="btn nonrelevantbtn dblclick" onclick=\'doAction("Update","'+retResult[k]._id+'","not-relevant","'+strSelectedProfileID+'",'+k+',this.id,"'+retResult[k].parent+'",event);\'><i class="tick"></i> Non-Relevant</button>';
          }
  
          if(retResult[k].score!==undefined && retResult[k].score!==null && retResult[k].score!=="")
          {
            strHTML=strHTML+'<span class="score">Score: '+retResult[k].score+'</span>';
          }
          else
          {
            strHTML=strHTML+'<span class="score">&nbsp;</span>';
          }

          if($.trim(retResult[k].score_result).toLowerCase()==='skip')
              strHTML=strHTML+'<span class="skip textcapitalize">'+retResult[k].score_result;
          else if($.trim(retResult[k].score_result).toLowerCase()==='review')
              strHTML=strHTML+'<span class="review textcapitalize">'+retResult[k].score_result;
          else
              strHTML=strHTML+'<span class="review">&nbsp;';

          if(retResult[k].model_result!==undefined)
          {
            if(retResult[k].model_result!='')
            {
              strHTML=strHTML+' (<span class="modelresult">'+parseFloat(retResult[k].model_result).toFixed(3)+'</span> )';
            }
            else
            {
              strHTML=strHTML+'<span class="modelresult">&nbsp;</span>';
            }
          }
          strHTML=strHTML+'</span>';

          strHTML=strHTML+'</div>';
        }
        $("#div_Items").append(strHTML);
        strHTML='';

        
      }
      $(".dblclick").dblclick(function(e)
      {
        e.preventDefault();
        e.cancelBubble = true;
      });
      fnBindRightPanel('item_'+arrCreatedItems[0].parent+'',arrCreatedItems[0].parent,0,"AutoLoad");
    }
    else
    {
      $("#div_Items").html('');
      strHTML='';
      $("#div_loader").hide();
      $("#spnRecordCount").html('(Records: 0)');
      __alertfy('alertfy_Info','record not found');
    }
}

$(document).on("keyup", function(e) 
{
  var key = e.which;
  if (key == 13 && $('#ul_buckets').css('display') == 'block')
  {
    addBucketTextDB($($('#'+e.target.id).parent().siblings()[0]));
  }
  else if (key == 13 && $('#edit_dataset').css('display') == 'block')
  {
    fnGoto();
  }
  else if(key == 13 && e.target.className==='appCustomFilter')
  {
      var ctrlId=e.target.id.split('___')[1];
      $("#anc_"+ctrlId).click();
  }
  else if(key == 13 && $.trim($("#taRight_Comment").val())!=='')
  {
     $("#btnSaveComment").click();
  }
  else if(((key >= 65 && key <= 90) ||(key >= 48 && key <= 57)) && $.trim(window.getSelection().toString())!=='')
  {
     console.log(e.key);
     var value=(e.key).toUpperCase();
     if($(".custom-menu li").length>0 && getSelectedText()!=='')
     {
       for(var k=0;k<$(".custom-menu li").length;k++)
       {
          var ctrl=$($(".custom-menu li")[k]);
          if($.trim($($($(".custom-menu li")[k]).find('span')[1]).html()).toUpperCase()===value)
          {
            addBucketTextDB(ctrl);
            break;
          }
       }
     }
  }
});

$(document).keydown(function(e) 
{
  if(e.ctrlKey && e.keyCode == 82)
  {
      e.preventDefault();
      var btns=$(".profilecontent.selected").find('button');
      if(btns.length>0)
      {
        for(var t=0;t<btns.length;t++)
        {
            var id=$(btns[t]).attr('id');
            if(parseInt($.trim(id).indexOf('btn_rel_'))>=0)
            {
              $('#'+id).click();
            }
        }
      }
  }
  else if(e.ctrlKey && e.keyCode == 69)
  {
      e.preventDefault();
      var btns=$(".profilecontent.selected").find('button');
      if(btns.length>0)
      {
        for(var t=0;t<btns.length;t++)
        {
            var id=$(btns[t]).attr('id');
            if(parseInt($.trim(id).indexOf('btn_notrel_'))>=0)
            {
              $('#'+id).click();
            }
        }
      }
  }
  else if(e.ctrlKey && e.keyCode == 85)
  {
      e.preventDefault();
      var btns=$(".profilecontent.selected").find('li');
      if(btns.length>0)
      {
        for(var t=0;t<btns.length;t++)
        {
            var id=$(btns[t]).attr('id');
            if(parseInt($.trim(id).indexOf('li_markread_'))>=0)
            {
              var itemId=$.trim($.trim(id).split('_')[2])
              lastSeen(itemId,"N","T");
            }
        }
      }
  }
  else
  {
    switch(e.which) 
    {
        case 37: // left
        break;
  
        case 38: // up
        e.preventDefault();
        $('#div_Items').animate({
          scrollTop: $('#item_'+preItemID+'').offset().top - $('#div_Items').offset().top +$('#div_Items').scrollTop()
        });
        if($.trim($("#div_Items .profilecontent.selected").attr('id'))!=='item_'+preItemID+'')
        {
          fnBindRightPanel('item_'+preItemID+'',preItemID,1,"ArrowEvent");
        }
        break;
  
        case 39: // right
        break;
  
        case 40: // down
        e.preventDefault();
        $('#div_Items').animate({
          scrollTop: $('#item_'+nxtItemID+'').offset().top - $('#div_Items').offset().top +$('#div_Items').scrollTop()
        });
        fnBindRightPanel('item_'+nxtItemID+'',nxtItemID,1,"ArrowEvent");
        break;
  
        default: 
          break;
    }
  }
});
function fnBindRightPanel(id,itemID,op,EventNme)
{
    $("#taRight_Comment").val('');
    //$("#div_columns").unmark();
    $("#div_columns").unhighlight();
    $("#div_loader").show();
    var idx=0;
    strSelectedItemID=itemID;
    var dbAlias=selectedDBAlias;
    for(var t=0;t<arrCreatedItems.length;t++)
    {
        if($.trim(arrCreatedItems[t].parent)===$.trim(itemID))
        {
              idx=t;
              var nxt=0;
              var pre=0;
              if((parseInt(idx)+1)>=(arrCreatedItems.length-1))
              {
                nxt=arrCreatedItems.length-1;
              }
              else
              {
                nxt=parseInt(idx)+1;
              }
  
              if(parseInt(idx)>0)
              {
                pre=parseInt(idx)-1;
              }
              else
              {
                pre=0;
              }
  
              nxtItemID=$.trim(arrCreatedItems[nxt].parent);
              preItemID=$.trim(arrCreatedItems[pre].parent);
            
              $("#btnPrevious").attr('onclick','return fnNextPreviousItem("item_'+preItemID+'","'+preItemID+'",1,"MouseClick","Previous")');
              $("#btnNext").attr('onclick','return fnNextPreviousItem("item_'+nxtItemID+'","'+nxtItemID+'",1,"MouseClick","Next")');
              break;
        }
    }

    var retResult=arrSourceData.filter(function(n)
    {
      return $.trim(n._id)===$.trim(itemID)
    });
    $("#div_columns").html('');
    if(arrSelectedProfileInfos[0].fields.length>0)
    {
        var strHTML='';
        $("#divRight_Title h4").html(retResult[0][dbAlias.Title]);
        $("#divRight_Title a").attr('href',retResult[0][dbAlias.Link]).css('cursor','pointer')
        for(var t=0;t<arrSelectedProfileInfos[0].fields.length;t++)
        {
          strHTML='';
          var keyName=arrSelectedProfileInfos[0].fields[t].name;
          if($.trim(keyName)!=="_id" && $.trim(keyName)!=="__EMPTY" && $.trim(keyName)!=="Unnamed__0" && $.trim(keyName)!=="0" && $.trim(keyName)!=="Unnamed: 0" && $.trim(keyName)!=="")
          {
            var upperColName=$.trim(keyName).toUpperCase().replace(/[^a-zA-Z0-9_-]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
            //strHTML=strHTML+'<div class="desc-content">';
            strHTML=strHTML+'<div class="title-container">';
            strHTML=strHTML+'<div class="desclr title-head parentaccordian">'+upperColName+'</div>';
            if(arrSelectedProfileInfos[0].fields[t].type!==undefined)
            {
              if($.trim(arrSelectedProfileInfos[0].fields[t].type[0])==='date')
              {
                  strHTML=strHTML+'<div class="desctext" name="'+keyName+'" style="display:none;">'+makeFormatedDate(retResult[0][keyName])+'</div>';
              }
              else
              {
                  var data=retResult[0][keyName];
                  if (typeof data === 'string' || data instanceof String)
                  {
                    data=data.replace(/  +/g, ' ').replace(/&nbsp;/g,' ')
                  }
                  strHTML=strHTML+'<div class="desctext" name="'+keyName+'" style="display:none;">'+data+'</div>';
              }
            }
            else
            {
                var data=retResult[0][keyName];
                if (typeof data === 'string' || data instanceof String)
                {
                  data=data.replace(/  +/g, ' ').replace(/&nbsp;/g,' ')
                }
                strHTML=strHTML+'<div class="desctext" name="'+keyName+'" style="display:none;">'+data+'</div>';
            }
            
            strHTML=strHTML+'</div>';
            $("#div_columns").append(strHTML);
            strHTML='';
          }
          
        }
        var arrComment=arrSelectedProfileData.filter(function(n)
        {
          return $.trim(n.parent)===$.trim(retResult[0]._id)
        });
        $("#taRight_Comment").val($.trim(arrComment[0].comment));
        $("#btnSaveComment").attr('onclick','return fnSaveComment("'+itemID+'","'+strSelectedProfileID+'");')
        $(".parentaccordian").click(function()
        {
            $(this).toggleClass('active');
            $(this).siblings('.desctext').slideToggle();
        });
    }
    $(".profilecontent").removeClass('selected');
    $("#"+id).removeClass('active');
    $("#"+id).addClass('selected');
    $("#spn_SelectedItemNo").html($("#div_Items .profilecontent.selected").attr('name'));
    if(iNextPre===3)
    {
      console.log('true');
      var num=parseInt($("#spn_SelectedItemNo").html());
      $("#div_Items .profilecontent").removeClass('selected')
      $('#div_Items [name='+gotoNum+']').addClass('selected');
      gotoNum=0;
      iNextPre=0;
    }
    if(op===1)
    {
      lastSeen(itemID,'Y','F');
    }
    else
    {
      //searchKeyword();//Himanshu_25_06
      showBucket();
    }
    bindBucketsRightMenu();
}


function fnNextPreviousItem(CtrlId,ItemId,Op,EventNme,param)
{
  $('#div_Items').animate({
    scrollTop: $('#item_'+preItemID+'').offset().top - $('#div_Items').offset().top +$('#div_Items').scrollTop()
  });
  fnBindRightPanel(CtrlId,ItemId,1,"MouseClick");
}

function fnSaveComment(id,profileId)
{
  $("#div_loader").show();
  var res=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(profileId)
  });
  if(res.length>0)
  {
      var arrComment=arrSelectedProfileData.filter(function(n)
      {
        return $.trim(n.parent)===$.trim(id)
      });
      arrComment[0].comment=$("#taRight_Comment").val();
      var comment= encodeURI($("#taRight_Comment").val().replace(/&/gi,' and '));
      var req = new XMLHttpRequest();
      req.open('GET', '/_api/doCommentUpdate?dbName='+res[0].profile_name+'&Path=0&objId='+id+'&comment='+comment);
      req.send();
      req.onload = function () 
      {
          //var obj = JSON.parse(req.response);
          $("#div_loader").hide();
      };
  }
}

function lastSeen(itemID,action,preEvent)
{
  if(preEvent==='T')
  {
    event.cancelBubble = true;
  }
  var resProfile=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(strSelectedProfileID)
  });
  var chkLastSeenDT=arrSelectedProfileData.filter(function(n)
  {
    return $.trim(n.parent)===$.trim(itemID)
  });
  if(action.toUpperCase()=='Y')
  {
    chkLastSeenDT[0].modified=new Date();
    $("#item_"+itemID).removeClass('profilecontent_unread_bold').addClass('selected');
  }
  else
  {
    chkLastSeenDT[0].modified="";
    $("#item_"+itemID).removeClass('selected').addClass('profilecontent_unread_bold');
  }
  
  var req = new XMLHttpRequest();
    req.open('GET', '/_api/doLastSeenUpdate?dbName='+resProfile[0].profile_name+'&Path=0&parentID='+itemID+'&lstSeen='+action);
    req.send();
    req.onload = function () 
    {
      //searchKeyword();//Himanshu_25_06
      showBucket();
    };
}

function fnRedirectItemURL(url)
{
  window.location.href=url;
}

function doAction(action,itemId,response,profileid,index,btnID,docID,event)
{
  event.cancelBubble = true;
  event.preventDefault();

  actionDocId=docID;
  actionResponse=response;
  $("#div_loader").show();
  var resProfile=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(profileid)
  });
  var comment=$.trim($("#taRight_Comment").val());
  if($.trim($("#"+btnID).find('i').attr('class')).indexOf('fa-check')>=0)
  {
    $(".profilecontent").removeClass('selected');
    $("#item_"+docID).removeClass('profilecontent_unread_bold').addClass('selected');
    $("#item_"+docID).find('#btn_rel_'+docID).find('i').removeClass('fa-check');
    $("#item_"+docID).find('#btn_notrel_'+docID).find('i').removeClass('fa-check');
    $("#item_"+docID).removeClass('relevant').removeClass('nonrelevant');

    doItemUpdate(resProfile[0].profile_name,resProfile[0].profile_path,'',itemId,comment,docID);
  }
  else
  {
    $(".profilecontent").removeClass('selected');
    $("#item_"+docID).removeClass('profilecontent_unread_bold').addClass('selected');
    $("#item_"+docID).find('#btn_rel_'+docID).find('i').removeClass('fa-check');
    $("#item_"+docID).find('#btn_notrel_'+docID).find('i').removeClass('fa-check');
    $("#item_"+docID).removeClass('relevant').removeClass('nonrelevant');

    if($.trim(response)==='relevant')
    {
      $("#item_"+docID).addClass('relevant');
      $("#item_"+docID).find('#btn_rel_'+docID).find('i').addClass('fa').addClass('fa-check');
    }
    else if($.trim(response)==='not-relevant')
    {
      $("#item_"+docID).addClass('nonrelevant');
      $("#item_"+docID).find('#btn_notrel_'+docID).find('i').addClass('fa').addClass('fa-check');
    }
    doItemUpdate(resProfile[0].profile_name,resProfile[0].profile_path,response,itemId,comment,docID);
  }
}

function doItemUpdate(profileName,profilePath,response,objId,comment,docID)
{
    var comment= encodeURI(comment.replace(/&/gi,' and '));
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/doItemUpdate?dbName='+profileName+'&Path=0&response='+response+'&objId='+objId+'&comment='+comment);
    req.send();
    req.onload = function () 
    {
        var obj = JSON.parse(req.response);
        var retResult=arrSelectedProfileData.filter(function(n)
        {
          return ($.trim(n.parent)===$.trim(actionDocId))
        });
        retResult[0].useraction=actionResponse;
        retResult[0].modified=new Date();
        retResult[0].comment=$("#taRight_Comment").val();
        if(obj.ok===1)
        {
          $("#taRight_Comment").val('');
          iTotalRecordCount=iTotalRecordCount-1;
          var filter=$.trim($("#ul_filter li.selectedfilter").attr('name'));
          if(filter==='pending' || filter==='relevant' || filter==='not-relevant' || filter==='unread')
          {
              $("#spnRecordCount").html('(Records: '+iTotalRecordCount+')');
          }
        }
        fnBindRightPanel('item_'+docID+'',docID,1,"MouseClick");
    };
}

function fnEditProfile(ctrl,profileid,event)
{
  currentSelected='';
  $scope.profileEdit(profileid);
  setTimeout(function()
  { 
      addSelective();
      vdtBucket();
  }, 100);
  //event.preventDefault();
  //event.cancelBubble = true;
  
}
function fnDeleteProfile(ctrl,profileid,event)
{
  var res=arrAllProfiles.filter(function(el)
  {
    return $.trim(el._id)===$.trim(profileid)
  })
  if(confirm('Are you sure? You want to delete '+res[0].profile_name+' profile.'))
  {
    $("#div_loader").show();
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/DeleteProfile?ProfileDBName='+res[0].profile_name+'&ProfileId='+profileid+'');
    req.send();
    req.onload = function () 
    {
      var obj = req.response;
      $("#div_loader").hide();
      if(obj==='true' && req.statusText==='OK')
      {
         ReadPofileInfo();
      }
    };
  }
}

function fnShowEditDataSet()
{
    $("#lblRecordSet").css('display','none');
    $("#btnPreviousRecord").css('display','none');
    $("#btnNextRecord").css('display','none');
    $("#edit_dataset").css('display','block');
    var totalRecordLen=parseInt($("#spnRecordCount").html().split(': ')[1]);
    $("#txtDocumentNumber").val(0);
    $("#lblTotalRecordlength").html(totalRecordLen);
    if (window.getSelection) 
    {
      if (window.getSelection().empty) 
      {  
        // Chrome
        window.getSelection().empty();
      } 
      else if (window.getSelection().removeAllRanges) 
      {  
        // Firefox
        window.getSelection().removeAllRanges();
      }
    } 
    else if (document.selection) 
    { 
      // IE?
      document.selection.empty();
    }
}


function fnCancelGoTo()
{
    $("#txtDocumentNumber").val(0);
    $("#lblRecordSet").css('display','block');
    $("#btnPreviousRecord").css('display','block');
    $("#btnNextRecord").css('display','block');
    $("#edit_dataset").css('display','none');
    $("#txtDocumentNumber").css('border','1px solid #ababab');
}

function fnGoto()
{
    var totalRecordLen=parseInt($("#spnRecordCount").html().split(': ')[1]);
    var DocumentNumber=$.trim($("#txtDocumentNumber").val())===''?0:parseInt($("#txtDocumentNumber").val());
    if(DocumentNumber==='')
    {
      iValidate=1;
      $("#txtDocumentNumber").css('border','1px solid red');
    }
    else if(parseInt(DocumentNumber)>totalRecordLen)
    {
      iValidate=1;
      $("#txtDocumentNumber").css('border','1px solid red');
      __alertfy('alertfy_Info','Total record length is '+totalRecordLen+'. Kindly enter document number again.');
    }
    else if(parseInt(DocumentNumber)<=0)
    {
      iValidate=1;
      $("#txtDocumentNumber").css('border','1px solid red');
      __alertfy('alertfy_Info','Total record length is '+totalRecordLen+'. Kindly enter document number again.');
    }
    else
    {
      $("#txtDocumentNumber").css('border','1px solid #ababab');
      var SetCount=Math.ceil(totalRecordLen/perPageDataLimit);
      iCurrentSetNo=Math.ceil(parseInt(DocumentNumber)/perPageDataLimit);

      //arrSelectedFilter.push({"filter":$("#ul_filter li.selectedfilter").attr('name'),'isApply':true,'isChildNodeFilter':false,'childnode':''});
      
      strSelectedSort=$("#ul_sort li.selectedSort").attr('name')===undefined?'':$("#ul_sort li.selectedSort").attr('name');
      startLimit=parseInt(DocumentNumber);
      endLimit=startLimit+perPageDataLimit;
      if(startLimit>=totalRecordLen && totalRecordLen>=50)
      {
        startLimit=totalRecordLen-50;
        endLimit=totalRecordLen;
      }
      else if(startLimit>=totalRecordLen && totalRecordLen<50)
      {
        startLimit=1;
        endLimit=totalRecordLen;
      }
      else if(endLimit>=totalRecordLen)
      {
        endLimit=totalRecordLen;
      }
      else
      {
        endLimit=endLimit-1;
      }
      fnCancelGoTo();
      iNextPre=3;
      gotoNum=DocumentNumber;
      fnGetItems(strSelectedProfileID,arrSelectedFilter,strSelectedSort,'GoTo');
    }
}


function fnDownload(profileid,event)
{
    //event.cancelBubble = true;
    var res=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(profileid)
    })
    if(res.length>0)
    {
        var totalrecordcount=res[0].total_record_count;
        var page=Math.ceil(parseInt(totalrecordcount)/500);
        var perPage=500;
        var strdata=JSON.stringify([]);
        window.open('/_api/ExcelExport_exceljs/'+res[0].profile_name.replace(/[^A-Z0-9]+/ig, "_")+'.xlsx/'+page+'/'+perPage+'/'+strdata+'?SourceDBName='+res[0].db_name+'&SourceDBPath=0&ProfileDBName='+res[0].profile_name+'&ProfileDBPath=0')
    }
}

function b64toBlob(byteCharacters, contentType, sliceSize) 
{
    contentType = contentType || '';
    sliceSize = sliceSize || 512;
    //var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) 
    {
        var slice = byteCharacters.slice(offset, offset + sliceSize);
        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) 
        {
            byteNumbers[i] = slice.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }
    var blob = new Blob(byteArrays, {type: contentType});
    return blob;
}



function fnFormatedDate(param)
{
  if(parseInt(param)<=9)
    return "0"+param;
  else
    return param;
}
function getMonthName(param)
{
  switch(param) {
    case 1:
      return "Jan"
      break;
    case 2:
      return "Feb"
      break;
    case 3:
      return "Mar"
      break;
    case 4:
      return "Apr"
      break;
    case 5:
      return "May"
      break;
    case 6:
      return "Jun"
      break;
    case 7:
      return "Jul"
      break;
    case 8:
      return "Aug"
      break;
    case 9:
      return "Sep"
      break;
    case 10:
      return "Oct"
      break;
    case 11:
      return "Nov"
      break;
    case 12:
      return "Dec"
      break;
   
  }
}

function makeFormatedDate(param)
{
    var d=new Date(param);
    return getMonthName(d.getMonth()+1)+'-'+fnFormatedDate(d.getDate())+','+(d.getFullYear());
}

function fnValidateNumber(evt)
{
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    {
       return false;
    }
    else
    {
       return true;
    }
}

function addSelective()
{
  $('.selectiveKey').selectize({
    plugins: ['remove_button'],
    delimiter: ',',
    persist: false,
    create: function(input) {
      return {
        value: input,
        text: input
      }
    }
  });

  $('.selectiveKey').removeClass('selectiveKey');
}

function vdtBucket()
{
  $(".bucketname").keyup(function () 
    {
        var textValue = $(this).val();
        textValue =textValue.replace(/ /g,"_");
        var format = /[!@#$%^&*()+\=\[\]{};':"\\|<>\/?]+/;
        if(format.test(textValue))
        {
          var val=textValue.substring(0,textValue.length-1);
          $(this).val(val);
        } 
        else 
        {
          $(this).val(textValue);
        }
    });
}
    
function GetSortOrder(prop) {  
  return function(a, b) {  
      if (a[prop] > b[prop]) {  
          return 1;  
      } else if (a[prop] < b[prop]) {  
          return -1;  
      }  
      return 0;  
  }  
} 


Array.prototype.flexFilter = function(info)
{
  
  // Set our variables
  var matchesFilter, matches = [], count;
  
  // Helper function to loop through the filter criteria to find matching values
  // Each filter criteria is treated as "AND". So each item must match all the filter criteria to be considered a match.
  // Multiple filter values in a filter field are treated as "OR" i.e. ["Blue", "Green"] will yield items matching a value of Blue OR Green.
  matchesFilter = function(item) {
    count = 0
    for (var n = 0; n < info.length; n++) {
      var val = info[n]["Values"];

      if(typeof val == 'function')
      {
        if( val(item[info[n]["Field"]]))
          count++;
          continue;
      }
      else if (val.indexOf(item[info[n]["Field"]]) > -1) {
        count++;
        continue;
      }
      else
      {
        var docontinue = false;
        for(var i=0; i<val.length; i++)
        {
          var valFn = val[i];
          if(typeof valFn == 'function')
          {
            if(valFn(item[info[n]["Field"]]))
              count++;
              docontinue=true;
              break;
          }
        }
        if(docontinue)continue;
      }
    }
    // If TRUE, then the current item in the array meets all the filter criteria
    return count == info.length;
  }

  // Loop through each item in the array
  for (var i = 0; i < this.length; i++) {
    // Determine if the current item matches the filter criteria
    
    if (matchesFilter(this[i])) {
      matches.push(this[i]);
    }
  }

  // Give us a new array containing the objects matching the filter criteria
  return matches;
}


/*
function fnDragDropProfile()
{
    //window.startPos = window.endPos = {};
    makeDraggable();
    $('.drophere').droppable({
      hoverClass: 'hoverClass',
      drop: function(event, ui) {
        var $from = $(ui.draggable),
            $fromParent = $from.parent(),
            $to = $(this).children(),
            $toParent = $(this);

        window.endPos = $to.offset();

        swap($from, $from.offset(), window.endPos, 0);
        swap($to, window.endPos, window.startPos, 1000, function() 
        {
          $toParent.html($from.css({position: 'relative', left: '', top: '', 'z-index': ''}));
          $fromParent.html($to.css({position: 'relative', left: '', top: '', 'z-index': ''}));
          makeDraggable();
        });
      }
    });
    function makeDraggable() 
    {
      $('.draghere').draggable({
        zIndex: 99999,
        revert: 'invalid',
        start: function(event, ui) {
          window.startPos = $(this).offset();
        }
      });
    }

    function swap($el, fromPos, toPos, duration, callback) {
      $el.css('position', 'absolute')
        .css(fromPos)
        .animate(toPos, duration, function() {
          if (callback) callback();
        });
    }
}

*/



