function searchKeyword() 
{
  arrSearchFrequency=[];
  for(var t=0;t<arrSelectedProfileInfos[0].categories.length;t++)
  {
    var catname=arrSelectedProfileInfos[0].categories[t].catname;
    var catColor=arrColors.filter(function(ee)
    {
      return $.trim(ee.CatName)===$.trim(catname)
    });
    for(var k=0;k<arrSelectedProfileInfos[0].categories[t].fields.length;k++)
    {
        var fieldname=$.trim(arrSelectedProfileInfos[0].categories[t].fields[k]).replace(/[^a-zA-Z0-9_-]/ig, "_").replace(/\s/g,'_');//.replace(/[^a-zA-Z0-9_-]/ig, "");
        for(var w=0;w<arrSelectedProfileInfos[0].categories[t].keywords.length;w++)
        {
            var keyword=$.trim(arrSelectedProfileInfos[0].categories[t].keywords[w]).toLowerCase().replace(/[^a-zA-Z0-9]/ig, "");
            mark_container=fieldname;//'[name='+fieldname+']';
            mark_keyword=keyword;
            mark_color=catColor[0].color;
            clsRemoveSpace="match "+catname.toUpperCase().replace(/  +/g, '#').replace(/_/g, '###').replace(/\s/g,'#')+" "+catname.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+"_"+fieldname.replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+"_"+mark_keyword.replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+" KeywordSearch";
            //mark();
            var options = {
              wordsOnly: true,
              className: clsRemoveSpace,
              caseSensitive: false,
              element:'mark'
            };
            $('[name='+mark_container+']').unhighlight();
            $('[name='+mark_container+']').highlight(mark_keyword, options);
            $('[name='+mark_container+']'+' > mark').css('background-color',mark_color);
            $('[name='+mark_container+']'+' > mark').css('color','white');
            $('[name='+mark_container+']'+' > mark').css('border-radius','80px');
            $('[name='+mark_container+']'+' > mark').css('padding','0px 10px');
        }
    }
  }
  var iFind=0;
  var srchDIV='';
  for(var i=0;i<$(".desctext").length;i++)
  {
    if($($(".desctext")[i]).find('mark').length>0)
      {
        if(iFind===0)
        {
            iFind=1;
            srchDIV=$($(".desctext")[i]).siblings();//.siblings().attr('name');
        }
        $($(".desctext")[i]).siblings().addClass('active').css('background','#544f40').css('color','#fff');
        if(_isRefresh===0)
        {
            $($(".desctext")[i]).slideToggle();
        }
      }
  }
  if(srchDIV!==undefined && srchDIV!=='' && _isRefresh===0)
  {
    $('#div_columns').animate({
      scrollTop: $(srchDIV).offset().top - $('#div_columns').offset().top +$('#div_columns').scrollTop()
    });
  }
  else
  {
    _isRefresh=0;
  }

  for(var col=0;col<arrColors.length;col++)
  {
    var cat=arrColors[col].CatName.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#');
    $("."+cat).css('background-color',arrColors[col].color);
    $("."+cat).css('color','white');
  }

  iBucketCount=0;
  iBucketDetailCount=0;
  $("#div_loader").hide();
  _showKeywordTooltip();
}

function _showKeywordTooltip()
{
    $('.KeywordSearch').hover(function(event)
    {
      var x = event.clientX;
      var y = event.clientY;
      _getKeywordStats($(this));
      /*
      console.log('================================================');
      console.log('ClientX==>'+x,'ClientY==>'+y);
      console.log('PageX==>'+event.pageX,'PageY==>'+event.pageY);
      console.log("Total Width: " + screen.width);
      console.log("Screen availWidth: " + screen.availWidth,"Screen availHeight: "+ screen.availHeight);
      console.log("Container Width: " + $(".container").width());
      console.log('================================================');
      */
      var pageX=event.pageX;
      var pageY=event.pageY;
      var totalwidth=screen.width;
      var fixWidth=totalwidth-150;
      var containerwidth=$(".container").width();
      /*
          top: (event.pageY+10) + "px",
          left: (event.pageX) + "px"
      */
      if(pageX>fixWidth)
      {
        pageX=pageX-140;
      }
      $(".bucketTooltip").finish().toggle(500).
      css({
          top: (pageY+10) + "px",
          left: (pageX) + "px"
      });
    });

    $('.KeywordSearch').mouseout(function(event)
    {
      $(".bucketTooltip").hide();
    });
}

function _getKeywordStats(ctrl)
{
  if($("mark").length>0)
  {
      var clsName='';
      var k=0;
      var arrSpt=[];
      var tcname=$.trim($(ctrl).attr('class').split(' ')[1]).replace(/###/g, '_').replace(/#/g, ' ');
      var tfieldname=$.trim($(ctrl).attr('class').split(' ')[2]).split('_')[1].replace(/#/g, ' ');
      var tkeywordVal=$.trim($(ctrl).attr('class').split(' ')[2]).split('_')[2].replace(/#/g, ' ');
      var cname='';
      var fieldname='';
      var keywordVal='';
      var iCount=0;
      for(k=0;k<$("mark").length;k++)
      {
        clsName=$($("mark")[k]).attr('class').split(' ')[2];
        arrSpt=clsName.split('_');
        cname=$.trim($($("mark")[k]).attr('class').split(' ')[1]).replace(/###/g, '_').replace(/#/g, ' ');
        fieldname=$.trim(arrSpt[1]).replace(/#/g, ' ');
        keywordVal=$.trim(arrSpt[2]).replace(/#/g, ' ');
        if($.trim(cname).toLowerCase()===$.trim(tcname).toLowerCase() && $.trim(fieldname)===$.trim(tfieldname) && $.trim(keywordVal)===$.trim(tkeywordVal))
        {
          iCount=iCount+1;
        }
      }
      var clrs=arrColors.filter(function(f)
      {
        return ($.trim(f.CatName).toLowerCase()===$.trim(tcname).toLowerCase())
      });
      var strHTML='';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Keyword</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+tkeywordVal+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Category</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+tcname+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Field</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+tfieldname+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Count</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+iCount+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Color</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><div style="background:'+clrs[0].color+';min-width: 14px;cursor:pointer;min-height: 15px;display: inline-block;float:left;"></div></td>';
      strHTML=strHTML+'</tr>';
      $("#tblBucketKeywordStats").html('');
      $("#tblBucketKeywordStats").html(strHTML);
      strHTML='';
  }
  else
  {
    $(".bucketTooltip").hide();
    $("#tblBucketKeywordStats").html('');
  }
}





$(".close-cross").click(function()
{
  $("#myProfileFrequency").css('display','none');
  $("#div_FrequencyCloud").html('');
  $("#div_ProfileFrequency").html('');
})


function getWordFrequency(ctrlid,ctrl)
{
  $("#div_loader").show();
  var color=$.trim(ctrlid.split('__')[1]);
  var category=$.trim(ctrlid.split('__')[2]);
  //$("#div_columns > mark");
  //arrColors.push({'CatName':catName,'color':rgb});
  //arrSearchFrequency
  var arrFrequency=new Array();
  if($("mark").length>0)
  {
      var clsName='';
      var k=0;
      var arrSpt=[];
      var cname='';
      var fieldname='';
      var keywordVal='';
      for(k=0;k<$("mark").length;k++)
      {
        clsName=$($("mark")[k]).attr('class').split(' ')[2];
        arrSpt=clsName.split('_');
        cname=$.trim(arrSpt[0]).replace(/#/g, ' ');
        fieldname=$.trim(arrSpt[1]).replace(/#/g, ' ');
        keywordVal=$.trim(arrSpt[2]).replace(/#/g, ' ');
        var fil=arrFrequency.filter(function(f)
        {
          if(color==='all' && category==='all')
          {
              return ($.trim(f.field)===$.trim(fieldname) && $.trim(f.keyword)===$.trim(keywordVal))
          }
          else
          {
              return ($.trim(f.Category).toLowerCase()===$.trim(category).toLowerCase() && $.trim(f.field)===$.trim(fieldname) && $.trim(f.keyword)===$.trim(keywordVal))
          }
          
        });
        if(fil.length>0)
        {
          fil[0].count=parseInt(fil[0].count)+1;
        }
        else
        {
          if(color==='all' && category==='all')
          {
            var resSet=arrColors.filter(function(c)
            {
              return ($.trim(c.CatName).toLowerCase()===$.trim(cname).toLowerCase())
            });
            arrFrequency.push({'Category':cname,'field':fieldname,'keyword':keywordVal,'count':1,'color':resSet[0].color});
          }
          else if($.trim(cname).toLowerCase()===$.trim(category).toLowerCase())
          {
            arrFrequency.push({'Category':cname,'field':fieldname,'keyword':keywordVal,'count':1,'color':'#'+color});
          }
        }
      }
  }
  $("#div_loader").hide();
  $("#div_ProfileFrequency").html('');
  $("#div_FrequencyCloud").html('');
  if(arrFrequency.length>0)
  {
    var sHTML='';
    sHTML=sHTML+'<table class="FrequencyTable" cellpadding="0" cellspacing="0" border="0">';
    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<th>Category</th>';
    sHTML=sHTML+'<th>Field</th>';
    sHTML=sHTML+'<th>Keyword</th>';
    sHTML=sHTML+'<th>Count</th>';
    sHTML=sHTML+'<th>Color</th>';
    sHTML=sHTML+'</tr>';
    for(var s=0;s<arrFrequency.length;s++)
    {
      sHTML=sHTML+'<tr>';
      sHTML=sHTML+'<td>'+arrFrequency[s].Category+'</td>';
      sHTML=sHTML+'<td>'+arrFrequency[s].field+'</td>';
      sHTML=sHTML+'<td>'+arrFrequency[s].keyword+'</td>';
      sHTML=sHTML+'<td>'+arrFrequency[s].count+'</td>';
      sHTML=sHTML+'<td><div style="width:15px;height:15px;background:'+arrFrequency[s].color+'"></td>';
      sHTML=sHTML+'</tr>';
    }
    sHTML=sHTML+'</table">';
    $("#div_ProfileFrequency").html(sHTML);
    sHTML='';
    _bindLegends();
    fnFrequencyCloud(arrFrequency,color);
  }
  else
  {
    var sHTML='';
    sHTML=sHTML+'<table class="FrequencyTable" cellpadding="0" cellspacing="0" border="0">';
    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<th>Category</th>';
    sHTML=sHTML+'<th>Field</th>';
    sHTML=sHTML+'<th>Keyword</th>';
    sHTML=sHTML+'<th>Count</th>';
    sHTML=sHTML+'</tr>';
    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<td colspan="4" style="text-align:center;">No record found</td>';
    sHTML=sHTML+'</tr>';
    sHTML=sHTML+'</table">';
    $("#div_ProfileFrequency").html(sHTML);
    $("#myProfileFrequency").css('display','block');
    sHTML='';
  }
  
}


function _bindLegends()
{
  $("#tblSignificance").html('');
  //$("#div_columns").css('height','calc(100vh - 340px)');
  var iTdsCount=0;
  //$("#div_columns").height($("#div_columns").height()+idecWidth);
  //$("#div_significance").height($("#div_significance").height()-idecWidth-20);
  //idecWidth=0;
  var strLegends='';
  strLegends=strLegends+'<tr>';
  strLegends=strLegends+'<td><span id="spn__all__all" style="cursor:pointer;font-weight:bold;" onclick="return getWordFrequency(this.id,this);">Legends : &nbsp;</span></td>';
  iTdsCount++;
  for(var t=0;t<arrSelectedProfileInfos[0].categories.length;t++)
  {
    var catname=arrSelectedProfileInfos[0].categories[t].catname;
    
    var catColor=arrColors.filter(function(ee)
    {
      return $.trim(ee.CatName)===$.trim(catname)
    });
    strLegends=strLegends+'<td>';
    strLegends=strLegends+'<div id="div__'+catColor[0].color.replace(/#/g, '')+'__'+catname.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+'" onclick="return getWordFrequency(this.id,this);" style="min-width: 14px;cursor:pointer;min-height: 15px;background: '+catColor[0].color+';display: inline-block;float:left;"></div>';
    strLegends=strLegends+'<span id="spn__'+catColor[0].color.replace(/#/g, '')+'__'+catname.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+'" style="cursor:pointer;" onclick="return getWordFrequency(this.id,this);" class="pull-left tlabels">'+catname+' &nbsp;</span>';
    strLegends=strLegends+'</td>';
    iTdsCount++;
    if(iTdsCount%8===0)
    {
      strLegends=strLegends+'</tr>';
      strLegends=strLegends+'<tr>';
      
      idecWidth=idecWidth+10;
    }
    if(t===arrSelectedProfileInfos[0].categories.length-1)
    {
      strLegends=strLegends+'</tr>';
      $("#tblSignificance").html(strLegends);
      //idecWidth=idecWidth+10;
      //$("#div_columns").height($("#div_columns").height()-idecWidth);
      //$("#div_significance").height($("#div_significance").height()+idecWidth+20);
      strLegends='';
    }
  }
}

function fnFrequencyCloud(arrFrequency,action)
{
    var word_list=[];
    for(var m=0;m<arrFrequency.length;m++)
    {
      if(action==='all')
      {
        var resSet=word_list.filter(function(c)
        {
          return ($.trim(c.text).toLowerCase()===$.trim(arrFrequency[m].keyword).toLowerCase())
        });
        if(resSet.length>0)
        {
          resSet[0].weight=parseInt(resSet[0].weight)+parseInt(arrFrequency[m].count);
          resSet[0].html['data-tooltip']=parseInt(resSet[0].html['data-tooltip'])+parseInt(arrFrequency[m].count);
        }
        else
        {
          if(m%2===1)
          {
            word_list.push({text: arrFrequency[m].keyword, weight: parseInt(arrFrequency[m].count), html: {"data-tooltip": arrFrequency[m].count}});//,"class": "vertical"
          }
          else
          {
            word_list.push({text: arrFrequency[m].keyword, weight: parseInt(arrFrequency[m].count),html: {"data-tooltip": arrFrequency[m].count}});
          }
        }
      }
      else
      {
        if(m%2===1)
        {
          word_list.push({text: arrFrequency[m].keyword, weight: parseInt(arrFrequency[m].count), html: {"data-tooltip": arrFrequency[m].count}});//,"class": "vertical"
        }
        else
        {
          word_list.push({text: arrFrequency[m].keyword, weight: parseInt(arrFrequency[m].count),html: {"data-tooltip": arrFrequency[m].count}});
        }
      }
    }

    $(function() {
      $("#div_FrequencyCloud").jQCloud(word_list, 
      {
        shape: "rectangular",
        autoResize: true
      });
    });
    $("#profilefre").html("Profile keyword frequency");
    $("#myProfileFrequency").css('display','block');
    
}


