

namespace Config
{

    export interface ICategory
    {
        cat: string,
        words: string[],
        color: string,
    }
    export var Categories: ICategory[] = [
        {
            "cat": "NRK1",
            "words": [
                "non-coeliac gluten",
                "central nervous system",
                "demyelinating",
                "recurrent tonsillitis",
                "autoimmune",
                "cell line",
                "cancer",
                "tumor",
                "tumors",
                "lymphoma",
                "leukemia",
                "diabetes",
                "cardiovascular diseases",
                "dementia",
                "carcinoma",
                "choriocarcinoma",
                "glioblastoma",
                "hepatoma",
                "neoplasm",
                "adenocarcinoma",
                "melanoma",
                "myeloma",
                "neuroblastoma",
                "hodgkin's",
                "non- hodgkin's",
                "lymphoblastic",
                "immunoblastic",
                "macroglobulinemia;",
                "carcinomas",
                "sarcomas",
                "meigs' syndrome",
                "seizures",
                "dravet syndrome",
                "epilepsy",
                "tuberculosis",
                "immunotherapy",
                "myocardial infarction",
                "rheumatoid arthritis",
                "cardiovascular disease",
                "antibiotic therapy",
                "septic shock ",
                "sepsis",
                "critically ill",
                "acute borna disease virus",
                "il-6 antagonists ",
                "cell therapy",
                "t-cell therapy ",
                "autoimmune disease",
                "cancers",
                "neurodegenerative",
                "amyloid deposit diseases",
                "regulatory t cells",
                "treg marker",
                "ewing sarcoma",
                "continuous glucose",
                "breastmilk",
                "capnographic",
                "capnography",
                "mitochondrial dysfunction",
                "eosinophilic esophagitis",
                "esophagitis spongiosis",
                "parkinson's disease ",
                "vaccine delivery ",
                "fungal infections",
                "fungal infection",
                "oral mucositis ",
                "chemotherapy",
                "monoclonal antibodies",
                "anti-tumor",
                "bile acid ",
                "inflammatory bowel diseases",
                "asthma",
                "cardiovascular regeneration",
                "food allergy",
                "checkpoint blockade ",
                "checkpoint inhibitor ",
                "checkpoint inhibitors",
                "cytotoxic",
                "immuno-oncology",
                "immunotherapies",
                "car-t cell therapy",
                "parkinson",
                "cardiovascular",
                "stem cell",
                "porcine respiratory",
                "reproductive syndrome virus",
                "fibrosis"
            ],
            "color": ""
        },
        {
            "cat": "NRK2",
            "words": [
                "implantable",
                "implanted",
                "implanting",
                "implants",
                "implant",
                "catheters",
                "catheter",
                "surgical",
                "surgery"
            ],
            "color": ""
        },
        {
            "cat": "NRK3",
            "words": [
                "avian",
                "poultry",
                "chicken",
                "primate",
                "animal ",
                "animals ",
                "dog",
                "cow",
                "calf",
                "veterinary ",
                "invasive",
                "in-vasive"
            ],
            "color": ""
        },
        {
            "cat": "Conditional",
            "words": [
                "human",
                "non-invasive"
            ],
            "color": ""
        },
        {
            "cat": "Hospital",
            "words": [
                "computer imaging",
                "computed tomography",
                "ct scan",
                "ct scans",
                "cat scan",
                "cat scans",
                "mri",
                "magnetic resonance imaging",
                "magnetic resonance",
                "mri scan",
                "mri scans",
                "ultrasound",
                "x-ray",
                "doppler ",
                "tomography"
            ],
            "color": ""
        },
        {
            "cat": "Condition",
            "words": [
                "common cold",
                "cold virus",
                "cold viral",
                "flu",
                "allergic rhinitis",
                "rhinitis",
                "respiratory allergy",
                "respiratory allergies",
                "nasopharyngitis",
                "rhinopharyngitis",
                "rhinosinusitis",
                "sinusitis",
                "influenza",
                "respiratory infection",
                "respiratory infections",
                "cough",
                "hayfever",
                "bronchitis",
                "laryngitis",
                "upper respiratory tract infection",
                "respiratory",
                "streptococcus ",
                "strep ",
                "strep throat ",
                "streptococcal ",
                "sore throat",
                "respiratory syncytial virus",
                "orthopneumovirus",
                "respiratory virus",
                "streptococcal pharyngitis",
                "smoking cessation",
                "tobacco cessation"
            ],
            "color": ""
        },
        {
            "cat": "Diagnosis",
            "words": [
                "diagnosis",
                "diagnosing ",
                "diagnosis ",
                "diagnose ",
                "diagnostic ",
                "diagnostics",
                "detection",
                "detect",
                "detected",
                "determination",
                "self diagnosis",
                "measurement",
                "identification",
                "identify",
                "examination",
                "examine",
                "evaluation",
                "evaluating",
                "test ",
                "tests"
            ],
            "color": ""
        },
        {
            "cat": "Sample",
            "words": [
                "saliva",
                "urine",
                "blood",
                "serum",
                "sweat",
                "breath",
                "voice",
                "plasma",
                "tear",
                "tears",
                "volatile organic compounds",
                "volatile organic compound",
                "voc's",
                "sputum",
                "body fluid",
                "body fluids",
                "biological fluid",
                "biological fluids",
                "biological sample",
                "biological samples",
                "nasal swab",
                "throat swab",
                "swab",
                "nasal secretion",
                "oral fluid",
                "oral fluids",
                "exhalation ",
                "stool ",
                "feces ",
                "aspirates",
                "aspirate"
            ],
            "color": ""
        },
        {
            "cat": "Specific Keywords",
            "words": [
                "microfluidics",
                "microfluidic",
                "lab-on-chip",
                "lab on chip",
                "immunoassay",
                "radioimmunoassays",
                "enzyme-linked immunosorbent assay",
                "elisa",
                "specificity",
                "accuracy",
                "accurately",
                "active noise cancellation",
                "real-time",
                "rapid",
                "at home",
                "at-home",
                "self-test",
                "self test",
                "self-diagnosis",
                "self-diagnostics",
                "self-detection",
                "self diagnosis",
                "self diagnostics",
                "self detection",
                "home diagnosis",
                "home diagnostics",
                "portability",
                "portable",
                "poc",
                "point-of-care",
                "point of care",
                "lateral flow assays",
                "lateral flow assay",
                "lfa",
                "sensor",
                "sensors",
                "biosensor",
                "biosensors",
                "bio-sensor",
                "bio-sensors"
            ],
            "color": ""
        },
        {
            "cat": "Digital",
            "words": [
                "mobile",
                "phone",
                "smartphone",
                "computer",
                "mobile application",
                "user interface",
                "wireless",
                "bluetooth",
                "wifi",
                "internet",
                "algorithm",
                "machine learning",
                "artificial intelligence",
                "data transfer",
                "data communication",
                "internet of things",
                "wearable",
                "wearables",
                "sensor",
                "sensors",
                "biosensor",
                "biosensors",
                "bio-sensor",
                "bio-sensors",
                "digiceuticals",
                "mhealth",
                "digital marker",
                "digital biomarker",
                "voice assistant",
                "voice-assistant",
                "accelerometer",
                "gyroscope",
                "ehealth",
                "digital therapeutics",
                "bracelet",
                "ai-powered",
                "ai-enabled",
                "ai-based",
                "ai based",
                "ai enabled",
                "headband",
                "patch"
            ],
            "color": ""
        },
        {
            "cat": "Parameters",
            "words": [
                "physiological parameter ",
                "physiological parameters ",
                "heart rate",
                "respiration",
                "breathing",
                "heart rate variability",
                "blood pressure",
                "respiratory rate",
                "vital signs",
                "blood oxygen",
                "body temperature",
                "ecg",
                "ekg",
                "electrocardiography ",
                "electrocardiogram",
                "electroencephalogram ",
                "electroencephalography ",
                "eeg",
                "hrv",
                "imaging",
                "biomarker"
            ],
            "color": ""
        }
    ];

    placeColor();
    function placeColor()
    {
        var max = 360;
        var divs = Categories.length;
        var step = max / divs;

        Categories.forEach((c, i) =>
        {
            c.color = `hsla( ${step * i},100%,90% )`;
        });
    }
}

namespace UI
{

    interface ITag
    {
        start: number;
        end: number;
        category: Config.ICategory[];
    }

    function addStyle()
    {
        let style1 = document.createElement('style');
        Config.Categories.forEach(category =>
        {
            style1.innerText += `.tag-${category.cat}{background:${category.color};}\n`;
            //style1.innerText += `.tag-${category.cat}:after{content:"${category.cat}";}\n`;
        });
        document.body.appendChild(style1);
    }
    addStyle();

    export function createTaggedDisplay(elem: HTMLElement, txt: string)
    {
        let lowerText = txt.toLowerCase();
        let allTags: ITag[] = [];

        Config.Categories.forEach(category =>
        {
            category.words.forEach(wordInCat =>
            {
                var regex1 = new RegExp('(\\W|^)' + wordInCat + '(\\W|$)', 'g');

                var result1 = regex1.exec(lowerText);

                while (result1)
                {

                    let newPos = result1.index + 1;

                    let isMatch = false;
                    let thisTag: ITag = undefined;
                    for (var j = 0; j < allTags.length; j++)
                    {
                        thisTag = allTags[ j ];
                        if (thisTag.start == newPos)
                        {
                            isMatch = true;
                            break;
                        }
                    }

                    if (isMatch)
                    {
                        thisTag.category.push(category);
                    }
                    else
                    {
                        allTags.push({
                            category: [ category ],
                            start: newPos,
                            end: newPos + wordInCat.length
                        });
                    }
                    result1 = regex1.exec(lowerText);
                }

            });
        });

        allTags = allTags.sort((a, b) => a.start - b.start);

        let pos = 0;
        allTags.forEach(tag =>
        {
            // Get untagged
            let substring = txt.substring(pos, tag.start);
            let span = document.createElement('span');
            span.innerText = substring;
            span.className = 'tag';
            elem.appendChild(span);

            // Get tagged
            substring = txt.substring(tag.start, tag.end);
            span = document.createElement('mark');
            span.innerText = substring;
            span.className = `tag cattag ` + tag.category.map(cat => 'tag-' + cat.cat).join(' ');
            elem.appendChild(span);
            pos = tag.end;
        });

        if (pos < txt.length)
        {
            // Get last untagged
            let substring = txt.substring(pos, txt.length);
            let span = document.createElement('span');
            span.className = 'tag'
            span.innerText = substring;
            elem.appendChild(span);
        }
    }
}


/**
 * Author: Devarshi Hazarika
 * Spreadsheet.js 2.4.5
 */
namespace UI
{
    var filterFilteredIconSVG = `<svg class='handle-ico ico-filtered' width=13 height=13 style='cursor:pointer;position:absolute; right:0px;'>
        <g stroke='black' stroke-width=1>
            <path d='M2,3 h9 l-4,4 v4 h-1 v-4 z'></path>
        </g>
    </svg>`;

    var filterDropIconSVG = `<svg class='handle-ico ico-dropdown' width=13 height=13 style='cursor:pointer;position:absolute; right:0px;'>
        <g stroke-width=1>
            <line x1=6.5 y1=8.5 x2=3 y2=4.5></line>
            <line x1=6.5 y1=8.5 x2=10 y2=4.5></line>		
        </g>
    </svg>`;

    let def_cell_width = 100;
    let def_cell_height = 20;

    export class Spreadsheet
    {
        private _elem: HTMLElement;
        private _opts: spreadsheetOpts;
        private _vocp?: HTMLElement;
        private _focp?: HTMLElement;

        private col_header?: HTMLElement;
        private row_header?: HTMLElement;
        private cell_space?: HTMLElement;
        private corner_space?: HTMLElement;
        private scroll_space?: HTMLElement;
        private guid: string;

        // 4th quadrant cell_space handles
        private box4th: HTMLElement[];
        private cbox4th: HTMLElement[];

        // 3th quadrant cell_space handles
        private box3rd: HTMLElement[];
        private cbox3rd: HTMLElement[];

        private selectedCell?: ContainerElement;

        private sel_from: { x: number, y: number } = { x: -1, y: -1 };
        private sel_to: { x: number, y: number } = { x: -1, y: -1 };

        private $_icols: string[] = [];
        private $_irows: string[] = [];
        private $_data: { [ key: string ]: any };
        private $_copy_data: { [ key: string ]: any };

        private $_ta: HTMLTextAreaElement;
        private handle_mode: number = 0;

        private handle_pos_x: number = -1;
        private handle_pos_y: number = -1;

        private handle_del_x: number = -1;
        private handle_del_y: number = -1;

        private handle_cell_from: { x: number, y: number } = { x: -1, y: -1 };
        private handle_cell_to: { x: number, y: number } = { x: -1, y: -1 };

        private $_headers_infos: HTMLTableDataCellElement[][] = [];
        public CustomEditors: { [ field_type: string ]: { Editor: Editor_FN, Renderer?: Renderer_FN } };

        private readonlyCells: { guid: string, colname: string }[] = [];
        private boxesHidden = true;

        constructor(elem: HTMLElement, options: spreadsheetOpts)
        {
            this.guid = "guid-" + genGUID();
            this.$_data = {};
            this.$_copy_data = {};
            this._elem = elem;
            this._opts = options;
            if (options.renderHeader == null) options.renderHeader = true;

            this.$_genSpace();
            this.$_fillTables();
            this.$_genSels();

            options.columns.forEach(col =>
            {
                this._set_default_vals_to_cols(col);
                this._add_column(col);
            });

            if (options.renderHeader)
            {
                this._align_header_row_spans();
                this._align_header_col_spans();
                this._align_corner_heights();
            }
            this.$_resizeOCP();

            this._setfocusEve();

            if (!this._opts.width || !this._opts.height)
            {
                let rst: number = 0;
                let rst1: number = 0;
                let rst2: number = 0;

                rst1 = setTimeout(() =>
                {
                    this.$_resizeOCP();
                }, 1000);
                rst2 = setTimeout(() =>
                {
                    this.$_resizeOCP();
                }, 2000);
                rst2 = setTimeout(() =>
                {
                    this.$_resizeOCP();
                }, 3000);
                rst2 = setTimeout(() =>
                {
                    this.$_resizeOCP();
                }, 4000);

                window.addEventListener('resize', () =>
                {
                    this.$_resizeOCP();
                    clearTimeout(rst);
                    clearTimeout(rst1);
                    clearTimeout(rst2);
                    rst = setTimeout(() =>
                    {
                        this.$_resizeOCP();
                    }, 250);

                    rst1 = setTimeout(() =>
                    {
                        this.$_resizeOCP();
                    }, 1000);
                    rst2 = setTimeout(() =>
                    {
                        this.$_resizeOCP();
                    }, 5000);
                });
            }
        }

        private _set_default_vals_to_cols(col: Type_Column)
        {
            if (!col.Width)
            {
                if (this._opts.cellWidth)
                    col.Width = this._opts.cellWidth;
                else
                    col.Width = def_cell_width;
            }
        }

        private $_genSpace()
        {
            let elem: HTMLElement = this._elem;
            styleInjector({
                '.d_container':
                {
                    position: 'relative'
                },
                '.d_container>div':
                {
                    position: 'absolute',
                },
                '.d_container>.real_space':
                {
                    overflow: 'hidden',
                    width: '100%',
                    height: '100%'
                },
                '.d_container>.real_space>div':
                {
                    position: 'absolute',
                },
                '.d_container>.real_space>div>.def_table':
                {
                    'table-layout': 'fixed',
                    'border-collapse': 'collapse',
                    //width: '0px',
                    height: '0px',
                },
                '.d_container>.real_space>div.corner_div':
                {
                    top: '0px',
                    left: '0px',
                    "z-index": 3
                },
                '.d_container>.real_space>div.col_div':
                {
                    top: '0px',
                    "z-index": 3
                },
                '.d_container>.real_space>div.row_div':
                {
                    left: '0px',
                    "z-index": 3
                },
                '.d_container>.scroll_space':
                {
                    overflow: 'auto',
                    width: '100%',
                    height: '100%'
                },

                '.d_container>.d_ta':
                {
                    position: "absolute",
                    left: "0px",
                    top: "0px",
                },


            }, this.guid);

            let kelem = $d({
                elem: "div",
                props: { className: "d_container" },
                children: [
                    {
                        elem: "textarea",
                        props: { className: 'd_ta' }
                    },
                    {
                        elem: "div",
                        props: { className: "scroll_space" },
                        children: [
                            {
                                elem: "div",
                                props: { className: "virtual_occupier" }
                            }
                        ]
                    },
                    {
                        elem: "div",
                        props: { className: "real_space", tabIndex: "0" },
                        children: [
                            {
                                elem: "div",
                                props: { className: "cell_div" },
                                children: [
                                    {
                                        elem: "table",
                                        props: { className: "cell_space def_table" },
                                        children: [
                                            { elem: "tbody" }
                                        ]
                                    }
                                ]
                            },
                            {
                                elem: "div",
                                props: { className: "row_div" },
                                children: [
                                    {
                                        elem: "table",
                                        props: { className: "row_header def_table" },
                                        children: [
                                            { elem: "tbody" }
                                        ]
                                    }
                                ]
                            },
                            {
                                elem: "div",
                                props: { className: "col_div" },
                                children: [
                                    {
                                        elem: "table",
                                        props: { className: "col_header def_table" },
                                        children: [
                                            { elem: "tbody" }
                                        ]
                                    }
                                ]
                            },
                            {
                                elem: "div",
                                props: { className: "corner_div" },
                                children: [
                                    {
                                        elem: "table",
                                        props: { className: "corner_space def_table" },
                                        children: [
                                            {
                                                elem: "tbody",
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            });

            this.$_ta = kelem.querySelector(".d_ta");
            var span = document.createElement('div');
            span.id = this.guid;
            span.appendChild(kelem);
            elem.appendChild(span);

            this.scroll_space = this._vocp = kelem.querySelector('.d_container>.scroll_space') as HTMLElement;
            this._vocp = kelem.querySelector('.d_container>.scroll_space>.virtual_occupier') as HTMLElement;
            this._focp = kelem.querySelector('.d_container>.real_space') as HTMLElement;


            if (this._opts.width)
                kelem.style.width = this._opts.width + 'px';
            if (this._opts.height)
                kelem.style.height = this._opts.height + 'px';

            var real_space = this._elem.querySelector('.d_container>.real_space') as HTMLElement;
            var scroll_space = this.scroll_space;
            real_space.onmousewheel = (e) =>
            {
                scroll_space.scrollTop -= e.wheelDelta;
            }
        }

        private $_fillTables()
        {
            let elem: HTMLElement = this._elem;
            let options: spreadsheetOpts = this._opts;

            var ht = def_cell_height;
            var wd = def_cell_width;

            if (this._opts.cellWidth) wd = this._opts.cellWidth;
            if (this._opts.cellHeight) ht = this._opts.cellHeight;
            styleInjector({
                '.d_container':
                {
                    '-webkit-user-select': 'none',
                    '-khtml-user-select': 'none',
                    '-moz-user-select': 'none',
                    '-ms-user-select': 'none',
                    '-o-user-select': 'none',
                    'user-select': 'none',
                },
                '.d_container>.real_space>div.row_div':
                {
                    overflow: 'hidden'
                },
                '.d_container>.real_space>div>.def_table>tbody>tr>td>div>.seamless':
                {
                    border: '0px',
                    outline: 'none',
                    //height: ht + 'px',
                    //width: wd + 'px',
                },
                '.d_container>.real_space>div>.def_table>tbody>tr>td':
                {
                    outline: 'none',
                    'width': wd + 'px',
                    'max-width': wd + 'px',
                    'min-width': wd + 'px',

                    'height': ht + 'px',
                    'max-height': ht + 'px',
                    'min-height': ht + 'px',

                    'border': "1px solid #AAA",
                    'cursor': 'default',
                    "box-sizing": "border-box"
                },
                '.d_container>.real_space>div>.def_table>tbody>tr>td.sub-selected':
                {
                    'background': '#ddd'
                },
                '.d_container>.real_space>div>.def_table>tbody>tr>td>div':
                {
                    //'width': wd + 'px',
                    'height': ht + 'px',
                    'overflow': 'hidden',
                    'text-overflow': 'ellipsis'
                },

                '.d_container>.real_space>div>.def_table>tbody>tr>td>div>.seamless, .d_container>.real_space>div>.def_table>tbody>tr>td>div':
                {
                    font: "13px sans-serif",
                    padding: "0px",
                    resize: 'none',
                },

                '.d_container>.real_space>div>.def_table>tbody>tr>td>div.header-drop':
                {
                    height: 'auto',
                }
            }, this.guid);

            let col_header = elem.querySelector('.d_container>.real_space>div.col_div>.col_header>tbody') as HTMLElement;
            let row_header = elem.querySelector('.d_container>.real_space>div.row_div>.row_header>tbody') as HTMLElement;
            let cell_space = elem.querySelector('.d_container>.real_space>div.cell_div>.cell_space>tbody') as HTMLElement;
            let corner_space = elem.querySelector('.d_container>.real_space>div.corner_div>.corner_space>tbody') as HTMLElement;

            this.col_header = col_header;
            this.row_header = row_header;
            this.cell_space = cell_space;
            this.corner_space = corner_space;
            //this.$_resizeOCP();
        }

        /**
         * 
         * @param col_info Column Descriptor
         */
        addCol(col_info: Type_Column | Type_Column[])
        {
            var colArr: Type_Column[];
            if (col_info instanceof Array)
            {
                colArr = col_info;
            }
            else
            {
                colArr = [ col_info ];
            }

            colArr.forEach(col_info =>
            {
                this._opts.columns.push(col_info);
                this._set_default_vals_to_cols(col_info);
                this._add_column(col_info);
            });

            if (this._opts.renderHeader)
            {
                this._align_header_row_spans();
                this._align_header_col_spans();
                this._align_corner_heights();
            }

            colArr.forEach(col_info =>
            {
                let colIndex = this._opts.columns.indexOf(col_info);

                var tr_space: HTMLElement;
                if (colIndex < this._opts.col_freeze)
                    tr_space = this.row_header;
                else
                    tr_space = this.cell_space;

                for (var i = 0; i < tr_space.children.length; i++)
                {
                    var tr_i = tr_space.children[ i ];
                    var rowId = tr_i[ 'data-guid' ]
                    var obj = this.$_data[ rowId ];

                    var val = obj[ col_info.Field ];
                    if (!val) val = ' ';

                    var td = this._gen_cell(col_info, obj, rowId);
                    tr_i.appendChild(td);

                    if (colIndex == this._opts.col_freeze)
                    {
                        td.className = 'freeze-right-border';
                    }
                }
            })
            this.$_resizeOCP();
        }

        remCol(fieldName: string | string[])
        {
            let fnArr: string[];
            if (typeof fieldName == 'string') fnArr = [ fieldName ];
            else fnArr = fieldName;

            // remove readonlyCells
            for (let i = 0; i < this.readonlyCells.length; i++)
            {
                if (fnArr.indexOf(this.readonlyCells[ i ].colname) >= 0)
                {
                    this.readonlyCells.splice(i, 1);
                    i--;
                }
            }

            fnArr.forEach(fieldName =>
            {
                let colIndex = this.$_icols.indexOf(fieldName);
                var ci_to_remove = colIndex;

                let header_zone: HTMLElement;
                let cell_zone: HTMLElement;

                if (colIndex < this._opts.col_freeze)
                {
                    header_zone = this.corner_space;
                    cell_zone = this.row_header;
                }
                else
                {
                    header_zone = this.col_header;
                    cell_zone = this.cell_space;

                    colIndex -= this._opts.col_freeze;
                }

                let trElemLen: number;
                if (this._opts.renderHeader)
                {
                    trElemLen = header_zone.children.length;
                    for (let i = 0; i < trElemLen; i++)
                    {
                        let tr = header_zone.children[ i ] as HTMLTableRowElement;
                        let td = tr.children[ colIndex ] as HTMLTableDataCellElement;
                        if (td[ "ref" ])
                        {
                            let spanTd = td[ "ref" ] as HTMLTableDataCellElement;
                            if (spanTd.colSpan > 1)
                                spanTd.colSpan--;
                            else
                                spanTd.removeAttribute('colspan');

                        }
                        tr.removeChild(td);
                    }
                }

                trElemLen = cell_zone.children.length;

                for (let i = 0; i < trElemLen; i++)
                {
                    let tr = cell_zone.children[ i ];
                    let td = tr.children[ colIndex ];
                    tr.removeChild(td);
                }
                this.$_icols.splice(ci_to_remove, 1);
                this._opts.columns.splice(ci_to_remove, 1);
            });

            if (this._opts.renderHeader)
            {
                this._align_header_row_spans();
                this._align_header_col_spans();
                this._align_corner_heights();
            }

            this.$_resizeOCP();
        }

        private _add_column(col_info: Type_Column)
        {
            let icol = this.$_icols.length;
            this.$_icols.push(col_info.Field);

            let target_trs: HTMLElement;

            if (icol < this._opts.col_freeze)
                target_trs = this.corner_space;
            else
                target_trs = this.col_header;

            let c: Type_Column | Parent_Column = col_info;
            let titleArr = [];
            while (c)
            {
                titleArr.unshift(c.Title);
                c = c.Parent;
            }

            if (target_trs.children.length < titleArr.length)
            {
                let req = titleArr.length - target_trs.children.length;
                while (req-- > 0)
                {
                    let tr = $d({ elem: 'tr' });
                    target_trs.appendChild(tr);

                    if (target_trs == this.corner_space && target_trs.children.length == 1)
                    {
                        if (this._opts.renderHeader)
                        {
                            var thead = $d({ elem: 'td', props: { className: 'corner header left' } })
                            tr.appendChild(thead);
                        }

                    }

                }
            }

            var headers_info = [];
            this.$_headers_infos.push(headers_info);

            titleArr.forEach((title, i) =>
            {
                var header = $d({ elem: 'td', props: { className: 'header', field: col_info.Field } }) as HTMLElement;


                var lines = title.split('\n') as string[];
                header.innerText = lines.shift();

                lines.forEach(function (line)
                {
                    header.appendChild(document.createElement('br'));
                    header.appendChild(document.createTextNode(line));
                });

                header.col_info = col_info;
                if (col_info.Width)
                {
                    header.style.width = col_info.Width + 'px';
                    header.style.maxWidth = col_info.Width + 'px';
                    header.style.minWidth = col_info.Width + 'px';
                    header.style.overflow = 'hidden';
                    header.style.textOverflow = 'ellipsis';
                    header.style.whiteSpace = 'nowrap';
                }
                headers_info.push(header);
                if (this._opts.renderHeader)
                {
                    target_trs.children[ i ].appendChild(header);
                    header.style.position = 'relative';
                    if (i == titleArr.length - 1)
                    {
                        header.innerHTML += filterDropIconSVG;
                        header.setAttribute('handle-field', col_info.Field);
                        //@work

                        let ss = this;
                        header.onclick = function ()
                        {
                            let header = this as HTMLTableDataCellElement;

                            if (header.drop)
                            {
                                header.drop.parentElement.removeChild(header.drop);
                                delete header.drop;
                            }
                            else
                            {
                                [ ss.corner_space.parentElement.parentElement,
                                ss.col_header.parentElement.parentElement ].forEach(function (headerElem)
                                {
                                    var allOtherHeader = headerElem.querySelectorAll('.header-drop');
                                    for (var ik = 0; ik < allOtherHeader.length; ik++)
                                    {
                                        var ohed = allOtherHeader[ ik ];
                                        ohed.parentElement.removeChild(ohed);
                                        delete ohed.header.drop;
                                    }
                                });


                                let div = $d({ elem: 'div', style: { position: 'absolute' }, props: { className: 'header-drop' } });
                                let colInfo = (header as any).col_info as Type_Column;
                                let colIndex = ss.$_icols.indexOf(colInfo.Field);

                                let target: HTMLElement;

                                if (colIndex < ss._opts.col_freeze)
                                {
                                    target = ss.corner_space.parentElement.parentElement;
                                }
                                else
                                {
                                    target = ss.col_header.parentElement.parentElement;
                                }

                                header.drop = div;
                                div.header = header;
                                target.appendChild(div);

                                div.onmousewheel = function (e)
                                {
                                    e.cancelBubble = true;
                                }
                                ss._render_filterDropdown(div, colInfo)

                                div.style.left = header.offsetLeft + 'px';
                                div.style.top = (header.offsetTop + header.clientHeight) + 'px';
                                div.style.minWidth = header.clientWidth + 'px';
                            }
                        }
                    }
                }
            });
        }

        private _render_filterDropdown(container: HTMLElement, col_info: Type_Column)
        {
            var vals = [];

            var dummyCell = document.createElement('div') as any as ContainerElement;
            var dummyDiv = document.createElement('div') as any as ContainerElement;
            dummyCell.appendChild(dummyDiv);

            this._allRowId.forEach(rowId =>
            {
                var row = this._allData[ rowId ];

                if (col_info.FilterProvider)
                {
                    var options = col_info.FilterProvider({
                        column: col_info,
                        container: null,
                        doClear: false,
                        model: row,
                        rowId: rowId
                    });

                    options.forEach(opt =>
                    {
                        if (vals.indexOf(opt) == -1) vals.push(opt);
                    })
                }
                else
                {
                    var val;
                    getEditorRenderer(col_info).Renderer(dummyDiv,
                        {
                            column: col_info,
                            container: dummyDiv,
                            doClear: false,
                            model: row,
                            rowId: rowId
                        });
                    val = dummyCell.innerVal;
                    if (vals.indexOf(val) == -1)
                        vals.push(val);
                }

            });


            vals.sort((a, b) => { if (typeof a == 'string') a = a.toLowerCase().trim(); if (typeof b == 'string') b = b.toLowerCase().trim(); if (a < b) return -1; if (a > b) return 1; return 0; })

            let clearOpt = $d({ elem: 'div', props: { innerText: "Clear filter", colInfo: col_info } });
            container.appendChild(clearOpt);
            let ss = this;
            clearOpt.onclick = function ()
            {
                var colInfo = this.colInfo;
                ss.unset_filter(colInfo.Field);
                var col = this.parentElement.querySelectorAll('.selected');
                for (var ij = 0; ij < col.length; ij++)
                {
                    col[ ij ].classList.remove('selected');
                }
            }

            vals.forEach(val =>
            {
                if (val == null || val == '') return;
                let opt =
                    $d({
                        elem: 'div',
                        props: { innerText: val }
                    });

                if (this._filter[ col_info.Field ])
                {
                    if (this._filter[ col_info.Field ].indexOf(val) >= 0)
                    {
                        opt.className = 'selected';
                    }
                }

                container.appendChild(opt);
                opt.colInfo = col_info;
                opt.innerVal = val;

                opt.onclick = function ()
                {
                    ss.set_filter(this.colInfo.Field, this.innerVal);
                    this.className = '';
                    if (ss._filter[ this.colInfo.Field ])
                    {
                        if (ss._filter[ this.colInfo.Field ].indexOf(this.innerVal) >= 0)
                        {
                            this.className = 'selected';
                        }
                    }
                }

            })
        }

        private _align_header_row_spans()
        {
            var max_pre_freeze = 1;
            var max_post_freeze = 1;

            this.$_headers_infos.forEach((hci, i) =>
            {
                if (i < this._opts.col_freeze)
                {
                    if (max_pre_freeze < hci.length)
                        max_pre_freeze = hci.length;
                }
                else
                {
                    if (max_post_freeze < hci.length)
                        max_post_freeze = hci.length;
                }
            });

            var corner = this.corner_space.children[ 0 ].children[ 0 ] as HTMLTableDataCellElement
            corner.rowSpan = max_pre_freeze;

            var local_max = 0;
            this.$_headers_infos.forEach((hci, i) =>
            {
                if (i < this._opts.col_freeze)
                    local_max = max_pre_freeze;
                else
                    local_max = max_post_freeze;

                if (hci.length < local_max)
                {
                    hci[ 0 ].rowSpan = local_max - hci.length + 1;
                }
            });
        }

        private _align_header_col_spans()
        {
            var target_headers = [ this.corner_space, this.col_header ];

            target_headers.forEach(header_col =>
            {
                for (var i = 0; i < header_col.children.length; i++)
                {
                    let tr_i = header_col.children[ i ];
                    if (tr_i.children.length == 1)
                    {
                        var td_1 = tr_i.children[ 0 ] as HTMLTableDataCellElement;
                        var col_opt = (this._opts.columns[ this.$_icols.indexOf(td_1[ 'field' ]) ]);
                        td_1.style.width = col_opt.Width + 'px';
                        td_1.style.maxWidth = col_opt.Width + 'px';
                        td_1.style.minWidth = col_opt.Width + 'px';
                    }

                    for (var j = 1; j < tr_i.children.length; j++)
                    {
                        var td_1 = tr_i.children[ j - 1 ] as HTMLTableDataCellElement;
                        var td_2 = tr_i.children[ j ] as HTMLTableDataCellElement;

                        if (!td_1[ 'ref' ] && !td_1.colSpan)
                        {
                            var col_opt = (this._opts.columns[ this.$_icols.indexOf(td_1[ 'field' ]) ]);
                            td_1.style.width = col_opt.Width + 'px';
                            td_1.style.maxWidth = col_opt.Width + 'px';
                            td_1.style.minWidth = col_opt.Width + 'px';
                        }

                        if (!td_2[ 'ref' ])
                        {
                            if (td_1.rowSpan == td_2.rowSpan && td_1.innerText == td_2.innerText)
                            {
                                var td_ref: HTMLTableDataCellElement = td_1;
                                if (td_1[ 'ref' ])
                                    td_ref = td_1[ 'ref' ];

                                if (!td_ref.colSpan) td_ref.colSpan = 2;
                                else td_ref.colSpan++;

                                var ind_from = this.$_icols.indexOf(td_ref[ 'field' ]);
                                var ind_to = this.$_icols.indexOf(td_2[ 'field' ]);

                                var calc_width = 0;
                                for (; ind_from <= ind_to; ind_from++)
                                    calc_width += this._opts.columns[ ind_from ].Width;

                                td_ref.style.width = calc_width + 'px';
                                td_ref.style.maxWidth = calc_width + 'px';
                                td_ref.style.minWidth = calc_width + 'px';
                                td_ref.align = 'center';

                                td_2[ 'ref' ] = td_ref;
                                td_2.style.display = 'none';
                            }
                        }
                        else
                        {
                            var td_ref = td_2[ 'ref' ] as HTMLTableDataCellElement;
                            var calc_width = 0;

                            var ind_from = this.$_icols.indexOf(td_ref[ 'field' ]);
                            var ind_to = this.$_icols.indexOf(td_2[ 'field' ]);

                            var calc_width = 0;
                            for (; ind_from <= ind_to; ind_from++)
                                calc_width += this._opts.columns[ ind_from ].Width;

                            td_ref.style.width = calc_width + 'px';
                            td_ref.style.maxWidth = calc_width + 'px';
                            td_ref.style.minWidth = calc_width + 'px';
                            td_ref.align = 'center';

                            td_2[ 'ref' ] = td_ref;
                            td_2.style.display = 'none';
                        }
                    }
                }
            });
        }

        private _align_corner_heights()
        {
            try
            {
                let firstFreezeCorner = this.corner_space.children[ 0 ].children[ 0 ] as HTMLTableDataCellElement;
                let firstColumnCorner = this.col_header.children[ 0 ].children[ 0 ] as HTMLTableDataCellElement;

                firstFreezeCorner.style.height = '';
                firstColumnCorner.style.height = '';

                var rec1 = this.corner_space.getBoundingClientRect();
                var rec2 = this.col_header.getBoundingClientRect();

                if (rec1.height > rec2.height)
                {

                    firstColumnCorner.style.height = (def_cell_height + rec1.height - rec2.height) + 'px';
                }
                else if (rec2.height > rec1.height)
                {
                    firstFreezeCorner.style.height = (def_cell_height + rec2.height - rec1.height) + 'px';
                }
            }
            catch (ex)
            {

            }
        }

        private $_genSels()
        {
            styleInjector({
                ".box": { "border": "1px solid", "position": "absolute", "z-index": "2" },
                ".copybox": { "border": "1px dashed", "position": "absolute", "z-index": "2" },
                ".box .box-top,.copybox .box-top": { "border-left": "0px", "border-right": "0px", "border-bottom": "0px" },
                ".box .box-left,.copybox .box-left": { "border-top": "0px", "border-right": "0px", "border-bottom": "0px" },
                ".box .box-right,.copybox .box-right": { "border-left": "0px", "border-top": "0px", "border-bottom": "0px" },
                ".box .box-bottom,.copybox .box-bottom": { "border-left": "0px", "border-right": "0px", "border-top": "0px" },
                ".handle": { position: "absolute", width: "5px", height: "5px", background: "black", border: "1px solid white", "z-index": 2, "cursor": "crosshair" }
            }, this.guid);

            this.box4th = [
                $d({ elem: "div", props: { className: "box box-top" } }),
                $d({ elem: "div", props: { className: "box box-right" } }),
                $d({ elem: "div", props: { className: "box box-bottom" } }),
                $d({ elem: "div", props: { className: "box box-left" } }),
                $d({ elem: "div", props: { className: "handle" } })
            ];
            this.cbox4th = [
                $d({ elem: "div", props: { className: "copybox box-top" } }),
                $d({ elem: "div", props: { className: "copybox box-right" } }),
                $d({ elem: "div", props: { className: "copybox box-bottom" } }),
                $d({ elem: "div", props: { className: "copybox box-left" } }),
            ];

            this.box3rd = [
                $d({ elem: "div", props: { className: "box box-top" } }),
                $d({ elem: "div", props: { className: "box box-right" } }),
                $d({ elem: "div", props: { className: "box box-bottom" } }),
                $d({ elem: "div", props: { className: "box box-left" } }),
                $d({ elem: "div", props: { className: "handle" } })
            ]
            this.cbox3rd = [
                $d({ elem: "div", props: { className: "copybox box-top" } }),
                $d({ elem: "div", props: { className: "copybox box-right" } }),
                $d({ elem: "div", props: { className: "copybox box-bottom" } }),
                $d({ elem: "div", props: { className: "copybox box-left" } }),
            ];

            let cell_space_div = this.cell_space.parentElement.parentElement;

            this.box4th.forEach(box =>
            {
                cell_space_div.appendChild(box);
                box.style.display = 'none';
            });

            this.cbox4th.forEach(copy_box =>
            {
                cell_space_div.appendChild(copy_box);
                copy_box.style.display = 'none';
            });

            let row_header_div = this.row_header.parentElement.parentElement;
            this.box3rd.forEach(box =>
            {
                row_header_div.appendChild(box);
                box.style.display = 'none';
            });
            this.cbox3rd.forEach(copy_box =>
            {
                row_header_div.appendChild(copy_box);
                copy_box.style.display = 'none';
            });

            this.box3rd[ 4 ].onmousedown = this.box4th[ 4 ].onmousedown = (e) =>
            {
                this.handle_mode = 1;
                this.handle_pos_x = e.pageX;
                this.handle_pos_y = e.pageY;

                if (this.sel_from.x !== -1 && this.sel_from.y !== -1 && this.sel_to.x !== -1 && this.sel_to.y !== -1)
                {
                    this.handle_cell_from.x = this.sel_from.x;
                    this.handle_cell_from.y = this.sel_from.y;

                    this.handle_cell_to.x = this.sel_to.x;
                    this.handle_cell_to.y = this.sel_to.y;
                }
                else
                {
                    let selIndex = this.getCellIndex(this.selectedCell);
                    this.handle_cell_from.x = selIndex.x;
                    this.handle_cell_from.y = selIndex.y;
                    this.handle_cell_to.x = selIndex.x;
                    this.handle_cell_to.y = selIndex.y;

                    this.sel_from.x = selIndex.x;
                    this.sel_from.y = selIndex.y;
                    this.sel_to.x = selIndex.x;
                    this.sel_to.y = selIndex.y;
                }
            }

            this._elem.onmouseup = (e) =>
            {
                if (this.handle_mode > 0)
                {
                    this.handle_mode = 0;
                    this.cbox4th.forEach(box => { box.style.display = 'none'; });
                    this.cbox3rd.forEach(box => { box.style.display = 'none'; });
                    this._execute_fill_handle();
                }
            }

            this.box3rd[ 4 ].onmouseup = this.box4th[ 4 ].onmouseup = this._elem.onmouseup;
        }

        private _execute_fill_handle()
        {
            this.handle_mode = 0;
            this.$_renderSelected();
            if (Math.abs(this.handle_del_x) > Math.abs(this.handle_del_y))
            {
                //Horizontal Fill
                let min = this.sel_from.x;
                let max = this.sel_to.x;
                let req = 0;
                if (min == this.handle_cell_from.x)
                {
                    req = max - this.handle_cell_to.x;
                }
                else
                {
                    req = min - this.handle_cell_from.x;
                }

                // ForEach rows
                for (var iy = this.handle_cell_from.y; iy <= this.handle_cell_to.y; iy++)
                {
                    // Collect column series in x axis
                    let arr = [];
                    for (var ix = this.handle_cell_from.x; ix <= this.handle_cell_to.x; ix++)
                    {
                        let td = this.getCellFromIndex(ix, iy);
                        arr.push(td.innerVal);
                    }

                    if (req > 0)
                    {
                        // Fill rightwards
                        let series = identify_series(arr, req);
                        for (ix = this.handle_cell_to.x + 1; ix <= this.sel_to.x; ix++)
                        {
                            this.$_set_cell_val(ix, iy, series.shift());
                        }
                    }
                    else
                    {
                        //Fill leftwards
                        let series = identify_series(arr.reverse(), req * -1);
                        for (ix = this.handle_cell_from.x - 1; ix >= this.sel_from.x; ix--)
                        {
                            this.$_set_cell_val(ix, iy, series.shift());
                        }
                    }
                }
            }
            else
            {
                //Vertical Fill
                let min = this.sel_from.y;
                let max = this.sel_to.y;
                let req = 0;
                if (min == this.handle_cell_from.y)
                {
                    req = max - this.handle_cell_to.y;
                }
                else
                {
                    req = min - this.handle_cell_from.y;
                }

                // ForEach columns
                for (var ix = this.handle_cell_from.x; ix <= this.handle_cell_to.x; ix++)
                {
                    // Collect row series in y axis
                    let arr = [];
                    for (var iy = this.handle_cell_from.y; iy <= this.handle_cell_to.y; iy++)
                    {
                        let td = this.getCellFromIndex(ix, iy);
                        arr.push(td.innerVal);
                    }

                    if (req > 0)
                    {
                        // Fill downwards
                        let series = identify_series(arr, req);
                        for (iy = this.handle_cell_to.y + 1; iy <= this.sel_to.y; iy++)
                        {
                            this.$_set_cell_val(ix, iy, series.shift());
                        }
                    }
                    else
                    {
                        // Fill upwards
                        let series = identify_series(arr.reverse(), req * -1);
                        for (iy = this.handle_cell_from.y - 1; iy >= this.sel_from.y; iy--)
                        {
                            this.$_set_cell_val(ix, iy, series.shift());
                        }
                    }
                }
            }
        }

        private _recordRow(rowId: string)
        {
            var obj = this.$_data[ rowId ];
            var prev_obj = {};

            var keyList = [];
            this._opts.columns.forEach(col =>
            {
                prev_obj[ col.Field ] = obj[ col.Field ];
                keyList.push(col.Field);
            });

            return {
                copy: prev_obj,
                detect: (avoid?: string) =>
                {
                    this._opts.columns.forEach(col =>
                    {
                        if (col.Field == avoid) return;
                        if (prev_obj[ col.Field ] != obj[ col.Field ])
                        {
                            let cellX = this.$_icols.indexOf(col.Field);
                            let cellY = this.$_irows.indexOf(rowId);

                            this.$_set_cell_val(cellX, cellY, obj[ col.Field ]);
                        }
                    });
                }
            }
        }

        private $_set_cell_val(x: number, y: number, val: any, overrideReadonly: boolean = false)
        {
            let td = this.getCellFromIndex(x, y);
            let containerDiv = td.children[ 0 ] as ContainerElement;
            let fieldName = td[ "data-field" ] as string;
            let rowId = td.parentElement[ 'data-guid' ] as string;

            if (!overrideReadonly)
            {
                for (var i = 0; i < this.readonlyCells.length; i++)
                {
                    var roc = this.readonlyCells[ i ];
                    if (roc.colname == fieldName && roc.guid == rowId)
                    {
                        return;
                    }
                }
            }

            let columnObject = this._opts.columns[ this.$_icols.indexOf(fieldName) ];
            let rowItem = this.$_data[ rowId ];

            var recInfo = this._recordRow(rowId);

            var hasChange = false;
            if (rowItem[ fieldName ] != val)
            {
                hasChange = true;
                rowItem[ fieldName ] = val;
                if (typeof this._opts.onBeforeChange == 'function')
                    this._opts.onBeforeChange({ container: containerDiv, doClear: false, rowId: rowId, column: columnObject, model: rowItem });
            }



            getEditorRenderer(columnObject).Renderer(containerDiv, { rowId: rowId, doClear: false, container: containerDiv, model: rowItem, column: columnObject });

            if (hasChange)
            {
                if (typeof this._opts.onAfterChange == 'function')
                    this._opts.onAfterChange({ rowId: rowId, doClear: false, container: containerDiv, column: columnObject, model: rowItem });
            }

            recInfo.detect(fieldName);
        }

        private $_drawSelectBox(box: HTMLElement[], x: number, y: number, w: number, h: number)
        {
            w--;
            h--;
            box.forEach(box => { box.style.display = '' });
            box[ 0 ].style.top = y + 'px';
            box[ 0 ].style.left = x + 'px';
            box[ 0 ].style.width = w + 'px';
            box[ 0 ].style.height = '0px';

            box[ 1 ].style.left = (x + w) + 'px';
            box[ 1 ].style.top = y + 'px';
            box[ 1 ].style.width = '0px';
            box[ 1 ].style.height = h + 'px';

            box[ 2 ].style.left = x + 'px';
            box[ 2 ].style.top = y + h + 'px';
            box[ 2 ].style.width = w + 'px';
            box[ 2 ].style.height = '0px';

            box[ 3 ].style.left = x + 'px';
            box[ 3 ].style.top = y + 'px';
            box[ 3 ].style.width = '0px';
            box[ 3 ].style.height = h + 'px';

            box[ 4 ].style.left = x + w - 2 + 'px';
            box[ 4 ].style.top = y + h - 2 + 'px';
        }

        private $_resizeOCP()
        {
            var rec1 = this.corner_space.parentElement.parentElement.getBoundingClientRect();
            var rec2 = this.cell_space.parentElement.parentElement.getBoundingClientRect();
            var rec3 = this.row_header.parentElement.parentElement.getBoundingClientRect();
            var rec4 = this.col_header.parentElement.parentElement.getBoundingClientRect();

            this._vocp.style.width = rec1.width + rec2.width + 'px';
            this._vocp.style.height = rec1.height + rec2.height + 'px';

            var scroll_space = this.scroll_space;
            var real_space = this._elem.querySelector('.d_container>.real_space') as HTMLElement;


            this.col_header.parentElement.parentElement.style.left = rec1.width - 1 + 'px';
            this.row_header.parentElement.parentElement.style.top = rec1.height - 1 + 'px';
            this.cell_space.parentElement.parentElement.style.left = rec3.width - 1 + 'px';
            this.cell_space.parentElement.parentElement.style.top = rec4.height - 1 + 'px';

            real_space.style.width = scroll_space.clientWidth + 'px';
            real_space.style.height = scroll_space.clientHeight + 'px';

            scroll_space.onscroll = (e) =>
            {
                let sx = rec1.width - 1 - scroll_space.scrollLeft + 'px';
                let sy = rec1.height - 1 - scroll_space.scrollTop + 'px';

                this.col_header.parentElement.parentElement.style.left = sx;
                this.row_header.parentElement.parentElement.style.top = sy;
                this.cell_space.parentElement.parentElement.style.left = sx;
                this.cell_space.parentElement.parentElement.style.top = sy;
            }
        }

        setRowClasses(rowId: string, className: string)
        {
            var row_index = this.$_irows.indexOf(rowId);
            var cellSpaceRow = this.cell_space.children[ row_index ];
            var rowHeaderRow = this.row_header.children[ row_index ];

            cellSpaceRow.className = className;
            rowHeaderRow.className = className;

            if (typeof this._opts.rowClassField == 'string')
            {
                this.$_data[ rowId ][ this._opts.rowClassField ] = className;
            }
        }

        /**
         * 
         * @param obj row rep
         */
        addRow(obj: any, suggestedGuid: string = null, doResizeOCP: boolean = true)
        {
            var guid: string = '';
            if (suggestedGuid)
            {
                guid = suggestedGuid;
            }
            else
            {
                guid = genGUID();
            }

            if (this._allRowElem[ guid ])
            {
                // Elem already exists;
                let row_header_tr = this._allRowElem[ guid ].rowHeader;
                let cell_space_tr = this._allRowElem[ guid ].cellSpace;

                this.row_header.appendChild(row_header_tr);
                this.cell_space.appendChild(cell_space_tr);
            }
            else
            {
                // Elems doesn't exists
                let row_header_tr = ($d({ elem: "tr", props: { 'data-guid': guid }, children: [ { elem: 'td', props: { className: "left" } } ] })) as HTMLTableRowElement;
                let cell_space_tr = $d({ elem: 'tr', props: { 'data-guid': guid } }) as HTMLTableRowElement;

                this._allRowElem[ guid ] = { rowHeader: row_header_tr, cellSpace: cell_space_tr };

                if (typeof this._opts.rowClassField == 'string' && typeof obj[ this._opts.rowClassField ] == 'string')
                {
                    row_header_tr.className = obj[ this._opts.rowClassField ];
                    cell_space_tr.className = obj[ this._opts.rowClassField ];
                }

                this._opts.columns.forEach((col, i) =>
                {
                    var td = this._gen_cell(col, obj, guid);

                    if (i < this._opts.col_freeze)
                    {
                        row_header_tr.appendChild(td);
                        if (i == this._opts.col_freeze - 1)
                            td.className = 'freeze-right-border';
                    }
                    else
                        cell_space_tr.appendChild(td);
                });



                if (this._allData[ guid ] == undefined)
                    this._allData[ guid ] = obj;
                if (this._allRowId.indexOf(guid) == -1)
                    this._allRowId.push(guid);

                this.row_header.appendChild(row_header_tr);
                this.cell_space.appendChild(cell_space_tr);
            }

            if (doResizeOCP)
                this.$_resizeOCP();

            this.$_data[ guid ] = obj;
            let copy_obj = {};
            this.$_copy_data[ guid ] = copy_obj

            Object.keys(obj).forEach(key => copy_obj[ key ] = obj[ key ]);

            this.$_irows.push(guid);
            return guid;
        }

        /**
         * 
         * @param guid guid of row
         */
        remRow(guid: string)
        {
            var ind_row = this.$_irows.indexOf(guid);
            this.$_irows.splice(ind_row, 1);
            delete this.$_data[ guid ];

            this.row_header.removeChild(this.row_header.children[ ind_row ]);
            this.cell_space.removeChild(this.cell_space.children[ ind_row ]);
        }

        /**
         * get records that were changed
         */
        get_delta_records()
        {
            var isSame = true;
            var deltaRecords: { fields: string[], record: any }[] = [];
            this.$_irows.forEach(row_id =>
            {
                var newObj = this.$_data[ row_id ];
                var oldObj = this.$_copy_data[ row_id ];
                isSame = true;
                var fields = [];


                this._opts.columns.forEach(col =>
                {
                    if (oldObj[ col.Field ] != newObj[ col.Field ])
                    {
                        isSame = false;
                        fields.push(col.Field);
                    }

                });

                if (!isSame)
                {
                    deltaRecords.push({ fields: fields, record: newObj });
                }
            });
            return deltaRecords;
        }

        /**
         * reset change check
         */
        reset_deltas()
        {
            this.$_irows.forEach(rowid =>
            {
                var obj1 = this.$_data[ rowid ];
                var obj2 = this.$_copy_data[ rowid ];

                var keys1 = Object.keys(obj1);
                var keys2 = Object.keys(obj2);

                keys2.forEach(key =>
                {
                    if (keys1.indexOf(key) == -1) delete obj2[ key ];
                })

                keys1.forEach(key =>
                {
                    obj2[ key ] = obj1[ key ];
                });
            });
        }


        /**
         * undo changes
         */
        revert_delta_records()
        {
            var isSame = true;
            var count = 0;

            this.$_irows.forEach((row_id, y) =>
            {
                var newObj = this.$_data[ row_id ];
                var oldObj = this.$_copy_data[ row_id ];
                isSame = true;

                this._opts.columns.forEach((col, x) =>
                {
                    if (oldObj[ col.Field ] != newObj[ col.Field ])
                    {
                        isSame = false;
                        newObj[ col.Field ] = oldObj[ col.Field ];

                        this.$_set_cell_val(x, y, newObj[ col.Field ]);
                    }
                });

                if (!isSame)
                    count++;

            });
            return count;
        }

        private $_refocus()
        {
            if (document.activeElement != this._focp)
            {
                this._focp.focus();
            }
        }
        private $_renderSelected()
        {
            if (this.boxesHidden)
            {
                this.boxesHidden = false;
                this.box3rd.forEach(box => box.style.display = '');
                this.box4th.forEach(box => box.style.display = '');
            }

            if (this.handle_mode == 1)
            {
                // code for marking the source for fill handle
                this.cbox4th.forEach((box, i) =>
                {
                    box.style.display = ''
                    copyPos(this.box4th[ i ], this.cbox4th[ i ]);
                });
                this.cbox3rd.forEach((box, i) =>
                {
                    box.style.display = ''
                    copyPos(this.box3rd[ i ], this.cbox3rd[ i ]);
                });
                this.handle_mode = 2;
            }

            if (this.handle_mode == 0)
            {
                // selection of range/cell
                if (this.sel_from.x !== -1 && this.sel_from.y !== -1 && this.sel_to.x !== -1 && this.sel_to.y !== -1)
                {
                    //range selection
                    let td_From = this.getCellFromIndex(this.sel_from.x, this.sel_from.y);
                    let td_To = this.getCellFromIndex(this.sel_to.x, this.sel_to.y);

                    let rec1 = this.getCellRelativeCoords(td_From);
                    let rec2 = this.getCellRelativeCoords(td_To);

                    if (this.sel_to.x < this._opts.col_freeze)
                    {
                        //draw selection box before freeze
                        this.$_drawSelectBox(this.box3rd, rec1.left, rec1.top, rec2.left + rec2.width - rec1.left, rec2.top + rec2.height - rec1.top);
                        this.box4th.forEach(box => box.style.display = 'none');
                    }
                    else if (this.sel_from.x >= this._opts.col_freeze)
                    {
                        //draw selection box after freeze
                        this.$_drawSelectBox(this.box4th, rec1.left, rec1.top, rec2.left + rec2.width - rec1.left, rec2.top + rec2.height - rec1.top);
                        this.box3rd.forEach(box => box.style.display = 'none');
                    }
                    else
                    {
                        //draw selection box accros freeze
                        let freeze_col_left_cell = this.getCellFromIndex(this._opts.col_freeze - 1, this.sel_to.y);
                        let margin_rec_before = this.getCellRelativeCoords(freeze_col_left_cell);

                        let freeze_col_right_cell = this.getCellFromIndex(this._opts.col_freeze, this.sel_from.y);
                        let margin_rec_after = this.getCellRelativeCoords(freeze_col_right_cell);

                        this.$_drawSelectBox(this.box3rd, rec1.left, rec1.top, margin_rec_before.left + margin_rec_before.width - rec1.left + 10, margin_rec_before.top + margin_rec_before.height - rec1.top);
                        this.$_drawSelectBox(this.box4th, margin_rec_after.left - 10, margin_rec_after.top, rec2.left + rec2.width - margin_rec_after.left + 10, rec2.top + rec2.height - margin_rec_after.top);
                    }

                }
                else
                {
                    //cell selection
                    let selCoords = this.getCellIndex(this.selectedCell);

                    if (selCoords.x < this._opts.col_freeze)
                    {
                        let rec1 = this.getCellRelativeCoords(this.selectedCell);
                        this.$_drawSelectBox(this.box3rd, rec1.left, rec1.top, rec1.width, rec1.height);
                        this.box4th.forEach(box => box.style.display = 'none');
                    }
                    else
                    {
                        let rec1 = this.getCellRelativeCoords(this.selectedCell);
                        this.$_drawSelectBox(this.box4th, rec1.left, rec1.top, rec1.width, rec1.height);
                        this.box3rd.forEach(box => box.style.display = 'none')
                    }
                }
                this.$__classifySelected();
            }
            else if (this.handle_mode == 2)
            {
                //fill handle dragging
                let from_x = this.sel_from.x;
                let from_y = this.sel_from.y;
                let to_x = this.sel_to.x;
                let to_y = this.sel_to.y;

                if (Math.abs(this.handle_del_x) > Math.abs(this.handle_del_y))
                {
                    //horizontal
                    this.sel_from.y = this.handle_cell_from.y;
                    this.sel_to.y = this.handle_cell_to.y;
                }
                else
                {
                    //vertical
                    this.sel_from.x = this.handle_cell_from.x;
                    this.sel_to.x = this.handle_cell_to.x;
                }

                let td_From = this.getCellFromIndex(this.sel_from.x, this.sel_from.y);
                let td_To = this.getCellFromIndex(this.sel_to.x, this.sel_to.y);

                let rec1 = this.getCellRelativeCoords(td_From);
                let rec2 = this.getCellRelativeCoords(td_To);

                if (this.sel_to.x < this._opts.col_freeze)
                {
                    this.$_drawSelectBox(this.box3rd, rec1.left, rec1.top, rec2.left + rec2.width - rec1.left, rec2.top + rec2.height - rec1.top);
                }
                else if (this.sel_from.x >= this._opts.col_freeze)
                {
                    this.$_drawSelectBox(this.box4th, rec1.left, rec1.top, rec2.left + rec2.width - rec1.left, rec2.top + rec2.height - rec1.top);
                }
                else
                {
                    let freeze_col_left_cell = this.getCellFromIndex(this._opts.col_freeze - 1, this.sel_to.y);
                    let margin_rec_before = this.getCellRelativeCoords(freeze_col_left_cell);

                    let freeze_col_right_cell = this.getCellFromIndex(this._opts.col_freeze, this.sel_from.y);
                    let margin_rec_after = this.getCellRelativeCoords(freeze_col_right_cell);

                    this.$_drawSelectBox(this.box3rd, rec1.left, rec1.top, margin_rec_before.left + margin_rec_before.width - rec1.left + 10, margin_rec_before.top + margin_rec_before.height - rec1.top);
                    this.$_drawSelectBox(this.box4th, margin_rec_after.left - 10, margin_rec_after.top, rec2.left + rec2.width - margin_rec_after.left + 10, rec2.top + rec2.height - margin_rec_after.top);
                }

            }
        }

        private _setfocusEve()
        {
            let prevent = false;
            let avoid = false;

            var fnTab = (e: KeyboardEvent) =>
            {
                var prevent = false;
                var acceptableKeycodes = [ 9, 39, 37, 13, 38, 40 ];
                if (acceptableKeycodes.indexOf(e.keyCode) >= 0) // TAB
                {
                    prevent = true;
                    if (this.selectedCell)
                    {
                        let minX = 0;
                        let maxX = this._opts.columns.length - 1;
                        let minY = 0;
                        let maxY = this.$_irows.length - 1;

                        if (this.sel_from && this.sel_to && this.sel_from.x !== -1 && this.sel_from.y !== -1 && this.sel_to.x !== -1 && this.sel_to.y !== -1)
                        {
                            minX = this.sel_from.x;
                            minY = this.sel_from.y;

                            maxX = this.sel_to.x;
                            maxY = this.sel_to.y;
                        }

                        let coords = this.getCellIndex(this.selectedCell);

                        if ((!e.shiftKey && e.keyCode == 9) || e.keyCode == 39) // go right
                        {
                            if (coords.x < maxX)
                                coords.x++;
                            else if (coords.y < maxY)
                            {
                                coords.x = minX;
                                coords.y++;
                            }
                            else
                            {
                                coords.x = minX;
                                coords.y = minY;
                            }
                        }
                        if ((e.shiftKey && e.keyCode == 9) || e.keyCode == 37) // go left
                        {
                            if (coords.x > minX)
                                coords.x--;
                            else if (coords.y > minY)
                            {
                                coords.x = maxX;
                                coords.y--;
                            }
                            else
                            {
                                coords.x = maxX;
                                coords.y = maxY;
                            }
                        }

                        if ((e.shiftKey && e.keyCode == 13) || e.keyCode == 38) //go up
                        {
                            if (coords.y > 0)
                            {
                                coords.y -= 1;
                            }
                        }

                        if ((!e.shiftKey && e.keyCode == 13 || e.keyCode == 40))
                        {
                            if (coords.y <= maxY)
                                coords.y++;
                        }

                        this.selectedCell = this.getCellFromIndex(coords.x, coords.y);
                        this.$_renderSelected();
                    }
                    this._scrollaccord();
                    this.$_refocus()
                }
                return !prevent;
            }

            var fne = (e: KeyboardEvent) =>
            {
                if (e.target != this._focp) return;

                prevent = false;
                avoid = false;

                prevent = !fnTab(e);

                if (e.keyCode == 46) // Delete
                {
                    var ci = this.getCellIndex(this.selectedCell);
                    this.$_set_cell_val(ci.x, ci.y, "");
                }

                if (e.keyCode == 67 && e.ctrlKey) // ^C
                {
                    if (this.box4th[ 0 ].style.display != 'none')
                    {
                        this.cbox4th.forEach((box, i) =>
                        {
                            copyPos(this.box4th[ i ], box)
                            box.style.display = '';
                        });
                    }
                    else
                    {
                        this.cbox4th.forEach((box) => box.style.display = 'none');
                    }

                    if (this.box3rd[ 0 ].style.display != 'none')
                    {
                        this.cbox3rd.forEach((box, i) =>
                        {
                            copyPos(this.box3rd[ i ], box)
                            box.style.display = '';
                        });
                    }
                    else
                    {
                        this.cbox3rd.forEach((box) => box.style.display = 'none');
                    }

                    this.box4th.forEach(box =>
                    {
                        box.style.display = 'none';
                    });
                    this.box3rd.forEach(box =>
                    {
                        box.style.display = 'none';
                    });


                    prevent = true;
                    if (this.selectedCell && this.selectedCell.innerVal)
                    {
                        if (this.sel_from.x == -1 || this.sel_from.y == -1 || this.sel_to.x == -1 || this.sel_to.y == -1)
                        {
                            if (this.selectedCell.innerVal)
                            {
                                this.$_ta.value = this.selectedCell.innerVal;
                                this.$_ta.select();
                                document.execCommand("copy");
                                this.$_refocus()
                            }
                        }
                        else
                        {
                            let str = "";
                            for (let y = this.sel_from.y; y <= this.sel_to.y; y++)
                            {
                                if (y != this.sel_from.y)
                                    str += '\n';
                                for (let x = this.sel_from.x; x <= this.sel_to.x; x++)
                                {
                                    let td1 = this.getCellFromIndex(x, y);
                                    if (x != this.sel_from.x) str += "\t";
                                    if (td1.innerVal)
                                    {
                                        str += td1.innerVal;
                                    }
                                    else
                                    {
                                        str += "";
                                    }
                                }
                            }

                            this.$_ta.value = str;
                            this.$_ta.select();
                            document.execCommand("copy");
                            this.$_refocus()

                        }

                    }
                }
                if (e.keyCode == 86 && e.ctrlKey) // ^V
                {
                    avoid = true;
                    if (this.selectedCell)
                    {
                        this.$_ta.value = '';
                        this.$_ta.focus();
                        this.$_ta.onkeyup = () =>
                        {
                            this.$_ta.onkeyup = null;
                            this.$_refocus()
                            var lines = this.$_ta.value.trim().split("\n");

                            let reqX = 0;
                            let reqY = lines.length;

                            var data: string[][] = [];

                            lines.forEach(row =>
                            {
                                var cells = row.split("\t");
                                data.push(cells);
                                reqX = Math.max(cells.length, reqX);
                            });

                            let cellIndex = this.getCellIndex(this.selectedCell);
                            let availX = this._opts.columns.length - cellIndex.x;
                            let availY = this.$_irows.length - cellIndex.y;

                            if (availX >= reqX && availY >= reqY)
                            {
                                for (let ry = 0; ry < reqY; ry++)
                                {
                                    for (let rx = 0; rx < data[ ry ].length; rx++)
                                    {
                                        this.$_set_cell_val(rx + cellIndex.x, ry + cellIndex.y, data[ ry ][ rx ]);
                                    }
                                }

                                this.sel_from.x = cellIndex.x;
                                this.sel_from.y = cellIndex.y;

                                this.sel_to.x = cellIndex.x + reqX - 1;
                                this.sel_to.y = cellIndex.y + reqY - 1;

                                this.$_renderSelected();
                                this.cbox4th.forEach(box => box.style.display = 'none');
                                this.cbox3rd.forEach(box => box.style.display = 'none');
                            }
                            else
                            {
                                alert('area not enough');
                            }
                        }
                    }
                }

                if (e.keyCode == 27) // Escape
                {

                    if (this.box4th[ 0 ].style.display == 'none' && this.box3rd[ 0 ].style.display == 'none')
                    {
                        if (this.cbox4th[ 0 ].style.display != 'none')
                            this.box4th.forEach(box => { box.style.display = ''; });

                        if (this.cbox3rd[ 0 ].style.display != 'none')
                            this.box3rd.forEach(box => { box.style.display = ''; });
                    }

                    this.cbox4th.forEach(box => { box.style.display = 'none'; });
                    this.cbox3rd.forEach(box => { box.style.display = 'none'; });
                }

                if (!e.ctrlKey && !prevent && !avoid && (e.key.length == 1 || e.key == 'F2'))// Edit mode
                {
                    var doClear = true;
                    if (e.key == "F2")
                    {
                        doClear = false;
                    }
                    this.invoke_edit_mode(doClear);
                }
                //console.log(e.keyCode, e.key);

                if (prevent)
                {
                    e.cancelBubble = true;
                    e.preventDefault();
                }
            }

            this._elem.onkeydown = (e) =>
            {
                if (!fnTab(e))
                {
                    e.preventDefault();
                    e.cancelBubble = true;
                    return false;
                }

            }

            this._focp.onkeydown = fne;



            // this._vocp.onblur=()=>
            // {
            //     this.box3rd.forEach(box=>box.style.display='none');
            //     this.box4th.forEach(box=>box.style.display='none');
            // }

        }

        private invoke_edit_mode(doClear: boolean)
        {
            var div = this.selectedCell.children[ 0 ] as ContainerElement;


            var field = this.selectedCell[ "data-field" ];
            var rowId = this.selectedCell.parentElement[ "data-guid" ];

            var goAhead = true;
            for (let i = 0; i < this.readonlyCells.length && goAhead; i++)
            {
                var roc = this.readonlyCells[ i ];
                if (roc.colname == field && roc.guid == rowId)
                {
                    goAhead = false;
                }
            }
            if (goAhead)
            {
                var model = this.$_data[ rowId ];
                let colInfo = this._opts.columns[ this.$_icols.indexOf(field) ];
                let Editor_Renderer = getEditorRenderer(colInfo);

                let EditorOpt: EditorOptions = {
                    container: div,
                    rowId: rowId,
                    column: colInfo,
                    model: model,
                    doClear: doClear,
                }

                var recInfo = this._recordRow(rowId);

                if (typeof this._opts.onBeforeEdit == 'function')
                    this._opts.onBeforeEdit(EditorOpt);

                Editor_Renderer.Editor(div, EditorOpt, () =>
                {
                    if (typeof this._opts.onBeforeChange == 'function')
                        if (model[ field ] != recInfo.copy[ field ])
                            this._opts.onBeforeChange(EditorOpt);

                    this.$_refocus();
                    Editor_Renderer.Renderer(div, EditorOpt);

                    if (typeof this._opts.onAfterChange == 'function')
                        if (model[ field ] != recInfo.copy[ field ])
                            this._opts.onAfterChange(EditorOpt);

                    recInfo.detect(field);
                });

                if (typeof this._opts.onAfterEdit == 'function')
                    this._opts.onAfterEdit(EditorOpt);
            }
        }

        make_cell_readonly(rowId: string, colname: string, status: boolean = true)
        {
            if (status)
            {
                var doAdd = true;
                for (var i = 0; i < this.readonlyCells.length && doAdd; i++)
                {
                    var roc = this.readonlyCells[ i ];
                    if (roc.colname == colname && roc.guid == rowId)
                    {
                        doAdd = false;
                        break;
                    }
                }
                if (doAdd)
                {
                    this.readonlyCells.push({ guid: rowId, colname: colname });
                }

                var rowNum = this.$_irows.indexOf(rowId);
                var colNum = this.$_icols.indexOf(colname);

                var cell = this.getCellFromIndex(colNum, rowNum)
                cell.classList.add('dcell-readonly');
            }
            else
            {
                for (let i = 0; i < this.readonlyCells.length; i++)
                {
                    var roc = this.readonlyCells[ i ];
                    if (roc.colname == colname && roc.guid == rowId)
                    {
                        this.readonlyCells.splice(i, 1);
                        break;
                    }
                }
                var rowNum = this.$_irows.indexOf(rowId);
                var colNum = this.$_icols.indexOf(colname);

                var cell = this.getCellFromIndex(colNum, rowNum)
                cell.classList.remove('dcell-readonly');

            }
        }

        make_col_readonly(colName: string, status: boolean)
        {
            this.$_irows.forEach(rowId =>
            {
                this.make_cell_readonly(rowId, colName, status);
            })
        }

        make_row_readonly(rowId: string, status: boolean)
        {
            this.$_icols.forEach(colname =>
            {
                this.make_cell_readonly(rowId, colname, status);
            })
        }

        private getCellRelativeCoords(td1: HTMLElement)
        {
            //Element's Rec
            var rec1 = td1.getBoundingClientRect();

            //Quadrant's div's Rec
            var rec2 = td1.parentElement.parentElement.parentElement.parentElement.getBoundingClientRect();

            var rec3 = {
                left: rec1.left - rec2.left,
                top: rec1.top - rec2.top,
                width: rec1.width,
                height: rec1.height
            }

            return rec3;
        }

        private getCellIndex(td1: HTMLElement)
        {
            let tr1 = td1.parentElement as HTMLTableRowElement;

            let colField = td1[ "data-field" ] as string;
            let rowId = tr1[ "data-guid" ] as string;

            let x = this.$_icols.indexOf(colField);
            let y = this.$_irows.indexOf(rowId);
            return { x: x, y: y };
        }

        private getCellFromIndex(x: number, y: number): ContainerElement
        {
            if (x < this._opts.col_freeze)
            {
                return this.row_header.children[ y ].children[ x + 1 ] as ContainerElement;
            }
            else
            {
                return this.cell_space.children[ y ].children[ x - this._opts.col_freeze ] as ContainerElement;
            }
        }

        private $__clearClasses()
        {
            let allSels = this.cell_space.querySelectorAll('.sub-selected') as NodeListOf<HTMLElement>;
            let i: number;
            for (i = 0; i < allSels.length; i++)
            {
                class_remove(allSels[ i ], 'sub-selected');
            }

            if (this._opts.col_freeze > 0)
            {
                allSels = this.row_header.querySelectorAll('.sub-selected') as NodeListOf<HTMLElement>;
                for (i = 0; i < allSels.length; i++)
                {
                    class_remove(allSels[ i ], 'sub-selected');

                }
            }
        }

        private $__classifySelected()
        {
            this.$__clearClasses();
            if (this.sel_from && this.sel_to && this.sel_from.x !== -1 && this.sel_from.y !== -1 && this.sel_to.x !== -1 && this.sel_to.y !== -1)
            {
                for (let y = this.sel_from.y; y <= this.sel_to.y; y++)
                {
                    for (let x = this.sel_from.x; x <= this.sel_to.x; x++)
                    {
                        let td1 = this.getCellFromIndex(x, y);
                        if (td1 != this.selectedCell)
                        {
                            class_add(td1, 'sub-selected');
                        }
                    }
                }
            }
        }

        private _gen_cell(col: Type_Column, obj: any, rowId: string)
        {
            var idiv = $d({ elem: 'div' }) as ContainerElement;
            var td = $d({ elem: 'td', props: { 'data-field': col.Field } });
            if (col.Width)
            {
                td.style.width = col.Width + 'px';
                td.style.maxWidth = col.Width + 'px';
                td.style.minWidth = col.Width + 'px';
            }
            td.appendChild(idiv);

            let Editor_Renderer = getEditorRenderer(col);
            Editor_Renderer.Renderer(idiv, { container: idiv, doClear: false, model: obj, column: col, rowId: rowId });

            td.onmousedown = (e) =>
            {
                if (this.handle_mode > 0) this.handle_mode = 0;

                this.sel_from.x = -1;
                this.sel_from.y = -1;
                this.sel_to.x = -1;
                this.sel_to.y = -1;
                let td1 = e.currentTarget as ContainerElement;
                this.selectedCell = td1;

                this.$_renderSelected();
                //this.$_refocus()
            }

            td.ondblclick = (e) =>
            {
                this.invoke_edit_mode(false);
            }

            td.onmouseup = () =>
            {
                this.$_refocus()
            }

            td.onmouseenter = (e) =>
            {
                if (e.buttons > 0 && e.button == 0 && this.selectedCell)
                {
                    let td1 = e.currentTarget as HTMLElement;

                    let fromXY = this.getCellIndex(this.selectedCell);
                    let toXY = this.getCellIndex(td1);

                    let minX = Math.min(fromXY.x, toXY.x);
                    let maxX = Math.max(fromXY.x, toXY.x);

                    let minY = Math.min(fromXY.y, toXY.y);
                    let maxY = Math.max(fromXY.y, toXY.y);

                    this.sel_from.x = minX;
                    this.sel_from.y = minY;

                    this.sel_to.x = maxX;
                    this.sel_to.y = maxY;

                    this.$_renderSelected();
                }
            };

            td.onmousemove = (e) =>
            {
                if (e.buttons > 0 && e.button == 0)
                {
                    this.handle_del_x = e.pageX - this.handle_pos_x;
                    this.handle_del_y = e.pageY - this.handle_pos_y;
                }
            }
            return td;
        }

        private _allRowId: string[] = [];
        private _allData: any = {};
        private _allRowElem: { [ rowId: string ]: { rowHeader: HTMLTableRowElement, cellSpace: HTMLTableRowElement } } = {}
        private _filter: any = {};

        do_filter()
        {
            var dowork = () =>
            {
                //remove each data;
                var toRemove = [];
                toRemove.push.apply(toRemove, this.$_irows);
                toRemove.forEach(row_id => this.remRow(row_id));

                let colsIQ = Object.keys(this._filter);
                var dummyCell = document.createElement('div') as any as ContainerElement;
                var dummyDiv = document.createElement('div') as any as ContainerElement;
                dummyCell.appendChild(dummyDiv);

                //for each row
                this._allRowId.forEach(row_id =>
                {
                    let isRowMatch = true;

                    //check match
                    let row = this._allData[ row_id ];
                    colsIQ.forEach(colName =>
                    {
                        let colIndex = this.$_icols.indexOf(colName)
                        let colInfo = this._opts.columns[ colIndex ];
                        let valsToMatch = this._filter[ colName ];

                        if (valsToMatch)
                        {
                            var svgHolder = document.querySelector('[handle-field="' + colName + '"]');
                            var svg = svgHolder.querySelector('.handle-ico.ico-dropdown');
                            if (svg)
                            {
                                svgHolder.removeChild(svg);
                                svgHolder.innerHTML += filterFilteredIconSVG;
                            }
                            var anyMatch = false;
                            valsToMatch.forEach(function (valToMatch)
                            {
                                if (colInfo.FilterMatch)
                                {
                                    var isRowMatch2 = colInfo.FilterMatch(valToMatch, {
                                        column: colInfo,
                                        container: null,
                                        doClear: false,
                                        model: row,
                                        rowId: row_id
                                    });
                                    if (isRowMatch2) anyMatch = true;
                                }
                                else
                                {
                                    getEditorRenderer(colInfo).Renderer(dummyDiv, {
                                        column: colInfo,
                                        container: dummyDiv,
                                        doClear: false,
                                        model: row,
                                        rowId: row_id
                                    });
                                    let rowVal = dummyCell.innerVal;

                                    if (valToMatch == rowVal)
                                    {
                                        anyMatch = true;
                                    }
                                }
                            });

                            if (!anyMatch)
                                isRowMatch = false;
                        }
                        else
                        {
                            var svgHolder = document.querySelector('[handle-field="' + colName + '"]');
                            var svg = svgHolder.querySelector('.handle-ico.ico-filtered');
                            if (svg)
                            {
                                svgHolder.removeChild(svg);
                                svgHolder.innerHTML += filterDropIconSVG;
                            }
                        }
                    });


                    //add back
                    if (isRowMatch)
                    {
                        this.addRow(row, row_id, false);
                    }
                });

                setTimeout(() =>
                {
                    this.$_resizeOCP();
                }, 100);
            };

            requestAnimationFrame(dowork);
            //dowork();
        }

        unset_filter(colName)
        {
            delete this._filter[ colName ];
            var svgHolder = document.querySelector('#' + this.guid + ' [handle-field="' + colName + '"]');
            var svgIcon = svgHolder.querySelector('.handle-ico.ico-filtered');
            if (svgIcon)
            {
                svgHolder.removeChild(svgIcon);
                svgHolder.innerHTML += filterDropIconSVG;
            }
            delete this._filter[ colName ];
            this.do_filter();
        }

        set_filter(colName: string, value: string)
        {
            var dofilter = true;
            if (!this._filter[ colName ]) this._filter[ colName ] = [];
            var arr = this._filter[ colName ];
            if (arr.indexOf(value) == -1) arr.push(value);
            else
            {
                arr.splice(arr.indexOf(value), 1);
                if (arr.length == 0)
                {
                    this.unset_filter(colName);
                    dofilter = false;
                }
            }
            if (dofilter)
                this.do_filter();
        }

        /**
         * 
         * @param obj array of objects holding data.
         */
        set_data(obj: any[])
        {
            //clear filter copy
            this._allRowId.length = 0;
            Object.keys(this._allData).forEach(key => delete this._allData[ key ]);

            this.$_irows.forEach(row_id => this.remRow(row_id));
            obj.forEach(row => this.addRow(row));

            //copy for filter
            //this.$_irows.forEach(irow => this._unfilteredRowId.push(irow));
            //Object.keys(this.$_data).forEach(key => this._allData[key] = this.$_data[key]);
        }

        re_render(rowId: string, fieldName: string)
        {
            var icol = this.$_icols.indexOf(fieldName);
            var irow = this.$_irows.indexOf(rowId);

            if (icol == -1)
            {
                console.warn(fieldName + ' column is not known to spreadsheet for re_render.');
                return;
            }
            if (irow == -1)
            {
                console.warn(rowId + ' row is not known to spreadsheet for re_render.');
                return;
            }

            var colInfo = this._opts.columns[ icol ]
            var record = this.$_data[ rowId ];
            var cell = this.getCellFromIndex(icol, irow);
            var div = cell.firstElementChild as ContainerElement;

            getEditorRenderer(colInfo).Renderer(div, {
                rowId: rowId,
                column: colInfo,
                container: div,
                doClear: false,
                model: record
            })
        }
        private _scrollaccord()
        {
            //@debug

            //if scrolling up is required ?
            var beginHeight = 0;
            var boxUpperPoint = this.selectedCell.offsetTop - this.scroll_space.scrollTop;
            if (boxUpperPoint < beginHeight)
            {
                var delY = boxUpperPoint - beginHeight;
                this.scroll_space.scrollTop += delY;
                //console.log('crossed up');
            }

            //if scrolling down is required ?
            var availableHeight = this._focp.clientHeight - this.col_header.clientHeight;
            var boxLowerPoint = this.selectedCell.offsetTop + this.selectedCell.clientHeight - this.scroll_space.scrollTop;
            if (boxLowerPoint > availableHeight)
            {
                var delY = boxLowerPoint - availableHeight + 2;
                this.scroll_space.scrollTop += delY;
                //console.log('crossed down');
            }


            //if scrolling right is required ?
            var boxRightPoint = this.selectedCell.offsetLeft + this.selectedCell.clientWidth - this.scroll_space.scrollLeft;
            var availableWidth = this._focp.clientWidth - this.row_header.clientWidth;
            if (boxRightPoint > availableWidth)
            {
                var delX = boxRightPoint - availableWidth + 2;
                this.scroll_space.scrollLeft += delX;
            }

            //if scrolling left is required ?
            var cellIndex = this.getCellIndex(this.selectedCell);
            if (cellIndex.x >= this._opts.col_freeze)
            {
                var beginLeft = 0;
                var boxLeftPoint = this.selectedCell.offsetLeft - this.scroll_space.scrollLeft;
                if (boxLeftPoint < beginLeft)
                {
                    var delX = boxLeftPoint - beginLeft;
                    this.scroll_space.scrollLeft += delX;
                }
            }
        }

        exportToExcel()
        {
            var table = document.createElement('table');
            var thead = document.createElement('thead');
            table.appendChild(thead);

            var tr = document.createElement('tr');
            thead.appendChild(tr);

            for (var i = 0; i < this._opts.columns.length; i++)
            {
                var th = document.createElement('th');
                th.innerText = this._opts.columns[ i ].Title;
                tr.appendChild(th);
            }

            var tbody = document.createElement('tbody');
            table.appendChild(tbody);

            this.$_irows.forEach((rowId, i) =>
            {
                tr = document.createElement('tr');
                tbody.appendChild(tr);
                var data = this.$_data[ rowId ];
                this._opts.columns.forEach((c, j) =>
                {
                    var elem: HTMLTableDataCellElement;
                    if (j < this._opts.col_freeze)
                    {
                        elem = this.row_header.children[ i ].children[ 1 + j ] as HTMLTableDataCellElement;
                    }
                    else
                    {
                        elem = this.cell_space.children[ i ].children[ j - this._opts.col_freeze ] as HTMLTableDataCellElement;
                    }

                    //var td = document.createElement('td');
                    //td.innerText = elem.innerText;
                    var td = elem.cloneNode(true);
                    tr.appendChild(td)
                });
            });
            ExportToExcelTable(table.outerHTML);
            debugger;
        }
    }

    interface Parent_Column
    {
        Title: string,
        Parent?: Parent_Column;
    }

    export type Type_Column = TC_SimpleText | TC_Dropdown | TC_Number

    export interface TC_SimpleText
    {
        Field: string;
        Title?: string;
        Type?: "SimpleText";
        Editor?: Editor_FN;
        Renderer?: Renderer_FN;
        Parent?: Parent_Column;
        Width?: number;

        FilterProvider?: (options: EditorOptions) => string[];
        FilterMatch?: (valueToMatch: string, options: EditorOptions) => boolean;
    }

    export interface TC_Dropdown
    {
        Field: string;
        Title?: string;
        Type: "Options";
        Editor?: Editor_FN;
        Renderer?: Renderer_FN;
        Parent?: Parent_Column;
        Width?: number;

        Options?: any[];
        ValueField?: string;
        DisplayField?: string;

        FilterProvider?: (options: EditorOptions) => string[];
        FilterMatch?: (valueToMatch: string, options: EditorOptions) => boolean;
    }

    export interface TC_Number
    {
        Field: string;
        Title?: string;
        Type: "Number";
        Editor?: Editor_FN;
        Renderer?: Renderer_FN;
        Parent?: Parent_Column;
        Width?: number;
        FormaterFn?: (val: number) => string;

        FilterProvider?: (options: EditorOptions) => string[];
        FilterMatch?: (valueToMatch: string, options: EditorOptions) => boolean;
    }

    export interface spreadsheetOpts
    {
        columns: Type_Column[];
        width?: number;
        height?: number;
        cellHeight?: number;
        cellWidth?: number;
        col_freeze?: number;
        rowClassField?: string;
        renderHeader?: boolean;

        onBeforeEdit?: (arg: EditorOptions) => void;
        onAfterEdit?: (arg: EditorOptions) => void;
        onBeforeChange?: (arg: EditorOptions) => void;
        onAfterChange?: (arg: EditorOptions) => void;
    }


    interface EditorOptions
    {
        container: HTMLElement,
        rowId: string,
        model: any;
        column: Type_Column;
        doClear: boolean;
    }

    interface $d_opt
    {
        elem: string;
        children?: $d_opt[];
        attrs?: any;
        props?: any;
        style?: any;
    }

    interface ContainerElement extends HTMLElement
    {
        innerVal: string;
        parentElement: ContainerElement;
    }

    type Renderer_FN = (container: ContainerElement, options: EditorOptions) => void;
    type Editor_FN = (container: ContainerElement, options: EditorOptions, over: Function) => void;


    function identify_series(vals: string[], len: number): string[]
    {
        let isSequence = vals.length > 1;
        let ret: string[] = [];

        // Reasons sequence
        if (isSequence)
        {
            let numericPattern = /(\D*)(\d+)/;
            let alphaSequence: string[] = [];
            let alphaPattern: { [ key: string ]: number[] } = {};
            let alphaDeltas: { [ key: string ]: number } = {};

            // Identify series
            for (var i = 0; i < vals.length && isSequence; i++)
            {
                var thisVal = vals[ i ];
                var thisParts = numericPattern.exec(thisVal);
                if (!thisParts)
                {
                    isSequence = false;
                    break;
                }

                alphaSequence.push(thisParts[ 1 ]);

                if (!alphaPattern[ thisParts[ 1 ] ]) alphaPattern[ thisParts[ 1 ] ] = [];

                let alphaArr = alphaPattern[ thisParts[ 1 ] ];
                alphaArr.push(parseInt(thisParts[ 2 ]));

                if (alphaArr.length > 1)
                {
                    let prev_val = alphaArr[ alphaArr.length - 2 ];
                    let this_val = alphaArr[ alphaArr.length - 1 ];

                    let del_sign = this_val - prev_val;
                    del_sign = del_sign / Math.abs(del_sign);

                    if (alphaDeltas[ thisParts[ 1 ] ] === undefined)
                        alphaDeltas[ thisParts[ 1 ] ] = del_sign;

                    if (alphaDeltas[ thisParts[ 1 ] ] !== del_sign)
                        alphaDeltas[ thisParts[ 1 ] ] = 0;
                }
            }

            if (isSequence)
            {
                let ind = 0;
                let diffs: { [ sym: string ]: number } = {};
                let lastVal: { [ sym: string ]: number } = {};

                Object.keys(alphaPattern).forEach(syms =>
                {
                    let first = alphaPattern[ syms ][ 0 ];
                    let last = alphaPattern[ syms ][ alphaPattern[ syms ].length - 1 ];
                    if (alphaPattern[ syms ].length > 1)
                    {
                        if (alphaDeltas[ syms ] !== 0)
                        {
                            let diff = (last - first) / (alphaPattern[ syms ].length - 1);
                            diffs[ syms ] = diff;
                            alphaDeltas[ syms ] = diff;
                        }
                    }
                    else
                    {
                        alphaDeltas[ syms ] = 0;
                    }
                    lastVal[ syms ] = last;
                });

                while (len-- > 0)
                {
                    let syms = alphaSequence[ ind ];
                    ind = ++ind % alphaSequence.length;
                    if (alphaDeltas[ syms ] !== 0)
                    {
                        let del = alphaDeltas[ syms ];
                        lastVal[ syms ] += del;
                        ret.push(syms + lastVal[ syms ]);
                    }
                    else
                    {
                        ret.push(syms + lastVal[ syms ]);
                    }
                }

                return ret;
            }
        }
        if (!isSequence)
        {
            let ind = 0;
            while (len-- > 0)
            {
                ret.push(vals[ ind ]);

                ind = ++ind % vals.length;
            }
            return ret;
        }
    }

    function genGUID()
    {
        var str = "0123456789abcdef";
        var lens = [ 8, 4, 4, 4, 12 ];
        var acc = "";

        for (var i = 0; i < lens.length; i++)
        {
            if (i != 0) acc += '-';
            for (var k = 0; k < lens[ i ]; k++)
            {
                acc += str.charAt(Math.floor(Math.random() * 16))
            }
        }
        return acc;
    }

    function copyPos(fr: HTMLElement, to: HTMLElement)
    {
        to.style.left = fr.style.left;
        to.style.top = fr.style.top;
        to.style.width = fr.style.width;
        to.style.height = fr.style.height;
    }

    function clearChildren(elem: HTMLElement)
    {
        for (var i = 0; i < elem.childNodes.length; i++)
        {
            elem.removeChild(elem.childNodes[ i ]);
        }
    }

    function $d(opt: $d_opt): HTMLElement
    {
        let elem = document.createElement(opt.elem) as any;

        if (opt.attrs)
        {
            Object.keys(opt.attrs).forEach(key =>
            {
                elem.setAttribute(key, opt.attrs[ key ]);
            })
        }

        if (opt.props)
        {
            Object.keys(opt.props).forEach(key =>
            {
                elem[ key ] = opt.props[ key ];
            });
        }

        if (opt.style)
        {
            Object.keys(opt.style).forEach(key =>
            {
                elem.style[ key ] = opt.style[ key ];
            });
        }

        if (opt.children && opt.children.length > 0)
        {
            for (let i = 0; i < opt.children.length; i++)
            {
                elem.appendChild($d(opt.children[ i ]));
            }
        }

        return elem;
    }

    function class_remove(elem: HTMLElement, className: string)
    {
        elem.className = elem.className.split(className).join(' ').replace(/\s{2,}/g, ' ').trim();
        if (elem.className.trim() == '')
            elem.removeAttribute('class');
    }

    function class_add(elem: Element, className: string)
    {
        if (elem.className.indexOf(className) == -1)
        {
            elem.className += ' ' + className;
        }
    }

    let css_style = document.createElement('style');

    document.head.insertBefore(css_style, document.head.firstElementChild);

    function styleInjector(style: any, guid: string | null = null)
    {
        if (!guid) guid = '';
        else guid = "#" + guid;
        let css_style_text = "";
        Object.keys(style).forEach(key =>
        {
            css_style_text += guid + " " + key + " {";
            Object.keys(style[ key ]).forEach(key2 =>
            {
                css_style_text += key2 + ":" + style[ key ][ key2 ] + ";";
            });
            css_style_text += "}\r\n";
        });

        css_style.innerHTML += css_style_text;
    }

    function getEditorRenderer(col: Type_Column)
    {
        let ret: { Editor: Editor_FN, Renderer: Renderer_FN } = {
            Editor: _$Def_Editor_Render.SimpleText.Editor,
            Renderer: _$Def_Editor_Render.SimpleText.Renderer,
        }

        if (col.Type && _$Def_Editor_Render[ col.Type ])
        {
            var Editor_Renderer = _$Def_Editor_Render[ col.Type ];
            if (Editor_Renderer.Renderer)
                ret.Renderer = Editor_Renderer.Renderer;
            if (Editor_Renderer.Editor)
                ret.Editor = Editor_Renderer.Editor;
        }

        if (col.Editor)
            ret.Editor = col.Editor;

        if (col.Renderer)
            ret.Renderer = col.Renderer;

        var rendererFn = ret.Renderer;
        ret.Renderer = function (container: ContainerElement, options: EditorOptions)
        {
            delete container.parentElement.innerVal;
            clearChildren(container);
            rendererFn(container, options);
        }

        var editorFn = ret.Editor;
        ret.Editor = function (container: ContainerElement, options: EditorOptions, overFn: Function)
        {
            clearChildren(container);
            editorFn(container, options, overFn);
        }
        return ret;
    }

    export let _$Def_Editor_Render: { [ field_type: string ]: { Editor: Editor_FN, Renderer?: Renderer_FN } } = {
        "SimpleText": {
            Renderer: function (container: ContainerElement, options: EditorOptions)
            {
                var val = options.model[ options.column.Field ];
                if (val != null)
                {
                    container.innerText = val;
                    container.parentElement.innerVal = val;
                }
                else
                {
                    container.innerText = ""
                    container.parentElement.innerVal = null;
                }
            },

            Editor: function (container: ContainerElement, options: EditorOptions, over: Function)
            {
                var val = options.model[ options.column.Field ];

                var ta = $d({ elem: "input", props: { type: "text", className: "seamless" } }) as HTMLInputElement;
                container.appendChild(ta);
                ta.focus();

                if (val != null && !options.doClear)
                {
                    ta.value = val;
                    // ta.selectionStart=0;
                    // ta.selectionEnd= ta.value.length;
                }
                ta.onchange = function ()
                {
                    let self: HTMLInputElement = this as HTMLInputElement;
                    if (self.value && self.value.trim() != "")
                    {
                        options.model[ options.column.Field ] = self.value;
                    }
                    else
                        options.model[ options.column.Field ] = null;
                }
                ta.onblur = function ()
                {
                    over();
                }
            }
        },
        "Options": {
            Renderer: function (container: ContainerElement, options: EditorOptions)
            {
                if (options.column.Type != 'Options') return;
                var val = options.model[ options.column.Field ];
                var dispVal = val;

                if (options.column.DisplayField && options.column.ValueField && val != null)
                {
                    for (var i = 0; i < options.column.Options.length; i++)
                    {
                        if (options.column.Options[ i ][ options.column.ValueField ] == val)
                        {
                            dispVal = options.column.Options[ i ][ options.column.DisplayField ];
                            break;
                        }
                    }
                }

                if (options.column.DisplayField && options.column.ValueField == null && val != null)
                {
                    dispVal = val[ options.column.DisplayField ];
                }

                if (dispVal)
                {
                    container.innerText = dispVal;
                    container.parentElement.innerVal = dispVal;
                }
                else
                {
                    container.innerText = ""
                    container.parentElement.innerVal = null;
                }
            },
            Editor: function (container, opt, over)
            {
                if (opt.column.Type != 'Options') return;
                container.innerHTML = "<select style='width:100%'></select>";

                var sel = container.querySelector('select');

                opt.column.Options.forEach((opt1, i) =>
                {
                    if (opt.column.Type != 'Options') return;
                    var opt_elem = document.createElement('option');
                    var display;
                    var value = i.toString();

                    if (typeof opt1 == 'object' && opt.column.DisplayField)
                    {
                        display = opt1[ opt.column.DisplayField ];
                    }
                    else if (typeof opt1 == 'string')
                    {
                        display = opt1;
                    }

                    opt_elem.value = value;
                    opt_elem.innerText = display;

                    sel.appendChild(opt_elem);
                });

                sel.onmouseup = (e) => { e.cancelBubble = true };
                sel.focus();

                if (opt.model[ opt.column.Field ] && !opt.doClear)
                {
                    if (opt.column.ValueField)
                    {
                        var val = opt.model[ opt.column.Field ];

                        for (var i = 0; i < opt.column.Options.length; i++)
                        {
                            if (opt.column.Options[ i ][ opt.column.ValueField ] == val)
                            {
                                sel.value = i.toString();
                                break;
                            }
                        }
                    }
                    else
                    {
                        sel.value = opt.column.Options.indexOf(opt.model[ opt.column.Field ]).toString();
                    }
                }
                else
                {
                    sel.selectedIndex = -1;
                }

                sel.onchange = (e) =>
                {
                    if (opt.column.Type != 'Options') return;
                    var obj = opt.column.Options[ parseInt(sel.value) ];
                    var val;
                    if (opt.column.ValueField)
                    {
                        val = obj[ opt.column.ValueField ]
                    }
                    else
                    {
                        val = obj;
                    }
                    opt.model[ opt.column.Field ] = val;
                }

                sel.onblur = (e) =>
                {
                    over();
                }
            }
        },
        "Number": {

            Renderer: function (container: ContainerElement, options: EditorOptions)
            {
                var dispVal = options.model[ options.column.Field ];
                if (typeof dispVal != 'number')
                {
                    try
                    {
                        dispVal = parseFloat(dispVal);
                    }
                    catch (ex)
                    {
                        dispVal = '';
                        delete options.model[ options.column.Field ];
                    }
                }
                if (options.column.Type != 'Number') return;

                if (dispVal)
                {
                    container.parentElement.innerVal = dispVal;
                    if (typeof options.column.FormaterFn == 'function')
                    {
                        dispVal = options.column.FormaterFn(dispVal);
                    }
                    container.innerText = dispVal;
                }
                else
                {
                    container.innerText = ""
                    container.parentElement.innerVal = '';
                }
            },

            Editor: function (container, options, over)
            {
                var val = options.model[ options.column.Field ];

                var ta = $d({ elem: "input", props: { type: "text", className: "seamless" } }) as HTMLInputElement;

                container.appendChild(ta);
                ta.focus();

                if (val && !options.doClear)
                {
                    ta.value = val;
                    // ta.selectionStart=0;
                    // ta.selectionEnd= ta.value.length;
                }

                ta.onkeypress = function (e)
                {
                    var inp1 = this as HTMLInputElement;
                    var validPattern = /^\-?\d*\.?\d*$/;

                    var val = inp1.value;
                    var pos1 = inp1.selectionStart;
                    var pos2 = inp1.selectionEnd;
                    var left = val.substring(0, pos1);
                    var right = val.substring(pos2 + 1, val.length);

                    if (e.key.length == 1)
                    {
                        val = left + e.key + right;
                        if (!validPattern.test(val))
                        {
                            e.preventDefault();
                            e.cancelBubble = true;
                            return false;
                        }
                    }
                }
                ta.onchange = function ()
                {
                    let self: HTMLInputElement = this as HTMLInputElement;
                    if (self.value && self.value.trim() != "")
                    {
                        options.model[ options.column.Field ] = parseFloat(self.value);
                    }
                    else
                        options.model[ options.column.Field ] = null;
                }
                ta.onblur = function ()
                {
                    over();
                }
            }
        }


    };

    function Repeat<ktype>(obj: ktype, length: number): ktype[]
    {
        var ret: ktype[] = [];
        while (length-- > 0)
        {
            ret.push(obj);
        }

        return ret;
    }


    function ExportToExcelTable(mainTable)
    {
        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");

        var tab_text = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="">';
        tab_text = tab_text + '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
        tab_text = tab_text + '<head><!--[if gte mso 9]>';
        tab_text = tab_text + '<xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Sheet0</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml>';
        tab_text = tab_text + '<![endif]-->';
        tab_text = tab_text + '</head><body>';
        tab_text = tab_text + mainTable;
        tab_text = tab_text + '</body></html>';

        tab_text = [ tab_text ];
        var blob1 = new Blob(tab_text, { type: "text/html" });
        if (typeof msie !== "undefined" && msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
        {

            if (typeof Blob !== "undefined")
            {
                window.navigator.msSaveBlob(blob1, 'download.xls');
            }
            // else
            // {
            //     txtArea1.document.open("text/html", "replace");
            //     txtArea1.document.write(tab_text);
            //     txtArea1.document.close();
            //     txtArea1.focus();
            //     sa = txtArea1.document.execCommand("SaveAs", true, 'download.xls');
            // }
        }
        else
        {
            var url1 = URL.createObjectURL(blob1);
            var a = document.createElement('a');
            a.href = url1;

            a.download = 'download.xls';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);

            window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));

        }
    }

}

var ss = new UI.Spreadsheet(document.querySelector('div'),
    {
        height: 400,
        cellHeight: 40,
        columns: [
            {
                Field: 'PatentNum',
                Title: 'Patent no.'
            },
            {
                Field: 'Title',
                Title: 'Title',
            },
            {
                Field: 'Details',
                Title: 'Description',
                Width: 400,
            },
            {
                Field: 'Date',
                Title: 'Date',
            },
            {
                Field: 'Url',
                Title: 'Link',
                Renderer: (c, o) =>
                {
                    var link = o.model[ o.column.Field ]
                    c.innerHTML = `<a target='_blank' href='${link}'>${link}</a>`
                }
            },
            {
                Field: 'Score',
                Title: 'Score',
                Width: 50
            },
            {
                Field: 'popup',
                Title: 'Details',
                Renderer: (c, o) =>
                {
                    c.innerHTML = `<button class='btn btn-sm btn-info' onclick="viewmsgs('${o.rowId}');">View Msg</button>`;
                }
            },
            {
                Field: 'relevant',
                Title: 'Actions',
                Width: 200,
                Renderer: (c, o) =>
                {
                    var row = o.model;

                    c.innerHTML = `<div class="btn-group">
                    <button class='btn btn-sm ${(row.relevant === true ? "btn-primary" : "btn-default")}' onclick="relevant('${o.rowId}');">Relevant</button>
                    <button class='btn btn-sm ${(row.relevant === false ? "btn-primary" : "btn-default")}' onclick="not_relevant('${o.rowId}');">Not relevant</button>
                    </div>`;
                }
            }
        ],
        col_freeze: 1,
    });

function relevant(rowid)
{
    var row = ss.$_data[ rowid ];
    if (row.relevant === true)
    {
        delete row.relevant;
    }
    else
        row.relevant = true;

    ss.re_render(rowid, 'relevant');
}

function not_relevant(rowid)
{
    var row = ss.$_data[ rowid ];
    if (row.relevant === false)
    {
        delete row.relevant;
    }
    else
        row.relevant = false;

    ss.re_render(rowid, 'relevant');
}

function viewmsgs(rowid)
{
    var row = ss.$_data[ rowid ];
    alertify.detailDialog(row, rowid).resizeTo('80%', '80%');
}

function ReadData() {
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/data');
    req.send();
    req.onload = function () {
        var obj = JSON.parse(req.response);
        var data = obj.map(function(item)
        {
            return {
                'PatentNum': item.patent_num,
                'Title': item.title,
                'Details': '',
                'Date': '',
                'Url': item.url,
                'Score': '',
                'relevant':undefined,
            }
        });

        data.forEach(function(item)
        {
            ss.addRow(item);
        });
        debugger;
    };
}
ReadData();


alertify.dialog('detailDialog', function factory()
{
    return {
        main: function (message, rowid)
        {
            this.message = message;
            this.rowid = rowid;
        },
        setup: function ()
        {
            return {
                buttons: [
                    { className: 'btn btn-primary', text: "Relevant", key: 82/*R*/ },
                    { className: 'btn btn-primary', text: "Not relevant", key: 84/*T*/ },
                    { className: 'btn btn-primary', text: "Prev", key: 219/*Esc*/ },
                    { className: 'btn btn-primary', text: "Next", key: 221/*Esc*/ },
                    { className: 'btn btn-primary', text: "Close", key: 27/*Esc*/ },
                ],
                focus: { element: 4 }
            };
        },
        prepare: function ()
        {


            var dom = this.elements.body.querySelector('.ajs-content');
            dom.innerHTML = '';
            var row = this.message;
            debugger;
            this.elements.buttons.primary.children[ 0 ].style.background = '';
            this.elements.buttons.primary.children[ 1 ].style.background = '';
            if (row.relevant === true)
            {
                this.elements.buttons.primary.children[ 0 ].style.background = 'lime';
            }
            if (row.relevant === false)
            {
                this.elements.buttons.primary.children[ 1 ].style.background = 'red';
            }

            dom.style.display = 'grid'
            dom.style.gridTemplateColumns = '100px auto';
            dom.style.gridTemplateRows = '25px 25px 25px auto 25px';

            var span = document.createElement('span');
            span.innerText = 'Title';
            span.style.gridRow = '1'
            span.style.gridColumn = '1';
            dom.appendChild(span);
            var span = document.createElement('span');
            span.innerText = 'Date';
            span.style.gridRow = '2'
            span.style.gridColumn = '1';
            dom.appendChild(span);
            var span = document.createElement('span');
            span.innerText = 'Link';
            span.style.gridRow = '3'
            span.style.gridColumn = '1';
            dom.appendChild(span);
            var span = document.createElement('span');
            span.innerText = 'Description';
            span.style.gridRow = '4'
            span.style.gridColumn = '1';
            dom.appendChild(span);

            var title = document.createElement('div');
            dom.appendChild(title);
            title.style.gridRow = '1';
            title.style.gridColumn = '2';
            UI.createTaggedDisplay(title, row.Title);

            var date = document.createElement('div');
            dom.appendChild(date);
            date.style.gridRow = '2';
            date.style.gridColumn = '2';
            date.innerText = row.Date

            var link = document.createElement('div');
            dom.appendChild(link);
            link.style.gridRow = '3';
            link.style.gridColumn = '2';
            link.innerHTML = `<a href="${row.Url}" target="_blank">${row.Url}</a>`;

            var body = document.createElement('div');
            dom.appendChild(body);
            body.style.gridRow = '4';
            body.style.gridColumn = '2';
            UI.createTaggedDisplay(body, row.Details);
        },
        callback: function (closeEvent)
        {

            debugger;
            //The closeEvent has the following properties
            //
            // index: The index of the button triggering the event.
            // button: The button definition object.
            // cancel: When set true, prevent the dialog from closing.
            if (closeEvent.index < 2)
            {
                closeEvent.cancel = true;
                if (closeEvent.index == 0)
                {
                    if (this.message.relevant === true)
                        delete this.message.relevant;
                    else
                        this.message.relevant = true;
                }
                else
                {
                    if (this.message.relevant === false)
                        delete this.message.relevant;
                    else
                        this.message.relevant = false;
                }
                ss.re_render(this.rowid, 'relevant');
                this.elements.buttons.primary.children[ 0 ].style.background = '';
                this.elements.buttons.primary.children[ 1 ].style.background = '';
                if (this.message.relevant === true)
                {
                    this.elements.buttons.primary.children[ 0 ].style.background = 'lime';
                }
                if (this.message.relevant === false)
                {
                    this.elements.buttons.primary.children[ 1 ].style.background = 'red';
                }
            }
            else if (closeEvent.index == 2)
            {
                var index = ss.$_irows.indexOf(this.rowid);
                var nextRowId = ss.$_irows[ index - 1 ];
                setTimeout(() =>
                {
                    viewmsgs(nextRowId);
                }, 1000);

                debugger;
            }
            else if (closeEvent.index == 3)
            {
                var index = ss.$_irows.indexOf(this.rowid);
                var nextRowId = ss.$_irows[ index + 1 ];
                setTimeout(() =>
                {
                    viewmsgs(nextRowId);
                }, 1000);
                debugger;
            }
        }
    }
});