var TLParser;
(function (TLParser)
{
    var TokenEnum;
    (function (TokenEnum)
    {
        TokenEnum[ TokenEnum[ "NOT_A_TOKEN" ] = 0 ] = "NOT_A_TOKEN";
        TokenEnum[ TokenEnum[ "INTEGER" ] = 1 ] = "INTEGER";
        TokenEnum[ TokenEnum[ "SYMBOL" ] = 2 ] = "SYMBOL";
        TokenEnum[ TokenEnum[ "OPERATOR" ] = 3 ] = "OPERATOR";
        TokenEnum[ TokenEnum[ "KEYWORD" ] = 4 ] = "KEYWORD";
        TokenEnum[ TokenEnum[ "WORD" ] = 5 ] = "WORD";
        TokenEnum[ TokenEnum[ "SEMICOLON" ] = 6 ] = "SEMICOLON";
        TokenEnum[ TokenEnum[ "EOF" ] = 7 ] = "EOF";
        TokenEnum[ TokenEnum[ "L_PAREN" ] = 8 ] = "L_PAREN";
        TokenEnum[ TokenEnum[ "R_PAREN" ] = 9 ] = "R_PAREN";
        TokenEnum[ TokenEnum[ "L_BRACE" ] = 10 ] = "L_BRACE";
        TokenEnum[ TokenEnum[ "R_BRACE" ] = 11 ] = "R_BRACE";
    })(TokenEnum = TLParser.TokenEnum || (TLParser.TokenEnum = {}));
    var isDigit = function (d) { return /^\d$/.test(d); };
    var isKeyword = function (d) { return /^[a-zA-Z][\w\$_]*$/.test(d); };
    var isSymbol = function (d) { return /^[\,\+\-\*\/\(\)\=\&\>\<\=\|]$/.test(d); };
    var keywords = [
        'int', 'void', 'class'
    ];
    var Token = /** @class */ (function ()
    {
        function Token(type, value)
        {
            this.type = type;
            this.value = value;
        }
        Token.prototype.toString = function ()
        {
            return 'Token(' + this.type + ', ' + this.value + ')';
        };
        return Token;
    }());
    TLParser.Token = Token;
    var NOT_A_TOKEN = new Token(TokenEnum.NOT_A_TOKEN, '');
    var opPriority = [
        '|', '&',
        '<', '>', '<=', '>=', '==',
        '-', '+',
        '/', '*',
    ];
    var Lexer = /** @class */ (function ()
    {
        function Lexer(text)
        {
            this.text = text;
            this.pos = 0;
            this.current_char = this.text.charAt(this.pos);
        }
        Lexer.prototype.error = function ()
        {
            throw "Invalid character";
        };
        Lexer.prototype.advance = function ()
        {
            this.pos++;
            if (this.pos > this.text.length - 1)
                this.current_char = '';
            else
                this.current_char = this.text[ this.pos ];
        };
        Lexer.prototype.skip_whitespace = function ()
        {
            while (this.current_char != '' && (this.current_char == ' ' || this.current_char == ' ' || this.current_char == '\n'))
                this.advance();
        };
        Lexer.prototype.keyword = function ()
        {
            var from = this.pos;
            var result = '';
            var out = 5000;
            while (isKeyword(result + this.current_char))
            {
                if (out-- < 0)
                    throw 'Infinite loop';
                result += this.current_char;
                this.advance();
            }
            var to = this.pos;
            return result;
        };
        Lexer.prototype.integer = function ()
        {
            var from = this.pos;
            var result = '';
            while (this.current_char != '' && isDigit(this.current_char))
            {
                result += this.current_char;
                this.advance();
            }
            var to = this.pos;
            return parseInt(result);
        };
        Lexer.prototype.symbol = function ()
        {
            var from = this.pos;
            var inf = 10;
            var result = '';
            var operatorPotential = opPriority.indexOf(this.current_char) >= 0;
            while (isSymbol(this.current_char))
            {
                if (inf-- < 0)
                    throw 'Infinite loop';
                if (operatorPotential && opPriority.indexOf(result + this.current_char) == -1)
                {
                    var to_1 = this.pos;
                    return result;
                }
                result += this.current_char;
                this.advance();
            }
            var to = this.pos;
            return result;
        };
        Lexer.prototype.get_next_token = function ()
        {
            if (this.pos >= this.text.length)
                return new Token(TokenEnum.EOF, '');
            while (this.current_char != '')
            {
                if (this.current_char == ' ' || this.current_char == '  ' || this.current_char == '\n')
                {
                    this.skip_whitespace();
                    continue;
                }
                if (isDigit(this.current_char))
                {
                    return new Token(TokenEnum.INTEGER, this.integer());
                }
                if (isKeyword(this.current_char))
                {
                    var word = this.keyword();
                    if (keywords.indexOf(word) >= 0)
                        return new Token(TokenEnum.KEYWORD, word);
                    else
                        return new Token(TokenEnum.WORD, word);
                }
                if (this.current_char == '(')
                {
                    var to = this.pos;
                    this.advance();
                    var from = this.pos;
                    return new Token(TokenEnum.L_PAREN, '(');
                }
                if (this.current_char == ')')
                {
                    var to = this.pos;
                    this.advance();
                    var from = this.pos;
                    return new Token(TokenEnum.R_PAREN, ')');
                }
                if (this.current_char == '{')
                {
                    var to = this.pos;
                    this.advance();
                    var from = this.pos;
                    return new Token(TokenEnum.L_BRACE, '{');
                }
                if (this.current_char == '}')
                {
                    var to = this.pos;
                    this.advance();
                    var from = this.pos;
                    return new Token(TokenEnum.R_BRACE, '}');
                }
                if (isSymbol(this.current_char))
                {
                    var sym = this.symbol();
                    if (opPriority.indexOf(sym) >= 0)
                    {
                        return new Token(TokenEnum.OPERATOR, sym);
                    }
                    else
                    {
                        return new Token(TokenEnum.SYMBOL, sym);
                    }
                }
                if (this.current_char == ';')
                {
                    var to = this.pos;
                    this.advance();
                    var from = this.pos;
                    return new Token(TokenEnum.SEMICOLON, ';');
                }
                this.error();
            }
            return new Token(TokenEnum.EOF, '');
        };
        return Lexer;
    }());
    TLParser.Lexer = Lexer;
    var OpCode;
    (function (OpCode)
    {
        OpCode[ OpCode[ "EXPRESION" ] = 0 ] = "EXPRESION";
        OpCode[ OpCode[ "STATEMENT" ] = 1 ] = "STATEMENT";
        OpCode[ OpCode[ "FUNC_CALL" ] = 2 ] = "FUNC_CALL";
        OpCode[ OpCode[ "BLOCK" ] = 3 ] = "BLOCK";
        OpCode[ OpCode[ "FUNC_DECLARE" ] = 4 ] = "FUNC_DECLARE";
        OpCode[ OpCode[ "VAR_DECLARE" ] = 5 ] = "VAR_DECLARE";
        OpCode[ OpCode[ "CLASS_DECLARE" ] = 6 ] = "CLASS_DECLARE";
    })(OpCode = TLParser.OpCode || (TLParser.OpCode = {}));
    var OpNode = /** @class */ (function ()
    {
        function OpNode(opcode, token, children)
        {
            var _this = this;
            if (token === void 0) { token = NOT_A_TOKEN; }
            if (children === void 0) { children = null; }
            this.children = null;
            this.parent = null;
            this.props = null;
            this.opcode = opcode;
            this.token = token;
            this.children = children;
            if (children)
            {
                children.forEach(function (child) { return child.parent = _this; });
            }
        }
        OpNode.prototype.addChildren = function (node)
        {
            if (!this.children)
                this.children = [];
            this.children.push(node);
            node.parent = this;
        };
        OpNode.prototype.item = function (index)
        {
            if (this.children)
            {
                if (index < 0)
                    throw "Index cannot be -ve";
                if (index < this.children.length)
                    throw "Index overflow";
                return this.children[ index ];
            }
            throw "Array not initialized";
        };
        OpNode.prototype.lastNode = function ()
        {
            var node1 = this;
            while (node1.children && node1.children.length > 0)
            {
                node1 = node1.children[ node1.children.length - 1 ];
            }
            return node1;
        };
        return OpNode;
    }());
    TLParser.OpNode = OpNode;
    var Interpreter = /** @class */ (function ()
    {
        function Interpreter(lex)
        {
            this.current_token = NOT_A_TOKEN;
            this.lex = lex;
            this.nextToken();
        }
        Interpreter.prototype.expr = function ()
        {
            var curNode = new OpNode(OpCode.STATEMENT, this.current_token);
            var lastToken = new Token(TokenEnum.NOT_A_TOKEN, "");
            if (curNode.token.type !== TokenEnum.L_PAREN)
            {
                lastToken = this.current_token;
                this.nextToken();
            }
            var infLoopBail = 10000;
            while (true)
            {
                if (infLoopBail-- < 0)
                    throw 'Infinite loop';
                if (this.current_token.type == TokenEnum.SEMICOLON)
                {
                    this.nextToken();
                    break;
                }
                if (this.current_token.type == TokenEnum.EOF)
                    throw "Expected ;";
                if (this.current_token.type == TokenEnum.R_PAREN)
                    break;
                if (this.current_token.value == ',')
                    break;
                switch (this.current_token.type)
                {
                    //#region operand
                    case TokenEnum.WORD:
                    case TokenEnum.INTEGER:
                        curNode.addChildren(new OpNode(OpCode.STATEMENT, this.current_token));
                        break;
                    //#endregion
                    //#region operator
                    case TokenEnum.OPERATOR:
                        if (curNode.token.type == TokenEnum.OPERATOR)
                        {
                            var operator = this.current_token.value;
                            if (typeof curNode.token.value != 'string')
                                throw "Symbol cannot be numeric";
                            var newRank = opPriority.indexOf(operator);
                            if (newRank == -1)
                                throw "Unknown symbol";
                            //Determine the rank of current eval
                            var curRank = -1;
                            if (curNode.opcode == OpCode.STATEMENT)
                            {
                                curRank = opPriority.indexOf(curNode.token.value);
                                if (curRank == -1)
                                    throw "Unknown symbol";
                            }
                            else
                            {
                                curRank = opPriority.length;
                            }
                            var newNode = new OpNode(OpCode.STATEMENT, this.current_token);
                            if (newRank <= curRank)
                            {
                                while (true)
                                {
                                    if (curNode.parent)
                                        curNode = curNode.parent;
                                    else
                                        break;
                                    curRank = opPriority.indexOf(curNode.token.value);
                                    if (newRank > curRank)
                                        break;
                                }
                            }
                            if (newRank <= curRank)
                            {
                                newNode.addChildren(curNode);
                                curNode = newNode;
                                break;
                            }
                            if (newRank > curRank)
                            {
                                if (!curNode.children)
                                    throw "Current node cannot have no children";
                                var operrand = curNode.children.splice(curNode.children.length - 1, 1)[ 0 ];
                                newNode.addChildren(operrand);
                                curNode.addChildren(newNode);
                                curNode = newNode;
                            }
                            break;
                        }
                        if (curNode.token.type == TokenEnum.WORD || curNode.token.type == TokenEnum.INTEGER)
                        {
                            var newNode = new OpNode(OpCode.STATEMENT, this.current_token, [ curNode ]);
                            curNode = newNode;
                            break;
                        }
                        break;
                    //#endregion
                    //#region LPAREN
                    case TokenEnum.L_PAREN:
                        var isFunc = false;
                        if (lastToken.type == TokenEnum.WORD)
                        {
                            isFunc = true;
                        }
                        if (isFunc)
                        {
                            var lastNode = curNode.lastNode();
                            lastNode.opcode = OpCode.FUNC_CALL;
                            while (true)
                            {
                                this.nextToken();
                                var node1 = this.expr();
                                if (this.current_token.value == ',' || this.current_token.value == ')')
                                {
                                    lastNode.addChildren(node1);
                                    if (this.current_token.value != ',')
                                        break;
                                }
                                else
                                    throw 'Expected )';
                            }
                        }
                        else
                        {
                            // non function
                            this.nextToken();
                            var node1 = this.expr();
                            if (curNode.token.type !== TokenEnum.L_PAREN)
                                curNode.addChildren(node1);
                            curNode = node1;
                            if (this.current_token.value !== ')')
                                throw "Expected )";
                        }
                        break;
                    //#endregion
                }
                lastToken = this.current_token;
                this.nextToken();
            }
            while (curNode.parent != null)
                curNode = curNode.parent;
            curNode.opcode = OpCode.EXPRESION;
            return curNode;
        };
        Interpreter.prototype.block = function ()
        {
            var curNode = new OpNode(OpCode.BLOCK, NOT_A_TOKEN);
            while (this.current_token.type != TokenEnum.R_BRACE)
            {
                curNode.addChildren(this.expr());
            }
            return curNode;
        };
        Interpreter.prototype.declaration = function ()
        {
            if (this.current_token.type == TokenEnum.KEYWORD)
            {
                var opNode = new OpNode(OpCode.VAR_DECLARE);
                opNode.props = {};
                opNode.props.type = this.current_token.value;
                // opNode.addChildren(new OpNode(OpCode.REF_TYPE, this.current_token));
                this.nextToken();
                if (this.current_token.type != TokenEnum.WORD)
                    throw "Expected varialbe identifier.";
                opNode.props.name = this.current_token.value;
                // opNode.addChildren(new OpNode(OpCode.REF_NAME, this.current_token));
                this.nextToken();
                // is function declaration
                if (this.current_token.type == TokenEnum.L_PAREN)
                {
                    opNode.opcode = OpCode.FUNC_DECLARE;
                    this.nextToken();
                    //let argNode = new OpNode(OpCode.PARAM_DECLARE);
                    //opNode.addChildren(argNode);
                    opNode.props.args = [];
                    while (this.current_token.type != TokenEnum.R_PAREN)
                    {
                        var argInfo = { type: '', name: '' };
                        if (this.current_token.type != TokenEnum.KEYWORD)
                            throw 'Expected datatype';
                        argInfo.type = this.current_token.value.toString();
                        //argNode.addChildren(new OpNode(OpCode.REF_TYPE, this.current_token));
                        this.nextToken();
                        if (this.current_token.type != TokenEnum.WORD)
                            throw "Expected variable name";
                        //argNode.addChildren(new OpNode(OpCode.REF_NAME, this.current_token));
                        argInfo.name = this.current_token.value;
                        opNode.props.args.push(argInfo);
                        this.nextToken();
                    }
                    this.nextToken();
                    if (this.current_token.type != TokenEnum.L_BRACE)
                        throw "Expected {";
                    this.nextToken();
                    opNode.addChildren(this.block());
                    if (this.current_token.type != TokenEnum.R_BRACE)
                        throw "Expected }";
                    this.nextToken();
                }
                // is variable declaration
                else
                {
                    if (this.current_token.type != TokenEnum.SEMICOLON)
                        throw "Expected ;";
                }
                return opNode;
            }
            else
            {
                return this.expr();
            }
        };
        Interpreter.prototype.program = function ()
        {
            var curNode = new OpNode(OpCode.BLOCK);
            while (this.current_token.type != TokenEnum.EOF)
            {
                curNode.addChildren(this.declaration());
                this.nextToken();
            }
            return curNode;
        };
        Interpreter.prototype.classDef = function ()
        {
            if (this.current_token.type == TokenEnum.KEYWORD && this.current_token.value == 'class')
            {
                var curNode = new OpNode(OpCode.CLASS_DECLARE);
                this.nextToken();
                if (this.current_token.type != TokenEnum.WORD)
                    throw "Expected classname";
                curNode.props = {};
                curNode.props.name = this.current_token.value;
                this.nextToken();
                if (this.current_token.type != TokenEnum.L_BRACE)
                    throw "Expected block start";
                while (this.current_token.type != TokenEnum.R_BRACE)
                {
                    this.nextToken();
                    curNode.addChildren(this.declaration());
                }
                this.nextToken();
                return curNode;
            }
            else
                throw 'Expected class def';
        };
        Interpreter.prototype.nextToken = function ()
        {
            this.current_token = this.lex.get_next_token();
        };
        return Interpreter;
    }());
    TLParser.Interpreter = Interpreter;
})(TLParser || (TLParser = {}));
var LogicalParser;
(function (LogicalParser)
{
    function checkValid(code, fieldsAvaialable)
    {
        var otherErrors = [];
        var validOperators = [
            '>',
            '<',
            '>=',
            '<=',
            '==',
            '!=',
            '&',
            '|'
        ];

        try
        {
            var lxp = new TLParser.Lexer(code + ";");
            var intp = new TLParser.Interpreter(lxp);
            var parseTree = intp.expr();
            var itr = [ parseTree ];
            for (var i = 0; i < itr.length; i++)
            {
                var node = itr[ i ];
                if (node.token.type == 3)
                {
                    if (validOperators.indexOf(node.token.value) == -1)
                    {
                        otherErrors.push("Invalid operator " + node.token.value);
                    }
                    if(!node.children || node.children.length<2)
                    {
                        otherErrors.push("Operator " + node.token.value + ' needs to have one expression on left and one on right.');
                    }
                }

                if (node.children)
                {
                    node.children.forEach(function (child) { return itr.push(child); });
                }
            }

            var wordsUsed = itr
                .filter(function (k) { return k.token.type == TLParser.TokenEnum.WORD; })
                .map(function (k) { return k.token.value; });

            var invalidWord = [];
            wordsUsed.forEach(function (word)
            {
                if (fieldsAvaialable.indexOf(word.toString()) == -1)
                {
                    invalidWord.push(word.toString());
                }
            });
            return { parseTree: parseTree, invalidWord: invalidWord, errors:otherErrors };
        }
        catch (ex)
        {
            return { reason: ex };
        }
    }
    LogicalParser.checkValid = checkValid;
})(LogicalParser || (LogicalParser = {}));

