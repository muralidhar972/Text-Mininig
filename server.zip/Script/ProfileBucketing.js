var currentSelectionCtrl;
var iBucketCount=0;
var iBucketDetailCount=0;
var htmClone;
var _isRefresh=0;
var contentSelection;
var arrAlphabets=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9'];


$(document).bind("mousedown", function (e) 
{
  if (!$(e.target).parents(".custom-menu").length > 0) 
  {
      $(".custom-menu").hide(100);
  }
});


/*

  Remove all code tag and mark tag on mouse down
  Set select field name into currentSelectionCtrl varibale

*/
function enableBucketing()
{
  
  $('#div_columns > .title-container .desctext').mousedown(function(event) 
    {
        removeTag('temp');
        $(".bucketComment").val('');
        //$("#div_loader").show();
        currentSelectionCtrl=$(this);
        //var at=$(currentSelectionCtrl).attr('name');
        //$('[name='+at+'] code').contents().unwrap();
        //$('[name='+at+'] mark').contents().unwrap();
        //$('[name='+at+'] a').remove();
        //var con=$($('[name='+at+']')[2]).html();
        //$('[name='+at+']').html(con);
        //htmClone=$('[name='+at+']').clone();
        //$("#div_loader").hide();
    });

  $('#div_columns > .title-container .desctext').mouseup(function(event) 
    {
        currentSelectionCtrl=$(this);
        if(getSelectedText()!=='')
        { 
            var x = event.clientX;
            var y = event.clientY;
            var pageX=event.pageX;
            var pageY=event.pageY;
            var totalwidth=screen.width;
            var fixWidth=totalwidth-150;
            var containerwidth=$(".container").width();
            if(pageX>fixWidth)
            {
              pageX=pageX-150;
            }
            $(".custom-menu").finish().toggle(500).
            css({
                top: pageY + "px",
                left: pageX + "px"
            });
            showSelectionOnFocus();
        }
    });
    $(".bucketComment").focus(function()
    {
        //showSelectionOnFocus();
    })
}

function getTempTagSelectionOffSet()
{
    var tNode = $('temp')[0];
    var start=0;
    var end=0;
    var content=tNode.textContent;
    var off = 0;
    if (tNode.parentElement.nodeName == 'CODE' || tNode.parentElement.nodeName == 'MARK' || tNode.parentElement.nodeName == 'TEMP')
        tNode = tNode.parentElement;
    tNode = tNode.previousSibling;
    while (tNode) 
    {
        off += tNode.textContent.length;
        tNode = tNode.previousSibling;
    }

    start=off;
    /*
    off=0;
    tNode = $('temp')[0];

    if (tNode.parentElement.nodeName == 'CODE' || tNode.parentElement.nodeName == 'MARK' || tNode.parentElement.nodeName == 'TEMP')
      tNode = tNode.parentElement;
      tNode = tNode.nextSibling;
      while (tNode) {
          off += tNode.textContent.length;
          tNode = tNode.nextSibling;
      }
    */
    end=start+content.length;
    return { begin:start, end:end, content:content };
}

function getSelectionOffsets(sel) 
{
  var begin = sel.anchorOffset + getOffset(sel.anchorNode);
  var end = sel.focusOffset + getOffset(sel.focusNode);
  return { begin:begin, end:end };
}
function getOffset(item) 
{
  var off = 0;
  var tNode = item;
  if (tNode.parentElement.nodeName == 'CODE' || tNode.parentElement.nodeName == 'MARK')
      tNode = tNode.parentElement;
  tNode = tNode.previousSibling;
  while (tNode) {
      off += tNode.textContent.length;
      tNode = tNode.previousSibling;
  }
  return off;
}

function showSelectionOnFocus()
{
  var range = window.getSelection().getRangeAt(0);
  var newNode = document.createElement("temp");
  range.surroundContents(newNode);
}


function getSelectedText() 
{
  if (window.getSelection) 
  {
      return window.getSelection().toString();
  } 
  else if (document.selection) 
  {
      return document.selection.createRange().text;
  }
  return '';
}


/*

  defination : Add tag into database

*/
function addBucketTextDB(ctrl)
{
  $("#div_loader").show();
  var attrName=$(ctrl).attr('name');
  var comment='';
  var selectedText='';
  var contentInfo;
  if($("temp").length>0)
  {
    comment=$.trim($("#ta_BucketComment_"+attrName).val());
    contentInfo=getTempTagSelectionOffSet();
    selectedText=contentInfo.content;
  }
  else
  {
    comment='';
    contentInfo=getSelectionOffsets(document.getSelection());
    selectedText=getSelectedText();
  }

  //var range = window.getSelection().getRangeAt(0);
  var bucketname=$(ctrl).attr('name');
  var dbField=$(currentSelectionCtrl).attr('name');
  var from=contentInfo.begin;
  var to=contentInfo.end;
  var modifiedby='${userid}';
  var modifieddt=new Date();
  
  if($.trim($("#ta_BucketComment_"+bucketname).val())!=='')
  {
    comment=$.trim($("#ta_BucketComment_"+bucketname).val());
  }
  var result=arrSelectedProfileInfos[0].bucket.filter(function(c)
  {
    return ($.trim(c.bucketname).toLowerCase()===$.trim(bucketname).toLowerCase())
  });
  if(result.length>0)
  {
      var info=[];
      var res=arrAllProfiles.filter(function(el)
      {
        return $.trim(el._id)===$.trim(strSelectedProfileID)
      });
      info.push({
          "bucketname":$.trim(bucketname),
          "itemId":strSelectedItemID,
          "fieldname" : $.trim(dbField),
          "from" : from,
          "to" : to,
          "text" : $.trim(selectedText),
          "comment":comment,
          "modifiedby":modifiedby,
          "modifieddt":modifieddt
      });

      var sendInfo=[];
      sendInfo.push({"dbName":res[0].profile_name,"objId":strSelectedProfileID,"info":info});
      
      var req = new XMLHttpRequest();
      req.open('POST', '/_api/doUpdateBucket');
      req.setRequestHeader('content-type', 'application/json');
      req.send(JSON.stringify(sendInfo));
      req.onload = function () 
      { 
          var obj = JSON.parse(req.response);
          if(obj.Result==='Bucket_updated')
          {
            _getRefreshBucket(dbField);
          }
          else if(obj.Result==='WrongSelection')
          {
              $("#div_loader").hide();
              __alertfy('alertfy_error','Please do not select bucket content from right direction to left direction.Please try again.');
              //alert("Please do not select bucket content from right direction to left direction.Please try again.");
          }
          else if(obj.Result==='Overlapping')
          {
              $("#div_loader").hide();
              __alertfy('alertfy_warning','Selected content is already exist.Please try again.');
              //alert("Selected content is already exist.Please try again.");
          }
          else if(obj.Result==='BucketNotFound')
          {
              $("#div_loader").hide();
              __alertfy('alertfy_Info','Selected bucket not found in db. Kindly contact to site administrator');
              //console.log('Selected bucket not found in db. Kindly contact to site administrator');
          }
      };
  }
  else
  {
      $("#div_loader").hide();
      __alertfy('alertfy_Info','Selected bucket not found in db. Kindly contact to site administrator');
      //alert('Selected bucket not found in db. Kindly contact to site administrator');
  }
}

function removeTag(tagname)
{
  $(tagname).contents().unwrap();
    /*
        var b = document.getElementsByTagName(tagname);

        while(b.length) {
            var parent = b[ 0 ].parentNode;
            while( b[ 0 ].firstChild ) {
                parent.insertBefore(  b[ 0 ].firstChild, b[ 0 ] );
            }
            parent.removeChild( b[ 0 ] );
        }
    */
}


function _getBucketFrequency(ctrlid,ctrl)
{
  var color=$.trim(ctrlid.split('__')[1]);
  var paramBucket=$.trim(ctrlid.split('__')[2]);
  $("#div_FrequencyCloud").html('');
  $("#div_ProfileFrequency").html('');
  $("#tblSignificance").html('');
  var arrBucketFrequency=[];
  if(arrSelectedProfileInfos[0].bucket!==undefined)
  {
  if(arrSelectedProfileInfos[0].bucket.length>0)
  {
    for(var i=0;i<arrSelectedProfileInfos[0].bucket.length;i++)
    {
      for(var s=0;s<arrSelectedProfileInfos[0].fields.length;s++)
      {
        if($.trim(color)==='all')
        {
          arrBucketFrequency.push(
            {
              'bucketname':$.trim(arrSelectedProfileInfos[0].bucket[i].bucketname),
              'Field':$.trim(arrSelectedProfileInfos[0].fields[s].name),
              'Color':$.trim(arrSelectedProfileInfos[0].bucket[i].color),
              'Count':0
            });
        }
        else
        {
            if($.trim(paramBucket).toUpperCase()===$.trim(arrSelectedProfileInfos[0].bucket[i].bucketname).toUpperCase())
            {
              arrBucketFrequency.push(
                {
                  'bucketname':$.trim(arrSelectedProfileInfos[0].bucket[i].bucketname),
                  'Field':$.trim(arrSelectedProfileInfos[0].fields[s].name),
                  'Color':$.trim(arrSelectedProfileInfos[0].bucket[i].color),
                  'Count':0
                });
            }
        }
        
      }
    }
  
  if($("code").length>0)
  {
      for(var k=0;k<$("code").length;k++)
      {
          var strbucket=$.trim($($("code")[k]).attr('class').split(' ')[2]).replace(/___/g, ' ');
          var strfield=$.trim($($("code")[k]).attr('class').split(' ')[3]);
          var ret=arrBucketFrequency.filter(function(m)
          {
            return ($.trim(m.bucketname).toLowerCase()===$.trim(strbucket).toLowerCase() && $.trim(m.Field).toLowerCase()===$.trim(strfield).toLowerCase())
          });
          if(ret.length>0)
          {
            ret[0].Count=parseInt(ret[0].Count)+1;
          }
      }
  }
  if(arrBucketFrequency.length>0)
  {
    var sHTML='';
    sHTML=sHTML+'<table class="FrequencyTable buckettable" cellpadding="0" cellspacing="0" border="0">';
    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<th>Bucket name</th>';
    sHTML=sHTML+'<th>Field</th>';
    sHTML=sHTML+'<th>Count</th>';
    sHTML=sHTML+'<th>Color</th>';
    sHTML=sHTML+'</tr>';
    for(var n=0;n<arrBucketFrequency.length;n++)
    {
      sHTML=sHTML+'<tr>';
      sHTML=sHTML+'<td>'+arrBucketFrequency[n].bucketname+'</td>';
      sHTML=sHTML+'<td>'+arrBucketFrequency[n].Field+'</td>';
      sHTML=sHTML+'<td>'+arrBucketFrequency[n].Count+'</td>';
      sHTML=sHTML+'<td><div style="width:15px;height:15px;background:'+arrBucketFrequency[n].Color+'"></td>';
      sHTML=sHTML+'</tr>';
    }
    sHTML=sHTML+'</table">';
    $("#div_ProfileFrequency").html('');
    $("#div_ProfileFrequency").html(sHTML);
    sHTML='';
  }
  else
  {
    var sHTML='';
    sHTML=sHTML+'<table class="FrequencyTable buckettable" cellpadding="0" cellspacing="0" border="0">';

    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<th>Bucket name</th>';
    sHTML=sHTML+'<th>Field</th>';
    sHTML=sHTML+'<th>Count</th>';
    sHTML=sHTML+'<th>Color</th>';
    sHTML=sHTML+'</tr>';

    sHTML=sHTML+'<tr>';
    sHTML=sHTML+'<td colspan="4" style="text-align:center;">No record found</td>';
    sHTML=sHTML+'</tr>';

    sHTML=sHTML+'</table">';
    $("#div_ProfileFrequency").html('');
    $("#div_ProfileFrequency").html(sHTML);
    sHTML='';
  }
  _bindBacketLegends();
  fnBucketingFrequencyCloud(arrBucketFrequency,color);
}
}
}

function _bindBacketLegends()
{
  $("#tblSignificance").html('');
  var iTdsCount=0;
  var strLegends='';
  strLegends=strLegends+'<tr>';
  strLegends=strLegends+'<td><span id="spnBucketAll__all__all" style="cursor:pointer;font-weight:bold;" >Legends : &nbsp;</span></td>';  //onclick="return _getBucketFrequency(this.id,this);"
  iTdsCount++;
  for(var t=0;t<arrSelectedProfileInfos[0].bucket.length;t++)
  {
    var bukt=arrSelectedProfileInfos[0].bucket[t].bucketname;
    var buktColor=arrSelectedProfileInfos[0].bucket[t].color;
    strLegends=strLegends+'<td>';
    strLegends=strLegends+'<div id="div__'+buktColor.replace(/#/g, '')+'__'+bukt.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+'" style="min-width: 14px;cursor:pointer;min-height: 15px;background: '+buktColor+';display: inline-block;float:left;"></div>';
    strLegends=strLegends+'<span id="spn__'+buktColor.replace(/#/g, '')+'__'+bukt.toUpperCase().replace(/  +/g, '#').replace(/_/g, '#').replace(/\s/g,'#')+'" style="cursor:pointer;" class="pull-left tlabels">'+bukt+' &nbsp;</span>';
    strLegends=strLegends+'</td>';
    iTdsCount++;
    if(iTdsCount%8===0)
    {
      strLegends=strLegends+'</tr>';
      strLegends=strLegends+'<tr>';
      
      idecWidth=idecWidth+10;
    }
    if(t===arrSelectedProfileInfos[0].bucket.length-1)
    {
      strLegends=strLegends+'</tr>';
      $("#tblSignificance").html(strLegends);
      strLegends='';
    }
  }
}


function fnBucketingFrequencyCloud(arrFrequency,action)
{
    var word_list=[];
    for(var m=0;m<arrFrequency.length;m++)
    {
      if(action==='all')
      {
        var resSet=word_list.filter(function(c)
        {
          return ($.trim(c.text).toLowerCase()===$.trim(arrFrequency[m].bucketname).toLowerCase())
        });
        if(resSet.length>0)
        {
          resSet[0].weight=parseInt(resSet[0].weight)+parseInt(arrFrequency[m].Count);
          resSet[0].html['data-tooltip']=parseInt(resSet[0].html['data-tooltip'])+parseInt(arrFrequency[m].Count);
        }
        else
        {
          if(m%2===1)
          {
            word_list.push({text: arrFrequency[m].bucketname, weight: parseInt(arrFrequency[m].Count), html: {"data-tooltip": arrFrequency[m].Count}});
          }
          else
          {
            word_list.push({text: arrFrequency[m].bucketname, weight: parseInt(arrFrequency[m].Count),html: {"data-tooltip": arrFrequency[m].Count}});
          }
        }
      }
      else
      {
        if(m%2===1)
        {
          word_list.push({text: arrFrequency[m].bucketname, weight: parseInt(arrFrequency[m].Count), html: {"data-tooltip": arrFrequency[m].Count}});
        }
        else
        {
          word_list.push({text: arrFrequency[m].bucketname, weight: parseInt(arrFrequency[m].count),html: {"data-tooltip": arrFrequency[m].Count}});
        }
      }
    }

    $(function() {
      $("#div_FrequencyCloud").jQCloud(word_list, 
      {
        shape: "rectangular",
        autoResize: true
        //removeOverflowing:false
      });
    });
    $("#profilefre").html("Bucket frequency");
    $("#myProfileFrequency").css('display','block');

}

/*

  defination : Show all tagging on page load

*/
function showBucket()
{
  var startOffset=0;
  var endOffset=0;
  var clName='';
  var clsBucket='';
  var fldName='';
  var arrFieldsData=[];
  var arrFilters=[];
  if(arrSelectedProfileInfos.length>0)
  {
    if(arrSelectedProfileInfos[0].bucket!==undefined)
    {
      for(var t=0;t<arrSelectedProfileInfos[0].fields.length;t++)
      {
        var flName=arrSelectedProfileInfos[0].fields[t].name;
        if($.trim(flName)!=="_id" && $.trim(flName)!=="__EMPTY" && $.trim(flName)!=="Unnamed__0" && $.trim(flName)!=="0" && $.trim(flName)!=="Unnamed: 0" && $.trim(flName)!=="")
        {
          flName=$.trim(flName).replace(/[^a-zA-Z0-9_-]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
          arrFieldsData.push({'Content':$('#div_columns [name='+flName+']').text(),'Field':flName});
        }
      }
      for(var i=0;i<arrSelectedProfileInfos[0].bucket.length;i++)
      {
        if(arrSelectedProfileInfos[0].bucket[i].bucketdetail.length>0)
        {
          for(var c=0;c<arrSelectedProfileInfos[0].bucket[i].bucketdetail.length;c++)
          {
            if($.trim(arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].itemId)===$.trim(strSelectedItemID) && $.trim(arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].status)==='active')
            {
              var fname=arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].fieldname;
              clsBucket="match clbucket "+arrSelectedProfileInfos[0].bucket[i].bucketname.replace(/\s/g,'___')+" "+arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].fieldname;
              var resResult=arrFilters.filter(function(m)
              {
                return ($.trim(m.Field).toLowerCase()===$.trim(fname).toLowerCase())
              });
              if(resResult.length>0)
              {
                resResult[0].Filter.push({
                  "from":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].range.from,
                  "itemId":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].itemId,
                  "to":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].range.to,
                  "text":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].text,
                  "class":clsBucket,
                  "bucketname":arrSelectedProfileInfos[0].bucket[i].bucketname,
                  "color":arrSelectedProfileInfos[0].bucket[i].color
                })
              }
              else
              {
                arrFilters.push({"Field":fname,"Filter":[
                  {
                    "from":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].range.from,
                    "itemId":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].itemId,
                    "to":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].range.to,
                    "text":arrSelectedProfileInfos[0].bucket[i].bucketdetail[c].text,
                    "class":clsBucket,
                    "bucketname":arrSelectedProfileInfos[0].bucket[i].bucketname,
                    "color":arrSelectedProfileInfos[0].bucket[i].color
                  }
                ]});
              }
            }
          }
        }
      }
      for(var rw=0;rw<arrFieldsData.length;rw++)
      {
        var ret=arrFilters.filter(function(el)
        {
          return ($.trim(el.Field).toLowerCase()===$.trim(arrFieldsData[rw].Field).toLowerCase())
        });
        if(ret.length>0)
        {
          if(ret[0].Filter.length>0)
          {
            var cnt=arrFieldsData[rw].Content.replace(/  +/g, ' ').replace(/&nbsp;/g,' ');
            var res = [];
            var arr=ret[0].Filter;
            
            arr.sort(function(a,b){
              return a.from - b.from;
            });
            
            var j = 0;
            for(var s=0; s<arr.length; s++)
            {
              var start=arr[s].from;
              var end=arr[s].to;
              var cls=arr[s].class;
              var clr=arr[s].color;
              if(start>j)
              {
                res.push({cnt:cnt.substring(j,start),class:'',style:'',onclick:""});
              }
              res.push({cnt:cnt.substring(start,end),class:cls,style:clr,id:arr[s].itemId+'_'+ret[0].Field.replace(/\s/g,'')+'_'+start+'_'+end,onclick:"fnDeleteTagging('"+ret[0].Field+"','"+arr[s].itemId+"','"+arr[s].from+"','"+arr[s].to+"','"+arr[s].bucketname+"',event)"});
              if(s==arr.length-1)
              {
                res.push({cnt:cnt.substring(end,cnt.length),class:'',style:'',onclick:""});
              }
              j = end;
            }
            //var cont=res.map(function(i){if(i.class!='')return "<code class='"+i.class+"' style='border-radius: 80px;padding: 0px 10px;color:white;background-color:"+i.style+"'>"+i.cnt+"</code>"; else return i.cnt}).join('')
            var cont=res.map(function(i)
            {
              if(i.class!='')
                return "<code class='"+i.class+"' id='codebucket_"+i.id+"' style='background:"+i.style+"'>"+i.cnt+"<a id='ancbucket_"+i.id+"' href=\"javascript:void(0);\" onclick="+i.onclick+"><i class=\"fa fa-times\"></i></a></code>"; 
              else 
                return i.cnt
            }).join('')

            $('#div_columns [name='+arrFieldsData[rw].Field+']').html(cont);
            
            cnt='';
          }
        }
      }
    }
  }
  $(".custom-menu").hide(100);
  $('.clbucket').hover(function(event)
  {
    $(".bucketTooltip").hide();
    var x = event.clientX;
    var y = event.clientY;
    _getBucketStats($(this));
    /*
    console.log('================================================');
    console.log('ClientX==>'+x,'ClientY==>'+y);
    console.log('PageX==>'+event.pageX,'PageY==>'+event.pageY);
    console.log("Total Width: " + screen.width);
    console.log("Screen availWidth: " + screen.availWidth,"Screen availHeight: "+ screen.availHeight);
    console.log("Container Width: " + $(".container").width());
    console.log('================================================');
    */

    var pageX=event.pageX;
    var pageY=event.pageY;
    var totalwidth=screen.width;
    var fixWidth=totalwidth-150;
    var containerwidth=$(".container").width();
    /*
        top: (event.pageY+10) + "px",
        left: (event.pageX) + "px"
    */
    if(pageX>fixWidth)
    {
      pageX=pageX-150;
    }
    $(".bucketTooltip").finish().toggle(500).
    css({
        top: (pageY+10) + "px",
        left: (pageX) + "px"
    });
  });

  $('.clbucket').mouseout(function(event)
  {
    $(".bucketTooltip").hide();
  });
  searchKeyword();
}

function _getBucketStats(ctrl)
{
  var strSelectedCtrl=$(ctrl).attr('class');
  var strSelectedCtrlItemID=$(ctrl).attr('id').split('_')[1];
  var strSelectedBucketName=$.trim(strSelectedCtrl.split(' ')[2]).replace(/___/g, ' ');
  var strSelectedField=$.trim(strSelectedCtrl.split(' ')[3]);
  var iCount=0
  var idx = $(ctrl).attr('id').indexOf("_");
  var tagid=$(ctrl).attr('id').substr(idx+1, $(ctrl).attr('id').length);
  if($("code").length>0)
  {
      for(var k=0;k<$("code").length;k++)
      {
          var strbucket=$.trim($($("code")[k]).attr('class').split(' ')[2]).replace(/___/g, ' ');
          var strfield=$.trim($($("code")[k]).attr('class').split(' ')[3]);
          if($.trim(strbucket).toLowerCase()===$.trim(strSelectedBucketName).toLowerCase() && $.trim(strfield).toLowerCase()===$.trim(strSelectedField).toLowerCase())
          {
            iCount=iCount+1;
          }
      }
      var strHTML='';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Bucket name</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+strSelectedBucketName+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Field name</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+strfield+'</span></td>';
      strHTML=strHTML+'</tr>';
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Count</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><span>'+iCount+'</span></td>';
      strHTML=strHTML+'</tr>';
      
      if(arrSelectedProfileInfos[0].bucket.length>0)
      {
        var retRes=arrSelectedProfileInfos[0].bucket.filter(function(el)
        {
          return $.trim(el.bucketname)===$.trim(strSelectedBucketName)
        });
        if(retRes.length>0)
        {
            var retResponse=retRes[0].bucketdetail.filter(function(ek)
            {
              return $.trim(ek.tagid)===$.trim(tagid)
            });
            if(retResponse.length>0)
            {
                if(retResponse[0].comment!==undefined && retResponse[0].comment!==null)
                {
                    strHTML=strHTML+'<tr>';
                    strHTML=strHTML+'<td>Comment</td>';
                    strHTML=strHTML+'<td>:</td>';
                    strHTML=strHTML+'<td><span>'+retResponse[0].comment+'</span></td>';
                    strHTML=strHTML+'</tr>';
                }
            }
        }
      }
      strHTML=strHTML+'<tr>';
      strHTML=strHTML+'<td>Color</td>';
      strHTML=strHTML+'<td>:</td>';
      strHTML=strHTML+'<td><div style="background:'+$.trim($(ctrl).attr('style').split(':')[1])+';min-width: 14px;cursor:pointer;min-height: 15px;display: inline-block;float:left;"></div></td>';
      strHTML=strHTML+'</tr>';
      $("#tblBucketKeywordStats").html('');
      $("#tblBucketKeywordStats").html(strHTML);
      strHTML='';
      

      //$(".statsbukname").html(strSelectedBucketName);
      //$(".statsfield").html(strfield);
      //$(".statscount").html(iCount);
      //$(".statscolor").css('background',$.trim($(ctrl).attr('style').split(':')[1]));
  }
  else
  {
    $(".bucketTooltip").hide();
    $("#tblBucketKeywordStats").html('');
  }
}


/*

  defination : delete selected tagging

*/
function fnDeleteTagging(field,itemid,start,end,bucketname,event)
{
    event.preventDefault();
    var modifiedby='${userid}';
    var modifieddt=new Date();
    var tagInfo={"field":$.trim(field),"itemid":$.trim(itemid),"start":parseInt(start),"end":parseInt(end),"bucketname":$.trim(bucketname),"modifiedby":modifiedby,"modifieddt":modifieddt};
    var res=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(strSelectedProfileID)
    });
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/doDeleteBucket?dbName='+res[0].profile_name+'&Path=0&objId='+strSelectedProfileID+'&TagInfo='+JSON.stringify(tagInfo));
    req.send();
    req.onload = function () 
    { 
        $("#codebucket_"+itemid+"_"+field.replace(/\s/g,'')+"_"+start+"_"+end).contents().unwrap();
        $("#ancbucket_"+itemid+"_"+field.replace(/\s/g,'')+"_"+start+"_"+end).remove();
        var obj = JSON.parse(req.response);
        if(obj.Result==='Bucket_deleted')
        {
          _getRefreshBucket(field);
        }
        else if(obj.Result==='TaggingNotFound')
        {
            $("#div_loader").hide();
            __alertfy('alertfy_Info','Selected tag is not found in database. Kindly refresh the page and try again');
        }
        else if(obj.Result==='BucketNotFound')
        {
            $("#div_loader").hide();
            __alertfy('alertfy_Info','Bucket not found in database. Kindly refresh the page and try again');
        }
    };
}


/*

  defination : Show all bucket in menu on mouse up event

*/
function bindBucketsRightMenu()
{
    var strHTML='';
    if(arrSelectedProfileInfos.length>0)
    {
      if(arrSelectedProfileInfos[0].bucket!==undefined)
      {
        for(var i=0;i<arrSelectedProfileInfos[0].bucket.length;i++)
        {
          //strHTML=strHTML+'<li name="'+arrSelectedProfileInfos[0].bucket[i].bucketname+'" data-action="addTextInBucket"><span>'+arrSelectedProfileInfos[0].bucket[i].bucketname+'</span> <span style="background:'+arrSelectedProfileInfos[0].bucket[i].color+';color:#fff !important;">'+arrAlphabets[i]+'</span></li>';

          strHTML=strHTML+'<li name="'+arrSelectedProfileInfos[0].bucket[i].bucketname+'">';
          strHTML=strHTML+'<span name="'+arrSelectedProfileInfos[0].bucket[i].bucketname+'" data-action="addTextInBucket">'+arrSelectedProfileInfos[0].bucket[i].bucketname+'</span> ';
          strHTML=strHTML+'<span name="'+arrSelectedProfileInfos[0].bucket[i].bucketname+'" data-action="addTextInBucket" style="background:'+arrSelectedProfileInfos[0].bucket[i].color+';color:#fff !important;">'+arrAlphabets[i]+'</span>';
         
          strHTML=strHTML+'<div>';
          strHTML=strHTML+'<input type="text" class="bucketComment" id="ta_BucketComment_'+arrSelectedProfileInfos[0].bucket[i].bucketname+'" placeholder="Enter comment" />';
          strHTML=strHTML+'</div>';
          
          strHTML=strHTML+'</li>';

        }
      }
    }
    $("#ul_buckets").html('');
    $("#ul_buckets").html(strHTML);
    strHTML='';
    $(".custom-menu li > span").click(function()
    {
      switch($(this).attr("data-action")) 
      {
          case "addTextInBucket": addBucketTextDB(this); break;
          case "Indication": alert("Indication"); break;
          case "Custom": alert("Custom"); break;
      }
      $(".custom-menu").hide(100);
    });
    if($("#ul_buckets li").length>10)
    {
        $("#ul_buckets").css('height','300px');
        $("#ul_buckets").css('overflow-y','auto');
    }	
    enableBucketing();
}

function _getRefreshBucket(field)
{
    _isRefresh=0;
    var res=arrAllProfiles.filter(function(el)
    {
      return $.trim(el._id)===$.trim(strSelectedProfileID)
    })
    if(res.length>0)
    {
      var req = new XMLHttpRequest();
      req.open('GET', '/_api/MstSelectedProfileInfos?dbName='+res[0].profile_name+'&Path=0');
      req.send();
      req.onload = function () 
      {
          var obj = JSON.parse(req.response);
          arrSelectedProfileInfos=obj;
          _isRefresh=1;
          showBucket();
          /*
          setTimeout(function()
          { 
            if($('#div_columns [name='+field+']').css('display') == 'none')
            {
              //$('#div_columns [name='+field+']').slideToggle();
              //$('#div_columns [name='+field+']').show();
            }
          }, 1000);
          */
      }
    }
}

function _checkBucketNames(buckets)
{
    var arr = [];
    var isValid=true;

    buckets.filter(function(item){
      return item.type=='custom';
    }).forEach(function(item)
    {
      if(arr.indexOf(item.bucketname)==-1)
        arr.push(item.bucketname);
      else
        isValid=false;
    });
    return isValid
    /*
    $(".custombucket").removeClass("duplicatebucket");
    $(".custombucket").each(function()
    {
        var value = $(this).val();
        if (arr.indexOf(value) == -1)
            arr.push(value);
        else
        {
          $(this).addClass("duplicatebucket");
          isValid=false;
        }
    });
    return isValid;
    */
}


function _checkBucketExistence()
{
    if($.trim($("#ddl_BucketType").val())==='CustBucket' && $.trim($("#txt_CustomBucketName").val())!=='')
    {
      var res=arrAllProfiles.filter(function(el)
      {
        return $.trim(el._id)===$.trim(strSelectedProfileID)
      })
      if(res.length>0)
      {
        var req = new XMLHttpRequest();
        req.open('GET', '/_api/checkBucketExistence?dbName='+res[0].profile_name+'&Path=0&bucketname='+$.trim($("#txt_CustomBucketName").val()));
        req.send();
        req.onload = function () 
        {
            var obj = JSON.parse(req.response);
            if(obj.Result==='DuplicacyFound')
            {
              return "DuplicacyFound";
            }
            else if(obj.Result==='Valid')
            {
              return "Valid";
            }
        }
      }
      else
      {
        return "ProfileNotFound";
      }
    }
    else
    {
      return "WrongSelection";
    }
}


