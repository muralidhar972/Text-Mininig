/**@typedef {Object} FieldInfo
 * @property {string} name
 * @property {boolean} req_expand
 */

/**@typedef {Object} ProfileInfoItem
 * @property {string} _id
 * @property {string} db_title
 * @property {string} db_name
 * @property {string} server_path
 * @property {string} desc
 * @property {number} isActive
 * @property {string[]} filterType
 * @property {string[]} dateField
 * @property {FieldInfo[]} fields
 */


var profSubmit = document.getElementById('profilesubmit');
var profDismis = document.getElementById('profiledismiss');
var profPopupBtn = document.getElementById('showProfilePage');

var StartDate1 = $("[placeholder='Start date']").datepicker2({
    changeMonth: true,
    changeYear: true,
    yearRange: "-50:+0"
}, '#myModal .modal-content');
var EndDate1 = $("[placeholder='End date']").datepicker2({
    changeMonth: true,
    changeYear: true,
    yearRange: "-50:+0"
}, '#myModal .modal-content');

var $scope;
var model =
    (function ()
    {
        function loadSources()
        {
            var cobj = asyncHelper.getCoupledObj();
            var req = new XMLHttpRequest()
            req.open("GET", "/_api/Sources");
            req.onload = function ()
            {
                model.sources = JSON.parse(req.response);

                if (model.sources.error)
                {
                    alert(model.sources.error);
                    return false;
                }
                model.sources.forEach(function (source)
                {
                    source.fields = source.fields.filter(function (f)
                    {
                        return (f.type instanceof Array && f.type.length == 1 && f.type[ 0 ] == 'string');
                    });
                });
                cobj.sender.invokeSuccess();
            }
            req.send();
            return cobj.recipient;
        }

        function loadGlobalBuckets()
        {
            var cobj = asyncHelper.getCoupledObj();
            var req = new XMLHttpRequest()
            req.open("GET", "/_api/globalBuckets");
            req.onload = function ()
            {
                model.globalbuckets = JSON.parse(req.response);
                if (model.globalbuckets.error)
                {
                    alert(model.globalbuckets.error);
                    return false;
                }
                cobj.sender.invokeSuccess();
            }
            req.send();
            return cobj.recipient;
        }

        return {
            loadData: function ()
            {
                var cobj = asyncHelper.getCoupledObj();
                asyncHelper.execParallel(
                    loadSources,
                    loadGlobalBuckets
                ).success(function ()
                {
                    cobj.sender.invokeSuccess();
                });
                return cobj.recipient;
            },

            /**@type {ProfileInfoItem[]} */
            sources: null,
        }
    })();


angular
    .module('app1', [ 'ui.multiselect' ])
    .controller('ctrl1', function ($scope)
    {
        function init()
        {
            $scope.classification = [];
            $scope.keywords = [];
            $scope.scores = [];
            $scope.searchwords = '';
            $scope.buckets = [];
        }

        init();

        model.loadData().success(function ()
        {
            window.$scope = $scope;
            $scope.sources = model.sources;
            $scope.$digest();
        });

        $scope.__filterGlobalBucket = function() 
        {
            $scope.globalbuckets=[];
            $scope.globalbuckets=model.globalbuckets.filter(function(e){return e.dbname===$scope.mde.db_name});
            $scope.globalbuckets.push({
                bucketname:'Custom bucket',
                description:'NA',
                dbname:'',
                type:'custom',
                status:'active',
                createdby:'',
                modifiedby:'',
                createddt:'',
                modifieddt:'',
                color:'',
                bucketdetail:[]
            });
        };

        $scope.addKeywords = function ()
        {
            $scope.keywords.push({
                name: '',
                fields: [],
                words: ''
            });

            setTimeout(function ()
            {
                addSelective();
            }, 100);

        }

        $scope.addBuckets = function ()
        {
            if($scope.buckets===undefined)
                $scope.buckets=[];

            if($scope.mde!==undefined)
            {
                $scope.buckets.push({  //type: 'custom',
                    type: '',
                    description: '',
                    "color": arrDarkColors[ $scope.buckets.length ],
                    "bucketname": '',
                    "status": "active",
                    "createdby": "${userid}",
                    "createddt": new Date(),
                    "modifiedby": "${userid}",
                    "modifieddt": new Date(),
                    "bucketdetail": []
                });

                setTimeout(function ()
                {
                    vdtBucket();
                }, 100);
            }
        }

        $scope.getSelected = function(bucketName,type)
        {
            if(type=='custom')
            {
                bucketName = 'Custom bucket';
            }
            return $scope.globalbuckets.filter(function(item)
            {
                return item.bucketname == bucketName
            })[0]; 
        }

        $scope.copyBucket = function(srcBuck, dstBuck)
        {
            Object.keys(srcBuck).forEach(function(key)
            {
                if(!key.startsWith('$$'))
                {
                    if(srcBuck.type=='custom' && key=='color')
                    {

                    }
                    else
                        dstBuck[key] = srcBuck[key];
                    
                }
            });
        }

        $scope.addScores = function ()
        {
            $scope.scores.push({
                name: '',
                criteria: '',
                weight: ''
            });
        }

        $scope.validate = function (score) { }

        profSubmit.onclick = function ()
        {

            var req2 = new XMLHttpRequest()
            req2.open("GET", "/_api/MstProfiles");
            req2.send();

            req2.onload = function ()
            {
                var stopSubmit = false;
                var stopReason = [];

                var profiles = JSON.parse(req2.response);
                if (profiles.error)
                {
                    alert(profiles.error);
                    return;
                }

                var isValidBucket = _checkBucketNames($scope.buckets);
                if (!isValidBucket)
                {
                    stopSubmit = true;
                    stopReason.push({ msg: 'Duplicacy exist in buckets name. Bucket name should be unique.' });
                }

                if (/[\!@#\$%\^&\*\)\(\+\-\=\[\]\{\};:'",<.>/?\\\|\s`~]/.test($scope.pfname))
                {
                    stopSubmit = true;
                    stopReason.push({ msg: "Profile name is invalid. Please don't use special symbols" });
                }

                var profileNames = profiles.map(function (pf) { return pf.profile_name });
                if (profileNames.indexOf($scope.pfname) >= 0 && $scope.mode == 'new')
                {
                    stopSubmit = true;
                    stopReason.push({ msg: "Profile name already exists." });
                }

                var categories = $scope.keywords.map(function (i)
                {
                    return {
                        catname: i.name,
                        fields: i.fields.map(function (j) { return j.name }),
                        keywords: i.words.split(',')
                    }
                })

                var buckets = $scope.buckets.map(function (i)
                {
                    return {
                        bucketname: i.bucketname,
                        dbname: i.dbname,
                        description: i.description,
                        status: i.status,
                        type: i.type,
                        color: i.color
                    }
                })

                var tempMap = {}
                categories.forEach(function (k)
                {
                    tempMap[ k.catname ] = true
                    if (!/^.+\d+$/.test(k.catname))
                    {
                        stopSubmit = true;
                        stopReason.push({ msg: "Keywords categorie name '" + k.catname + "' is prohibited. Please use a name such that it ends in a number for e.g. '" + k.catname + '1\'' });
                    }
                });

                if (Object.keys(tempMap).length != categories.length)
                {
                    stopSubmit = true;
                    // error duplication of cateogrynames
                    stopReason.push({ msg: "Keywords categories should have unique name." });
                }


                var valid = $scope.keywords.map(function (j) { return j.name });

                $scope.scores.forEach(function (i)
                {
                    var response = LogicalParser.checkValid(i.criteria, valid);
                    console.log(response);
                    if (response.invalidWord instanceof Array && response.invalidWord.length == 0 && response.errors.length == 0)
                    {

                        if (response.parseTree.token.type != 3)
                        {
                            stopSubmit = true;
                            stopReason.push({ msg: "Invalid expression " + i.criteria })
                        }
                        var obj = convert(response.parseTree);

                        function convert(obj)
                        {
                            var retObj = {
                                sym: obj.token.value,
                                type: TLParser.TokenEnum[ obj.token.type ],
                            }
                            if (obj.children)
                                retObj.children = obj.children.map(function (k) { return convert(k) })
                            return retObj;
                        }
                        i.parsed = obj;
                    }
                    else
                    {
                        stopSubmit = true;
                        // error critiera is wrong
                        if (response.invalidWord instanceof Array)
                        {
                            stopReason.push({ msg: "Invalid keywords found : " + response.invalidWord.join(", ") });
                        }
                        else
                        {
                            stopReason.push({ msg: "Scoring criteria has syntax error. " + response.reason });
                        }
                        if (response.errors instanceof Array && response.errors.length > 0)
                        {
                            response.errors.forEach(function (k)
                            {
                                stopReason.push({ msg: k });
                            });

                        }
                    }

                })

                var scoring = $scope.scores.map(function (i)
                {
                    if (tempMap[ i.name ])
                    {
                        stopSubmit = true;
                        stopReason.push({ msg: "Scoring criteria name should be unique amongst other scoring criteria as well as the keyword categories." })
                    }
                    tempMap[ i.name ] = true;
                    return {
                        name: i.name,
                        weight: i.weight,
                        query: i.criteria,
                        criteria: i.parsed,
                    }
                });
                
                var profileCreationInfo = {
                    profile_name: $scope.pfname,
                    sourceId: $scope.mde._id,
                    categories: categories,
                    scoring: scoring,
                    bucket: buckets
                };

                if(categories.length==0)
                {
                    stopSubmit=true;
                    stopReason.push({msg:"There needs to be atleast one keyword."})
                }

                if(scoring.length==0)
                {
                    stopSubmit=true;
                    stopReason.push({msg:"There needs to be atleast one scoring criteria."})
                }

                if ($scope.mde.filterType[ 0 ] == 'date')
                {

                    profileCreationInfo.filter = 'date';
                    profileCreationInfo.startDate = $scope.startDate;
                    profileCreationInfo.endDate = $scope.endDate;
                }
                if ($scope.mde.filterType[ 0 ] == 'keyword')
                {
                    profileCreationInfo.filter = 'keyword';
                    profileCreationInfo.keywords = $scope.searchwords.replace(/\n/g, ',').split(",").map(function (k) { return k.trim() });
                }


                if (stopSubmit)
                {
                    alert('There are issues:\n' + stopReason.map(function (msgs)
                    {
                        return msgs.msg;
                    }).join("\n"));
                }
                else
                {

                    var req = new XMLHttpRequest();
                    if ($scope.mode == 'new')
                    {
                        req.open('POST', '/_api/createprofile');
                        req.setRequestHeader('content-type', 'application/json');
                        req.send(JSON.stringify(profileCreationInfo));

                        req.onload = function ()
                        {
                            try
                            {
                                ProgressPercentage = 1;
                                blockMsg();
                                setTimeout(function ()
                                {
                                    fnChangeProgressBarStatus(profileCreationInfo.profile_name);
                                }, 5000);
                                var obj = JSON.parse(req.response);
                                if (obj.error)
                                {
                                    alert(obj.error);
                                    return;
                                }
                            }
                            catch (ex)
                            {

                            }
                            $('#myModal').modal('hide')
                        }
                    }
                    else
                    {
                        req.open('POST', '/_api/querymodifyprofile');

                        req.setRequestHeader('content-type', 'application/json');
                        req.send(JSON.stringify(profileCreationInfo));

                        req.onload = function ()
                        {
                            try
                            {
                                var obj = JSON.parse(req.response);
                                if (obj.error)
                                {
                                    alert(obj.error);
                                    return;
                                }

                                if (obj.deleteCount > 0)
                                {
                                    if (confirm(obj.deleteCount + " no of records will be deleted. Please confirm?"))
                                    {
                                        proceedToModify();
                                    }
                                }
                                else
                                    proceedToModify();

                                function proceedToModify()
                                {
                                    if(profileCreationInfo.bucket===undefined)
                                    {
                                        profileCreationInfo.bucket=[];
                                    }
                                    var req = new XMLHttpRequest();

                                    req.open('POST', '/_api/modifyprofile');

                                    req.setRequestHeader('content-type', 'application/json');
                                    req.send(JSON.stringify(profileCreationInfo));
                                    req.onload = function ()
                                    {
                                        try
                                        {
                                            ProgressPercentage = 1;
                                            blockMsg();
                                            setTimeout(function ()
                                            {
                                                fnChangeProgressBarStatus(profileCreationInfo.profile_name);
                                            }, 5000);

                                            var obj = JSON.parse(req.response);
                                            if (obj.error)
                                            {
                                                alert(obj.error);
                                                return;
                                            }
                                        }
                                        catch (ex)
                                        {

                                        }

                                    }

                                }
                            }
                            catch (ex)
                            {

                            }
                            $('#myModal').modal('hide')
                        }
                    }
                }
                //}
            }
        }

        profDismis.onclick = function ()
        {
            $('#myModal').modal('hide')
        }

        profPopupBtn.onclick = function ()
        {
            init();
            $scope.mode = 'new';
            $scope.$apply();
            $('#myModal').modal('show')

        }

        $scope.profileEdit = function (profileID)
        {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/_api/getProfileInfo/" + profileID);
            xhr.send();
            xhr.onload = function ()
            {

                var profileInfoObj = JSON.parse(xhr.response);
                if (profileInfoObj.error)
                {
                    alert(profileInfoObj.error);
                    return
                }
                $scope.mode = 'edit';
                $scope.profileInfo = profileInfoObj;
                $scope.keywords.length = 0;
                $scope.scores.length = 0;


                // set profile_name
                $scope.pfname = profileInfoObj.profile_name;

                // select source
                $scope.mde = $scope.sources.filter(function (i)
                {
                    return i.db_name == profileInfoObj.db_name;
                })[ 0 ];

                $scope.$apply();

                // get and tranform keywords

                var tcat = profileInfoObj.categories.map(function (i)
                {
                    var retObj = {
                        name: i.catname,
                        words: i.keywords.join(',')
                    }
                    retObj.fields = $scope.mde.fields.filter(function (j)
                    {
                        return i.fields.indexOf(j.name) >= 0;
                    })
                    // fields logic

                    return retObj;
                });
                tcat.forEach(function (i) { $scope.keywords.push(i); })
                $scope.$apply();

                // get and transform score
                var tscore = profileInfoObj.scoring.map(function (i)
                {
                    return {
                        name: i.name,
                        weight: i.weight,
                        criteria: i.query,
                        parsed: i.criteria
                    };
                });
                tscore.forEach(function (i) { $scope.scores.push(i); });
                $scope.$apply();

                // apply keywords
                try
                {

                    var fo = profileInfoObj.filterObj;
                    switch (fo.type)
                    {
                        case "daterange":
                            var startDate = new Date(fo.from);
                            var endDate = new Date(fo.to);

                            StartDate1.datepicker('setDate', startDate);
                            EndDate1.datepicker('setDate', endDate);
                            $scope.startDate = (startDate.getMonth() + 1) + "/" + startDate.getDate() + "/" + startDate.getFullYear();
                            $scope.endDate = (endDate.getMonth() + 1) + "/" + endDate.getDate() + "/" + endDate.getFullYear();

                            $scope.$apply();
                            break;
                        case "keyword":
                            $scope.searchwords = fo.keywords.join(", ");
                            break;
                    }
                }
                catch (ex)
                {

                }

                // apply bucket
                $scope.buckets = profileInfoObj.bucket;

                $scope.globalbuckets=[];
                $scope.globalbuckets=model.globalbuckets.filter(function(e){return e.dbname===$scope.mde.db_name});
                $scope.globalbuckets.push({
                    bucketname:'Custom bucket',
                    description:'NA',
                    dbname:'',
                    type:'custom',
                    status:'active',
                    createdby:'',
                    modifiedby:'',
                    createddt:'',
                    modifieddt:'',
                    color:'',
                    bucketdetail:[]
                });

                $('#myModal').modal('show');
            }
        }

        $scope.getUnfound = function ()
        {
            var profileCreationInfo = {
                sourceId: $scope.mde._id
            };
            if ($scope.mde.filterType[ 0 ] == 'keyword')
            {
                profileCreationInfo.filter = 'keyword';
                profileCreationInfo.keywords = $scope.searchwords.replace(/\n/g, ',').split(",").map(function (k) { return k.trim() });
            }
            var req = new XMLHttpRequest();

            req.open('POST', '/_api/getUnfound');
            req.setRequestHeader('content-type', 'application/json');
            req.send(JSON.stringify(profileCreationInfo));

            req.onload = function ()
            {
                var response = JSON.parse(req.response);
                var datacode = response.missing.join('\n');

                var blob1 = new Blob([ datacode ], { type: 'text/plain' });

                var ua = window.navigator.userAgent;
                var ms_ie = /MSIE|Trident/.test(ua);

                if (ms_ie)
                {
                    navigator.msSaveBlob(blob1, 'Mismatched.txt');
                }
                else
                {
                    var anchor = document.createElement('a');
                    anchor.download = 'Mismatched.txt';
                    anchor.href = URL.createObjectURL(blob1);
                    document.body.appendChild(anchor);
                    anchor.click();

                    setTimeout(function()
                    {
                        document.body.removeChild(anchor);
                    },1000);
                }
            }
        }

    });



