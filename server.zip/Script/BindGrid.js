var ss = [];

var sharedDataSource;
function ReadData() 
{
    var req = new XMLHttpRequest();
    req.open('GET', '/_api/data');
    req.send();
    req.onload = function () {
        var obj = JSON.parse(req.response);
        debugger;
        var reqData = obj.map(function (item) {
            return {
                'PatentNum': item.patent_num,
                'Title': item.title,
                'Details': item.combined_columns,
                'Date': '',
                'Url': item.url,
                'Score': '',
                'relevant': undefined,
            }
        });
        /*
        var sharedDataSource = new kendo.data.DataSource({
            data:reqData 
        });
        */
        sharedDataSource = new kendo.data.DataSource({
            data: reqData
        });
        bindGrid();
        // reqData.forEach(function (item) {
        //     ss.addRow(item);
        // });
        debugger;
    };
}
ReadData();
/*
    var dbSource=
    [
        {
            employee: "Joe Smith",
            sales: 2000
        },
        {
            employee: "Jane Smith",
            sales: 2250
        },
        {
            employee: "Will Roberts",
            sales: 1550
        }
    ]
*/

function bindGrid() 
{
    $("#grid").kendoGrid({
        dataSource:     ,
        height: 550,
        groupable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns:
            [
                {
                    field: "PatentNum",
                    title: "PatentNum",
                    width: 200
                },
                {
                    field: "Title",
                    title: "Title",
                    width: 200
                },
                {
                    field: "Details",
                    title: "Details",
                    width: 200
                },
                {
                    field: "Date",
                    title: "Date",
                    width: 200
                },
                {
                    field: "Url",
                    title: "Url",
                    width: 200
                },
                {
                    field: "Score",
                    title: "Score",
                    width: 200
                },
                {
                    field: "relevant",
                    title: "relevant",
                    width: 200
                }
            ]
    });
    $(".k-pager-refresh").trigger('click');
}
