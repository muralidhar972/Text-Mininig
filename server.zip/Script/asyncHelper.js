

var asyncHelper = {
    getCoupledObj: function getCoupledObj()
    {
        var ret = {
            hasSucceeded: false,
            hasFailed: false,
            arguments: null,
            sender: {
                invokeSuccess: function ()
                {
                    ret.hasSucceeded = true;
                    ret.arguments = arguments;
                    if (ret.successFn)
                    {
                        ret.successFn.apply(ret.recipient, arguments);
                    }
                },
                invokeFail: function ()
                {
                    ret.hasFailed = true;
                    ret.arguments = arguments;
                    if (ret.failFn)
                    {
                        ret.failFn.apply(ret.recipient, arguments);
                    }
                }
            },
            recipient: {
                success: function (fn)
                {
                    if (typeof fn === 'function')
                    {
                        ret.successFn = fn;
                        if (ret.hasSucceeded)
                        {
                            ret.successFn.apply(ret.recipient, ret.arguments);
                        }
                    }

                },
                fail: function (fn)
                {
                    if (typeof fn === 'function')
                    {
                        ret.failFn = fn;
                        if(ret.hasFailed)
                        {
                            ret.failFn.apply(ret.recipient, arguments);
                        }
                    }
                }
            }
        }
        return ret;
    },

    
    execParallel: function execParallel()
    {
        /**@type {any[]} */
        var fns = arguments;

        var cobj = asyncHelper.getCoupledObj();

        var cnt = 0;
        var mat = 0;

        var retCol = [];
        var retIds = {};

        /**
         * @type {{id:number,fn:Function,args:any[],thisArg:any}[]}
         */
        var postExec = [];

        for (var i = 0; i < fns.length; i++)
        {
            var fn = fns[i];
            (function ()
            {
                if (typeof fn === 'function')
                {
                    cnt++;

                    var ret = fn();
                    ret.success(function ()
                    {
                        mat++;
                        retCol.push({fn:fn, returns:arguments});
                        post();
                    });

                    ret.fail(function ()
                    {
                        mat++;
                        retCol.push({fn:fn, returns:arguments});
                        post();
                    });
                }

                if (typeof fn === 'object' && typeof fn.fn == 'function')
                {
                    var efn = fn.fn;
                    var suc = fn.success;
                    var fail = fn.fail;
                    var arg = fn.args;
                    var id = fn.id;
                    cnt++;

                    var ret = efn.apply(this, arg);

                    ret.success(function ()
                    {
                        mat++;
                        if(id)
                            retIds[id] = arguments;
                        retCol.push({ fn: fn, returns: arguments });
                        if (typeof suc === 'function')
                        {
                            postExec.push({
                                args: arguments,
                                fn: suc,
                                thisArg: fn
                            })
                        }
                        post();
                    });

                    ret.fail(function ()
                    {
                        mat++;
                        retCol.push({ fn: fn, returns: arguments });
                        if (typeof fail === 'function')
                        {
                            postExec.push({
                                args: arguments,
                                fn: fail,
                                thisArg: fn
                            })
                        }
                        post();
                    });
                }
            })();
        }



        function post()
        {
            if (mat == cnt)
            {
                if (postExec.length > 0)
                {
                    postExec.forEach(function (warrant)
                    {
                        warrant.fn.apply(warrant.thisArg, warrant.args);
                    });
                }



                cobj.sender.invokeSuccess(retCol, retIds);
            }
        }

        return cobj.recipient;

    }
}


