var globalRes;
const MongoClient = require('mongodb').MongoClient;
const ObjectId = require('mongodb').ObjectId;
const express = require('express');
const cluster = require("cluster")
var numWorkers = require('os').cpus().length;
const debuggerAttached = typeof v8debug === 'object' || /--debug|--inspect/.test(process.execArgv.join(' '));

const config = require("./config.json");
var mongoUrl = config.central_mongo;


if (cluster.isMaster && !debuggerAttached)
{
    console.log('Master cluster setting up ' + numWorkers + ' workers...');

    for (var i = 0; i < numWorkers; i++)
    {
        cluster.fork();
    }

    cluster.on('online', function (worker)
    {
        console.log('Worker ' + worker.process.pid + ' is online');
    });

    cluster.on('exit', function (worker, code, signal)
    {
        console.log('Worker ' + worker.process.pid + ' died with code: ' + code + ', and signal: ' + signal);
        console.log('Starting a new worker');
        cluster.fork();
    });

    var onlineSessions = {};

    cluster.on('message', (worker, message, handle) =>
    {
        if (arguments.length === 2)
        {
            handle = message;
            message = worker;
            worker = undefined;
        }

        switch (message.cmd)
        {
            case "ping":
                var ping = message.ping;
                onlineSessions[ ping.id ] = ping;
                break;

            case "query":
                var queryObj = message.get;
                var queryID = message._id;

                switch (queryObj.query)
                {
                    case "ping":
                        var now = new Date();
                        Object.keys(onlineSessions).forEach(key =>
                        {
                            var expires = new Date(onlineSessions[ key ].expires);

                            if (expires < now)
                            {
                                delete onlineSessions[ key ];
                            }
                        });
                        worker.send({ _id: queryID, response: onlineSessions });
                        break;
                }

                break;
        }
    });

}
else
{
    var app = express();
    var limit = 500;

    app.get('/integrated/:profilename/', function (req, res)
    {

        console.log('requrested ', req.params.profilename, 'skip 0');
        globalRes = res;
        getProfileInfo(req.params.profilename, 0, function (err, response)
        {
            if (response.collection.length >= limit)
                response.next_url = "/integrated/" + req.params.profilename + "/" + limit;
            res.json(response);
            res.end();
        });
    });

    app.get('/integrated/:profilename/:skip', function (req, res)
    {
        var skipValue = parseInt(req.params.skip);
        console.log('requrested ', req.params.profilename, 'skip ' + skipValue);
        globalRes = res;
        getProfileInfo(req.params.profilename, skipValue, function (err, response)
        {
            if (response.collection.length >= limit)
                response.next_url = "/integrated/" + req.params.profilename + "/" + (limit + skipValue);
            res.json(response);
            res.end();
        });
    });

    /**@type { (profileName:string, callback : ()=>void )=>void } */
    var getProfileInfo;

    getProfileInfo = function (profileName, skip, callback)
    {
        console.log('Profile query ', profileName);
        MongoClient.connect(mongoUrl, { useNewUrlParser: true }, function (err, db)
        {
            var masterDB = db.db('Master_DB');


            masterDB.collection('ProfileInfo').findOne({ profile_name: profileName }, function (err, masterProfileObj)
            {
                var SourceDBName = masterProfileObj.db_name;
                var SourceDBPath = masterProfileObj.db_source_path;
                var ProfileDBName = masterProfileObj.profile_name;
                var ProfileDBPath = masterProfileObj.profile_path;

                var arrInfosDataFilter = new Array();
                var arrFilterData = new Array();
                url = "mongodb://" + ProfileDBPath + "/";
                MongoClient.connect(url, { useNewUrlParser: true }, function (err, db2)
                {
                    if (err) throw err;
                    var dbo = db2.db(ProfileDBName);
                    dbo.collection("data").find({}).skip(skip).limit(limit).toArray(function (err, arrData)
                    {
                        if (err) throw err;

                        dbo.collection('infos').findOne(function (err, config)
                        {
                            if (arrData.length > 0)
                            {
                                var inId = arrData.map(k => ObjectId(k.parent));

                                dbo = db2.db(SourceDBName);
                                dbo.collection("data").find({ _id: { $in: inId } }).toArray(function (err, arrFilterData)
                                {
                                    if (err) throw err;

                                    var _id_map = {};
                                    arrFilterData.forEach(element =>
                                    {
                                        _id_map[ element._id ] = element;
                                    });

                                    var newArr = arrData.map(i =>
                                    {
                                        var obj = {};
                                        var source_data_obj = _id_map[ i.parent ];
                                        Object.keys(source_data_obj).forEach(j => obj[ j ] = source_data_obj[ j ]);
                                        Object.keys(i).forEach(j => obj[ j ] = i[ j ]);
                                        return obj;
                                    });
                                    db2.close();
                                    db.close();
                                    //masterProfileObj.close();
                                    callback(err, { collection: newArr, configuration: config });
                                });
                            }
                        });
                    });
                });
            });
        });
    }

    app.listen(config.dataopsPort);
}

if (!debuggerAttached)
    process.on('uncaughtException', function (err)
    {
        // globalRes.write(JSON.stringify({ error: err }));
        // globalRes.end();
        console.log('Caught exception: ' + err);
    });