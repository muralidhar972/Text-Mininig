var fs = require('fs');
 
var contents = fs.readFileSync('uspto_80 p3.csv', 'utf8');

var txts = contents.split("\n");
console.log(txts.length);
// var header = txts.shift();
// var offset = 350+150+150+50+50;
// txts.splice(0,offset);
// txts.length = Math.min(50,txts.length);
// txts.unshift(header);
 txts.pop();

console.log(txts.length);
console.log(txts.length + offset);



var doesntEndsWithQuote = /[^"](?:"")*$/;
/**@param {string} txt */
function splitCSV(txt)
{
    /**@type {string[]} */
    var ret = txt.split(',');

    for(var i=0; i<ret.length; i++)
    {
        var str = ret[i];
        if(str.startsWith('"'))
        {
            str = str.substring(1,str.length);
            ret[i] = str;
            while(true)
            {
                str = ret[i+1];
                if(!doesntEndsWithQuote.test(str))
                {
                    str = str.substring(0,str.length-1);
                    ret[i] += "," +str;
                    ret.splice(i+1,1);
                    break;
                }
                else
                {
                    ret[i]+="," + str;
                    ret.splice(i+1,1);
                }
            }
        }
    }
    return ret;
}
txts = txts.map((c,i)=>{console.log(i);return splitCSV(c);});



/**@param {string[][]} arr */
function arr2dToObj(arr)
{
    var ret = [];
    var fields = arr[0];
    for(var i=1; i<arr.length; i++)
    {
        var obj = {};
        var row = arr[i];

        for(var j=0; j<fields.length && j<row.length; j++)
        {
            obj[fields[j]] = row[j];
        }
        ret.push(obj);
    }
    return ret;
}

var objtxt = arr2dToObj(txts);
txts.length = 0;
objtxt = JSON.stringify(objtxt);

fs.appendFile('jsontxt6.txt', objtxt, function (err) {
  if (err) throw err;
  console.log('Saved!');
});



var fs = require('fs');
var contents = [];
var contents1 = JSON.parse(fs.readFileSync('jsontxt.txt', 'utf8'));
contents.push.apply(contents,contents1);
contents1.length=0;
var contents2 = JSON.parse(fs.readFileSync('jsontxt2.txt', 'utf8'));
contents.push.apply(contents,contents2);
contents2.length=0;
var contents3 = JSON.parse(fs.readFileSync('jsontxt3.txt', 'utf8'));
contents.push.apply(contents,contents3);
contents3.length=0;
var contents4 = JSON.parse(fs.readFileSync('jsontxt4.txt', 'utf8'));
contents.push.apply(contents,contents4);
contents4.length=0;
var contents5 = JSON.parse(fs.readFileSync('jsontxt5.txt', 'utf8'));
contents.push.apply(contents,contents5);
contents5.length=0;
var contents6 = JSON.parse(fs.readFileSync('jsontxt6.txt', 'utf8'));
contents.push.apply(contents,contents6);
contents6.length=0;


objtxt = JSON.stringify(contents);
fs.appendFile('jsonfinal.txt', objtxt, function (err) {
    if (err) throw err;
    console.log('Saved!');
  });
  