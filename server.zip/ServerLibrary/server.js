var globalRes;

const fs = require('fs');
var path = require('path');
const config = require("./config.json");
const express = require('express');
const cluster = require("cluster")
var numWorkers = require('os').cpus().length;
const Cryptr = require('cryptr');
const serverOTP = "32423813";
const serverEncryption = new Cryptr(serverOTP);
const debuggerAttached = typeof v8debug === 'object' || /--debug|--inspect/.test(process.execArgv.join(' '));
const cookieParser = require('cookie-parser');

//var workkbook = xlsx.readFile('data/Relevant_uspto_sample_80_Review.xlsx');
//var data = xlsx.utils.sheet_to_json(workkbook.Sheets[workkbook.SheetNames[0]]);

var mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.wav': 'audio/wav',
    '.mp4': 'video/mp4',
    '.woff': 'font-woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'font/otf',
    '.svg': 'image/svg+xml',
    '.sfnt': 'font/sfnt'
};

if (cluster.isMaster && !debuggerAttached)
{
    console.log('Master cluster setting up ' + numWorkers + ' workers...');

    for (var i = 0; i < numWorkers; i++)
    {
        cluster.fork();
    }

    cluster.on('online', function (worker)
    {
        console.log('Worker ' + worker.process.pid + ' is online');
    });

    cluster.on('exit', function (worker, code, signal)
    {
        console.log('Worker ' + worker.process.pid + ' died with code: ' + code + ', and signal: ' + signal);
        console.log('Starting a new worker');
        cluster.fork();
    });

    var onlineSessions = {};

    cluster.on('message', (worker, message, handle) =>
    {
        if (arguments.length === 2)
        {
            handle = message;
            message = worker;
            worker = undefined;
        }

        switch (message.cmd)
        {
            case "ping":
                var ping = message.ping;
                onlineSessions[ ping.id ] = ping;
                break;

            case "query":
                var queryObj = message.get;
                var queryID = message._id;

                switch (queryObj.query)
                {
                    case "ping":
                        var now = new Date();
                        Object.keys(onlineSessions).forEach(key =>
                        {
                            var expires = new Date(onlineSessions[ key ].expires);

                            if (expires < now)
                            {
                                delete onlineSessions[ key ];
                            }
                        });
                        worker.send({ _id: queryID, response: onlineSessions });
                        break;
                }

                break;
        }
    });

} else
{
    var queryID = 0;
    var queryHandlers = {};

    function queryMasterProcess(obj, callback)
    {
        queryID++;
        var query = { _id: queryID, get: obj, cmd: 'query' };
        queryHandlers[ queryID ] = callback;
        if(!debuggerAttached)
        process.send(query);
    }

    process.on('message', (msg) =>
    {
        if (msg._id)
        {
            var handler = queryHandlers[ msg._id ];
            if (typeof handler == 'function')
            {
                delete queryHandlers[ msg._id ];
                handler(msg.response);
            }
        }
    });

    var app = express();
    app.use(cookieParser());
    
    //all file parser
    app.get(/^\/(?!(?:_api)|(?:ServerLibrary)).*/, (req, res) =>
    {
        var url1 = req.url;
        if (url1 == '/') url1 = 'HTML/index.html';
        var ext = path.extname(url1);
        var contentType = mimeTypes[ ext ] || 'application/octet-stream';
        if (url1.startsWith('/'))
            url1 = url1.substring(1, url1.length);
        fs.readFile(url1.split('?')[ 0 ], function (err, data)
        {
            if (err)
            {
                console.log(url1);
                res.writeHead(404);
                res.end();
            }
            else
            {
                if (err) console.log(err);
                res.writeHead(200, { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' });
                if (ext == '.html')
                {
                    var str = '';
                    for (var i = 0; i < data.length; i++)
                    {
                        str += String.fromCharCode(data[ i ]);

                    }

                    data = str.replace(/(<head(?:\s[^>]*)?>)/, '$1<script src="/ServerLibrary/serverscript.js?' + (new Date()).toISOString() + '"></script>');
                }

                res.write(data);
                res.end();
            }
        });
    });

    app.get('/ServerLibrary/serverscript.js', (req, res) =>
    {
        function revolver()
        {
            var script_version = 3;
            var intervalStops = [];

            function start()
            {
                var refreshRequired = true;
                console.log('starting v' + script_version);
                var events = [ 'scroll', 'mousedown', 'mousemove', 'keypress' ]
                var timer = 0;
                events.forEach(function (eve)
                {
                    document.addEventListener(eve, function ()
                    {
                        timer = 0;
                    });
                });

                intervalStops.push(
                    setInterval(function ()
                    {
                        timer++;
                    }, 1000));

                var sessionObj = localStorage[ 'session' ];
                if (sessionObj)
                {
                    var now = new Date();
                    sessionObj = JSON.parse(sessionObj);
                    var expires = new Date(sessionObj.expires);
                    var sessionID = sessionObj.id;
                    if (expires > now)
                    {
                        refreshRequired = false;
                    }
                }
                if (refreshRequired)
                {
                    var req = new XMLHttpRequest();
                    req.open("POST", '/ServerLibrary/request_new_id');
                    req.onload = function ()
                    {
                        var responseObj = JSON.parse(req.response);
                        var expiryDate = new Date();
                        expiryDate.setSeconds(expiryDate.getSeconds() + 6);

                        localStorage.session = JSON.stringify({
                            id: responseObj.id,
                            expires: expiryDate,
                        });
                    }
                    req.send();
                }

                intervalStops.push(setInterval(function ()
                {
                    sessionObj = localStorage[ 'session' ];
                    if (sessionObj)
                    {
                        sessionObj = JSON.parse(sessionObj);
                        sessionObj.inactive_seconds = timer;
                        sessionObj.v = script_version;
                        var req = new XMLHttpRequest();
                        req.open("POST", '/ServerLibrary/ping');
                        req.onload = function ()
                        {
                            try
                            {
                                var serverTrackerResponse = JSON.parse(req.response);
                                if(serverTrackerResponse.req_version!=script_version)
                                {
                                    intervalStops.forEach(function(ints)
                                    {
                                        console.log('shutting v' + script_version);
                                        clearInterval(ints);
                                        var req = new XMLHttpRequest();
                                        req.open("GET",'/ServerLibrary/serverscript.js?' + (new Date()).toISOString());
                                        req.send();
                                        req.onload=function()
                                        {
                                            eval(req.response);
                                        }
                                        
                                    });
                                }

                                var expiryDate = new Date();
                                expiryDate.setSeconds(expiryDate.getSeconds() + 10);

                                localStorage.session = JSON.stringify({
                                    id: sessionObj.id,
                                    expires: expiryDate
                                });
                            }
                            catch (ex)
                            {

                            }
                        }
                        req.send(JSON.stringify(sessionObj));
                    }
                }, 5000));
            }

            function getCookie(name) {
                var value = "; " + document.cookie;
                var parts = value.split("; " + name + "=");
                if (parts.length == 2) return parts.pop().split(";").shift();
              }

            window._server_ = {
                user : 'Anonymous',
                username:'Anonymous'
            }

            var value = getCookie('user');
            var valuename = getCookie('username');
            if(value)
            {
                window._server_.user = value;
                window._server_.username = valuename;
                if(window.location.href.indexOf('/html/login.html')!=-1)
                {
                    window.location.href='/';
                }
            }
            else if(window.location.href.indexOf('/html/login.html')==-1)
            {
                window.location.href = '/html/login.html';
            }
            start();
        }

        res.write(revolver.toString() + "\nrevolver();");
        res.end();
    });

    app.post("/ServerLibrary/request_new_id", (req, res) =>
    {
        console.log("request new id");
        res.writeHead(200, "application/json");
        var randomId = Math.floor(Math.random() * 1000);
        res.write(JSON.stringify({ id: randomId }));
        res.end();
    });

    app.post("/ServerLibrary/ping", (req, res) =>
    {
        var body = '';
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            try
            {
                body = JSON.parse(body);
                var user = req.cookies['user'];
                body.user = 'Anonymous';
                if(user)
                {
                    try
                    {
                        body.user = serverEncryption.decrypt(user);
                    }
                    catch(ex)
                    {
                        
                    }
                }
                
                if(!debuggerAttached)
                
                process.send({ cmd: 'ping', ping: body });
            }
            catch (ex)
            {
                console.log(ex);
            }
            
            res.writeHead("200", "application/json");
            res.write(JSON.stringify({ req_version: 3 }));
            res.end();
        });

    });

    app.get('/ServerLibrary/active', (req, res) =>
    {
        queryMasterProcess({ query: 'ping' }, function (data)
        {
            res.writeHead(200, 'application/json');
            res.write(JSON.stringify(data));
            res.end();
        });

    });

    app.get('/code',(req,res)=>
    {
        res.writeHead(200, { 'Content-Type': contentType, 'Access-Control-Allow-Origin': '*' });
        req.write('Test');
        req.end();
    });

    var services = require('./services');
    app.use("/_api", services);

    app.listen(config.serverPort);

}
if (!debuggerAttached)
{
    process.on('uncaughtException', function (err)
    {
        // globalRes.write(JSON.stringify({ error: err.message }));
        // globalRes.end();
        console.log('Caught exception: ' + err);
    });
}