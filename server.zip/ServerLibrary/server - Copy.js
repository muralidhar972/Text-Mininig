
console.log('test');
var globalRes;

const http = require('http');
const xlsx = require('xlsx');
const fs = require('fs');
var path = require('path');
var ObjectId = require('mongodb').ObjectID
var MongoClient = require('mongodb').MongoClient;

const config = require("./config.json");
var url = config.central_mongo;

var arrFilterData = [];
var arrInfosDataFilter = [];
var arrInfosData=[];

//var exp=require('express');

//var workkbook = xlsx.readFile('data/Relevant_uspto_sample_80_Review.xlsx');
//var data = xlsx.utils.sheet_to_json(workkbook.Sheets[workkbook.SheetNames[0]]);

var mimeTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.wav': 'audio/wav',
    '.mp4': 'video/mp4',
    '.woff': 'font-woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'font/otf',
    '.svg': 'image/svg+xml',
    '.sfnt': 'font/sfnt'
};

http.createServer(function (req, res)
{
    globalRes = res;
    try
    {


        /**@type {string} */
        var url1 = req.url;

        if (!url1.startsWith('/_api') && !url1.startsWith('/ServerLibrary'))
        {
            if (url1 == '/') url1 = 'HTML/index.html'
            var contentType = mimeTypes[ path.extname(url1) ] || 'application/octet-stream';
            if (url1.startsWith('/'))
                url1 = url1.substring(1, url1.length);
            fs.readFile(url1.split('?')[ 0 ], function (err, data)
            {
                if (err)
                {
                    console.log(url1);
                    res.writeHead(404);
                    res.end();
                }
                else
                {
                    if (err) console.log(err);
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.write(data);
                    res.end();
                }
            });
        }
        else
        {
            /**@type {string[]} */
            var paths;
            var query = {};
            (function ()
            {
                var qss = url1.split('?');
                paths = qss[ 0 ].split('/');
                var queriess = qss[ 1 ];
                if (queriess)
                {

                    queriess.split('&').forEach(function (e)
                    {
                        var es = e.split('=');
                        if (es[ 1 ] == undefined)
                            es[ 1 ] = true;
                        query[ es[ 0 ] ] = es[ 1 ];
                    });
                }
            })();

            switch (paths[ 2 ])
            {
                case "Sources":
                    MongoClient.connect(url, function (err, db)
                    {
                        var dbo_central = db.db('Master_DB');
                        var sorucesInfoCollection = dbo_central.collection('SourceDBInfo');

                        sorucesInfoCollection.find().toArray((err, result) =>
                        {
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                        });
                    });

                    break;

                case "querymodifyprofile":
                    var body = '';
                    var httpResponse = res;
                    req.on('data', function (data)
                    {
                        body += data;
                        if (body.length > 1e6)
                            req.connection.destroy();
                    });

                    req.on('end', function ()
                    {
                        body;
                        req;

                        var pcidata = JSON.parse(body);
                        MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
                        {
                            //var dbo = db.db(db_name);

                            var CentralDB = db.db('Master_DB');
                            // find SourceDBInfo Obj
                            CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                            {
                                if (err) console.log(err);
                                // Conenct To Server to Copy
                                MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                                {
                                    //determine filter
                                    var filterObj = {};
                                    var storeFilterObj = {};
                                    if (pcidata.filter == 'date')
                                    {
                                        var field = sourceInfoObj.dateField[0];
                                        var andLogicArr = [];
                                        var fromDate = new Date(pcidata.startDate);
                                        var toDate = new Date(pcidata.endDate)

                                        var fromLogic = {};
                                        fromLogic[field] = { $gte: fromDate };

                                        var toLogic = {};
                                        toLogic[field] = { $lte: toDate };

                                        andLogicArr.push(fromLogic);
                                        andLogicArr.push(toLogic);

                                        filterObj['$and'] = andLogicArr

                                        storeFilterObj.type = 'daterange';
                                        storeFilterObj.from = fromDate;
                                        storeFilterObj.to = toDate;
                                    }
                                    if (pcidata.filter == 'keyword')
                                    {
                                        var field = sourceInfoObj.keywordField[0];
                                        filterObj[field] = { $in: pcidata.keywords }
                                        storeFilterObj.type = 'keyword';
                                        storeFilterObj.keywords = pcidata.keywords;

                                    }

                                    var SourceDB = db2.db(sourceInfoObj.db_name);
                                    var SourceCol = SourceDB.collection('data');

                                    //fetch all ids
                                    SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                                    {
                                        var profileDB = db.db(pcidata.profile_name);
                                        // insert infos


                                        if (err) console.log(err);


                                        profileDB.collection('data').find({}).toArray(function (err, prevRes)
                                        {
                                            allIds = allIds.filter(sid =>
                                            {
                                                var exists = false;
                                                for (var i = 0; i < prevRes.length; i++)
                                                {
                                                    var ei = prevRes[i];
                                                    if (ei.parent.equals(sid._id))
                                                    {
                                                        exists = true;
                                                        prevRes.splice(i, 1);
                                                        break;
                                                    }
                                                }
                                                return !exists;
                                            });


                                            db.close();
                                            db2.close();
                                            httpResponse.writeHead(200, 'application/json');
                                            httpResponse.write(JSON.stringify({ deleteCount: prevRes.length }));
                                            httpResponse.end();



                                        });

                                    });
                                });
                            });
                        });
                    });
                    break;

                case "modifyprofile":
                    var body = '';
                    var httpResponse = res;
                    req.on('data', function (data)
                    {
                        body += data;
                        if (body.length > 1e6)
                            req.connection.destroy();
                    });

                    req.on('end', function ()
                    {
                        body;
                        req;

                        var pcidata = JSON.parse(body);
                        MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
                        {
                            //var dbo = db.db(db_name);

                            var CentralDB = db.db('Master_DB');
                            // find SourceDBInfo Obj
                            CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                            {
                                if (err) console.log(err);
                                // Conenct To Server to Copy
                                MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                                {
                                    //determine filter
                                    var filterObj = {};
                                    var storeFilterObj = {};
                                    if (pcidata.filter == 'date')
                                    {
                                        var field = sourceInfoObj.dateField[0];
                                        var andLogicArr = [];
                                        var fromDate = new Date(pcidata.startDate);
                                        var toDate = new Date(pcidata.endDate)

                                        var fromLogic = {};
                                        fromLogic[field] = { $gte: fromDate };

                                        var toLogic = {};
                                        toLogic[field] = { $lte: toDate };

                                        andLogicArr.push(fromLogic);
                                        andLogicArr.push(toLogic);

                                        filterObj['$and'] = andLogicArr

                                        storeFilterObj.type = 'daterange';
                                        storeFilterObj.from = fromDate;
                                        storeFilterObj.to = toDate;
                                    }
                                    if (pcidata.filter == 'keyword')
                                    {
                                        var field = sourceInfoObj.keywordField[0];
                                        filterObj[field] = { $in: pcidata.keywords }
                                        storeFilterObj.type = 'keyword';
                                        storeFilterObj.keywords = pcidata.keywords;

                                    }

                                    var SourceDB = db2.db(sourceInfoObj.db_name);
                                    var SourceCol = SourceDB.collection('data');

                                    //fetch all ids
                                    SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                                    {
                                        var profileDB = db.db(pcidata.profile_name);
                                        // insert infos
                                        profileDB.collection('infos').updateMany({}, {
                                $set: {
                                                "profile_name": pcidata.profile_name,
                                                "db_name": sourceInfoObj.db_name,
                                                "server_path": sourceInfoObj.server_path,
                                                "user": "anonymous",
                                                "created": new Date(),
                                                "modified": new Date(),
                                                "modifiedby": "anonymous",
                                                categories: pcidata.categories,
                                                scoring: pcidata.scoring,
                                                fields: sourceInfoObj.fields,
                                                alias: sourceInfoObj.alias,
                                                filterObj: storeFilterObj,
                                            }
                                        },
                                            function (err, res)
                                            {
                                                if (err) console.log(err);


                                                profileDB.collection('data').find({}).toArray(function (err, prevRes)
                                                {
                                                    allIds = allIds.filter(sid =>
                                                    {
                                                        var exists = false;
                                                        for (var i = 0; i < prevRes.length; i++)
                                                        {
                                                            var ei = prevRes[i];
                                                            if (ei.parent.equals(sid._id))
                                                            {
                                                                exists = true;
                                                                prevRes.splice(i, 1);
                                                                break;
                                                            }
                                                        }
                                                        return !exists;
                                                    });
                                                    debugger;

                                                    var copyRef = allIds.map(i =>
                                                    {
                                                        return {
                                                            "parent": i._id,
                                                            "useraction": "",
                                                            "comment": "",
                                                            "modified": null,
                                                            "score": -1,
                                                            "score_result": ""
                                                        }
                                                    });

                                                    // create copy ref
                                                    if (copyRef.length > 0)
                                                    {
                                                        profileDB.collection('data').insertMany(copyRef, function (err, res)
                                                        {
                                                            if (prevRes.length > 0)
                                                            {
                                                                deleteExcess(() =>
                                                                {
                                                                    updateProfileInfo();
                                                                });
                                                            }
                                                            else
                                                            {
                                                                updateProfileInfo();
                                                            }
                                                        });
                                                    }
                                                    else
                                                    {
                                                        if (prevRes.length > 0)
                                                        {
                                                            deleteExcess(() =>
                                                            {
                                                                updateProfileInfo();
                                                            });
                                                        }
                                                        else
                                                        {
                                                            updateProfileInfo();
                                                        }
                                                    }


                                                    function deleteExcess(done)
                                                    {
                                                        var deleteQuery = { _id: { $in: prevRes.map(k => k._id) } };
                                                        profileDB.collection('data').deleteMany(deleteQuery, function (err, delRes)
                                                        {
                                                            done();
                                                        });
                                }

                                                    // update records
                                                    function updateProfileInfo()
                                {
                                                        profileDB.collection('data').count().then(dataCount =>
                                        {
                                                            CentralDB.collection('ProfileInfo').updateOne({ profile_name: pcidata.profile_name }, {
                                            $set: {
                                                                    total_record_count: dataCount,
                                            }
                                                            }, function (err, res)
                                        {
                                                                    if (err) throw err
                                                                    db.close();
                                                                    db2.close();

                                                                    var profileProcess_url = config.python_url + '/run/' + pcidata.profile_name;
                                            console.log('calling');
                                            http.get(profileProcess_url, res =>
                                            {
                                                res.setEncoding("utf8");
                                                let body = '';
                                                res.on("data", data =>
                                                {
                                                    body += data;
                                                });
                                                res.on("end", () =>
                                                {
                                                    console.log('evaluation called', body);
                                                });
                                            });
                                                                    //http.get(profileProcess_url, res =>{console.log('evaluation called',res)});

                                                                    httpResponse.writeHead(200, 'application/json');
                                                                    httpResponse.write(JSON.stringify({ result: "ok" }));
                                                                    httpResponse.end();
                                                                });
                                                        });
                                                    }


                                                });
                                            });
                                    });
                                        });
                                });
                        });
                    });
                    break;
                case "createprofile":
                    var body = '';
                    var httpResponse = res;
                    req.on('data', function (data)
                    {
                        body += data;
                        if (body.length > 1e6)
                            req.connection.destroy();
                    });

                    req.on('end', function ()
                    {
                        body;
                        req;

                        var pcidata = JSON.parse(body);
                        MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
                        {
                            //var dbo = db.db(db_name);

                            var CentralDB = db.db('Master_DB');
                            // find SourceDBInfo Obj
                            CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                            {
                                // Create relevant obj in ProfileInfo
                                CentralDB.collection('ProfileInfo').insertOne(
                                    {
                                        "profile_name": pcidata.profile_name,
                                        "profile_path": config.new_profile_db_server,

                                        "db_source_path": sourceInfoObj.server_path,
                                        "db_name": sourceInfoObj.db_name,

                                        "isActive": 1,
                                        "color": "#FF0000",
                                        "desc": "N/A"
                                    }, function (err, result)
                                    {
                                        if (err) console.log(err);
                                        // Conenct To Server to Copy
                                        MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                                        {
                                            //determine filter
                                            var filterObj = {};
                                            var storeFilterObj = {};
                                            if (pcidata.filter == 'date')
                                            {
                                                var field = sourceInfoObj.dateField[ 0 ];
                                                var andLogicArr = [];
                                                var fromDate = new Date(pcidata.startDate);
                                                var toDate = new Date(pcidata.endDate)

                                                var fromLogic = {};
                                                fromLogic[ field ] = { $gte: fromDate };

                                                var toLogic = {};
                                                toLogic[ field ] = { $lte: toDate };

                                                andLogicArr.push(fromLogic);
                                                andLogicArr.push(toLogic);

                                                filterObj[ '$and' ] = andLogicArr

                                                storeFilterObj.type = 'daterange';
                                                storeFilterObj.from = fromDate;
                                                storeFilterObj.to = toDate;
                                            }
                                            if (pcidata.filter == 'keyword')
                                            {
                                                var field = sourceInfoObj.keywordField[ 0 ];
                                                filterObj[ field ] = { $in: pcidata.keywords }
                                                storeFilterObj.type = 'keyword';
                                                storeFilterObj.keywords = pcidata.keywords;

                                            }

                                            var SourceDB = db2.db(sourceInfoObj.db_name);
                                            var SourceCol = SourceDB.collection('data');

                                            //fetch all ids
                                            SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                                            {
                                                var profileDB = db.db(pcidata.profile_name);
                                                // insert infos
                                                profileDB.collection('infos').insertOne({
                                                    "profile_name": pcidata.profile_name,
                                                    "db_name": sourceInfoObj.db_name,
                                                    "server_path": sourceInfoObj.server_path,
                                                    "user": "anonymous",
                                                    "created": new Date(),
                                                    "modified": new Date(),
                                                    "modifiedby": "anonymous",
                                                    categories: pcidata.categories,
                                                    scoring: pcidata.scoring,
                                                    fields: sourceInfoObj.fields,
                                                    alias: sourceInfoObj.alias,
                                                    filterObj: storeFilterObj,
                                                }, function (err, res)
                                                    {
                                                        if (err) console.log(err);
                                                        allIds

                                                        var copyRef = allIds.map(i =>
                                                        {
                                                            return {
                                                                "parent": i._id,
                                                                "useraction": "",
                                                                "comment": "",
                                                                "modified": null,
                                                                "score": -1,
                                                                "score_result": ""
                                                            }
                                                        });
                                                        // create copy ref
                                                        profileDB.collection('data').insertMany(copyRef, function (err, res)
                                                        {
                                                            // update records
                                                            CentralDB.collection('ProfileInfo').updateOne({ profile_name: pcidata.profile_name }, {
                                                                $set: {
                                                                    total_record_count: copyRef.length,
                                                                }
                                                            }, function (err, res)
                                                                {
                                                                    if (err) throw err
                                                                    db.close();
                                                                    db2.close();

                                                                    var profileProcess_url = config.python_url + '/run/' + pcidata.profile_name;
                                                                    console.log('calling');
                                                                    http.get(profileProcess_url, res =>
                                                                    {
                                                                        res.setEncoding("utf8");
                                                                        let body = '';
                                                                        res.on("data", data =>
                                                                        {
                                                                            body += data;
                                                                        });
                                                                        res.on("end", () =>
                                                                        {
                                                                            console.log('evaluation called', body);
                                                                        });
                                                                    });
                                                                    //http.get(profileProcess_url, res =>{console.log('evaluation called',res)});

                                                                    httpResponse.writeHead(200, 'application/json');
                                                                    httpResponse.write(JSON.stringify({ result: "ok" }));
                                                                    httpResponse.end();
                                                                });

                                                        });
                                                    });
                                            });
                                        });
                                    });
                            });
                        });
                    });
                    break;

                case "getProfileInfo":
                    var profileId = paths[ 3 ];
                    MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
                    {
                        var MasterDB = db.db("Master_DB");
                        MasterDB.collection('ProfileInfo').findOne({ _id: ObjectId(profileId) }, function (err, profileMasterInfo)
                        {
                            var prof_dbname = profileMasterInfo.profile_name;
                            var prof_path = profileMasterInfo.profile_path;

                            MongoClient.connect("mongodb://" + prof_path, { useNewUrlParser: true }, function (err, db1)
                            {
                                var profileDB = db1.db(prof_dbname);
                                profileDB.collection('infos').findOne({}, function (err, profileInfo)
                                {
                                    res.writeHead(200, 'application/json');
                                    res.write(JSON.stringify(profileInfo));
                                    res.end();
                                })
                            });
                        });
                    });
                    break;

                case "MstSourceDBsInfo":
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db("Master_DB");
                        dbo.collection("SourceDBInfo").find({}).toArray(function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "MstProfiles":
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db("Master_DB");
                        dbo.collection("ProfileInfo").find({}).toArray(function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                    case "DeleteProfile":
                        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                        var ProfileDBPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                        url = "mongodb://" + ProfileDBPath + "/";
                        MongoClient.connect(url, function (err, db)
                        {
                            if (err) console.log(err);
                            var dbo = db.db("Master_DB");
                            var myquery = { profile_name: ProfileDBName };
                            dbo.collection("ProfileInfo").deleteOne(myquery, function(err, obj) 
                            {
                                if (err) throw err;
                                var dbo = db.db(ProfileDBName);
                                dbo.dropDatabase(function(err, result)
                                {
                                    console.log("Error : "+err);
                                    if (err) throw err;
                                    console.log(ProfileDBName+" DB has been deleted successfully");
                                    res.write(JSON.stringify(result));
                                    res.end();
                                    db.close();
                                });
                            });
                        });
                    break;
                case "MstItems":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    var inId = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]).split(',');
                    inId = inId.map(i => ObjectId(i));
                    url = "mongodb://" + db_path + "/";
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        dbo.collection("data").find({ _id: { $in: inId } }).toArray(function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "MstSelectedProfileInfos":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    url = "mongodb://" + db_path + "/";
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        dbo.collection("infos").find({}).toArray(function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "MstSelectedProfileData":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    var action = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
                    url = "mongodb://" + db_path + "/";
                    var query = {};
                    if (action == "allitems")
                    {
                        query = {};
                    }
                    else if (action == "pending")
                    {
                        query = { useraction: "" };
                    }
                    else if (action == "relevant")
                    {
                        query = { useraction: "relevant" };
                    }
                    else if (action == "not-relevant")
                    {
                        query = { useraction: "not-relevant" };
                    }
                    else if (action == "seen")
                    {
                        query = { modified: { $ne: "" }, useraction: "" }
                    }
                    else if (action == "unseen")
                    {
                        query = { modified: { $eq: "" }, useraction: "" }
                    }
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        dbo.collection("data").find(query).toArray(function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            res.writeHead(200, { 'Content-Type': 'application/json' });
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "doItemUpdate":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    var response = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
                    var objId = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
                    var comm = (((url1.split('?')[ 1 ]).split('&')[ 4 ]).split('=')[ 1 ]);
                    url = "mongodb://" + db_path + "/";
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        var myquery = { _id: ObjectId(objId) };
                        var newvalues = { $set: { useraction: response, modified: new Date(), comment: decodeURI(comm) } };
                        dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            console.log("1 document updated");
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "doCommentUpdate":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    var objId = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
                    var comm = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
                    url = "mongodb://" + db_path + "/";
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        var myquery = { parent: ObjectId(objId) };
                        var newvalues = { $set: { comment: decodeURI(comm) } };
                        dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            console.log("1 document updated");
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                case "doLastSeenUpdate":
                    var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                    var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                    var parentID = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
                    var lstSeen = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
                    url = "mongodb://" + db_path + "/";
                    MongoClient.connect(url, function (err, db)
                    {
                        if (err) console.log(err);
                        var dbo = db.db(db_name);
                        var myquery = { parent: ObjectId(parentID) };
                        var newvalues = {};
                        if (lstSeen == 'Y')
                            newvalues = { $set: { modified: new Date() } };
                        else
                            newvalues = { $set: { modified: "" } };

                        dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
                        {
                            if (err) console.log(err);
                            //console.log(result);
                            console.log("1 document updated");
                            res.write(JSON.stringify(result));
                            res.end();
                            db.close();
                        });
                    });
                    break;
                    case "ExcelExport":
                        var SourceDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
                        var SourceDBPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
                        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
                        var ProfileDBPath = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
                        arrInfosDataFilter = new Array();
                        arrFilterData = new Array();
                        arrInfosData=new Array();
                        url = "mongodb://" + ProfileDBPath + "/";
                        MongoClient.connect(url, function (err, db)
                        {
                            if (err) console.log(err);
                            var dbo = db.db(ProfileDBName);
                            dbo.collection("data").find({}).toArray(function (err, result)
                            {
                                if (err) console.log(err);
                                //console.log(result);
                                res.writeHead(200, { 'Content-Type': 'application/json' });
                                var arrJson = JSON.stringify(result);
                                arrInfosDataFilter = JSON.parse(arrJson);
                                var inId = "";
                                if (arrInfosDataFilter.length > 0)
                                {
                                    for (var k = 0; k < arrInfosDataFilter.length; k++)
                                    {
                                        if (inId === '')
                                            inId = arrInfosDataFilter[ k ].parent;
                                        else
                                            inId = inId + ',' + arrInfosDataFilter[ k ].parent;
                                    }
                                    inId = inId.split(',').map(i => ObjectId(i));
                                    dbo = db.db(SourceDBName);
                                    dbo.collection("data").find({ _id: { $in: inId } }).toArray(function (err, result)
                                    {
                                        arrInfosDataFilter;
                                        if (err) console.log(err);
                                        //console.log(result);
                                        res.writeHead(200, { 'Content-Type': 'application/json' });
                                        var ret = JSON.stringify(result);
                                        arrFilterData = JSON.parse(ret);
    
                                        dbo = db.db(ProfileDBName);
                                        dbo.collection("infos").find({}).toArray(function (err, result)
                                        {
                                            arrInfosDataFilter;
                                            arrFilterData;
                                            if (err) console.log(err);
    
                                            res.writeHead(200, { 'Content-Type': 'application/json' });
                                            var retInfos = JSON.stringify(result);
                                            arrInfosData = JSON.parse(retInfos);
    
                                            var writeStream = fs.createWriteStream(ProfileDBName + ".xls");
                                            var keys = Object.keys(arrFilterData[ 0 ]);
                                            keys.splice(0, 1);
    
                                            var strRow = "";
                                            strRow = strRow + '<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
                                            strRow = strRow + '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
                                            strRow = strRow + '<head><!--[if gte mso 9]>';
                                            strRow = strRow + '<xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
                                            strRow = strRow + '<x:Name>Meeting Dashboard</x:Name>';
                                            strRow = strRow + '<x:WorksheetOptions>';
                                            strRow = strRow + '<x:FreezePanes/>';
                                            strRow = strRow + '<x:SplitHorizontal>1</x:SplitHorizontal>';
                                            strRow = strRow + '<x:TopRowBottomPane>1</x:TopRowBottomPane>';
                                            strRow = strRow + '<x:SplitVertical>9</x:SplitVertical>';
                                            strRow = strRow + '<x:LeftColumnRightPane>9</x:LeftColumnRightPane>';
                                            strRow = strRow + '<x:ActivePane>0</x:ActivePane>';
                                            strRow = strRow + '<x:ProtectContents>False</x:ProtectContents>';
                                            strRow = strRow + '<x:ProtectObjects>False</x:ProtectObjects>';
                                            strRow = strRow + '<x:ProtectScenarios>False</x:ProtectScenarios>';
                                            strRow = strRow + '<x:DisplayGridlines/>';
                                            strRow = strRow + '</x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml>';
                                            strRow = strRow + '<![endif]-->';
                                            strRow = strRow + '</head><body>';
                                            strRow = strRow + "<table>";
                                            strRow = strRow + "<tr>";
                                            for (var t = 0; t < keys.length; t++)
                                            {
                                                var upperColName = keys[ t ].toUpperCase().replace(/[^a-zA-Z0-9]/ig, " ").replace(/  +/g, ' ');
                                                if (t === keys.length - 1)
                                                {
                                                    strRow = strRow + "<th style='border-top:2px solid #72635d;border-left:2px solid #72635d;border-right:2px solid #72635d;border-bottom:2px solid #72635d;background-color:#72635d;color:white;'>" + upperColName + "</th>";
                                                }
                                                else
                                                {
                                                    if (t === 0)
                                                    {
                                                        strRow = strRow + "<th style='border-top:2px solid #72635d;border-left:2px solid #72635d;border-right:2px solid #72635d;border-bottom:2px solid #72635d;background-color:#72635d;color:white;'>SL NO</th>";
                                                        strRow = strRow + "<th x:autofilter='all' style='border-top:2px solid #72635d;border-left:2px solid #72635d;border-right:2px solid #72635d;border-bottom:2px solid #72635d;background-color:#72635d;color:white;'>" + upperColName + "</th>";
                                                    }
                                                    else if (t === 3)
                                                    {
                                                        if(arrInfosData.length>0)
                                                        {
                                                            if(arrInfosData[0].categories.length>0)
                                                            {
                                                                strRow = strRow + "<th style='border-top:2px solid #94c943;border-left:2px solid #94c943;border-right:2px solid #94c943;border-bottom:2px solid #94c943;background-color:#94c943;color:white;'>Keyword criteria Name</th>";
                                                                strRow = strRow + "<th style='border-top:2px solid #94c943;border-left:2px solid #94c943;border-right:2px solid #94c943;border-bottom:2px solid #94c943;background-color:#94c943;color:white;'>Fields</th>";
                                                                strRow = strRow + "<th style='border-top:2px solid #94c943;border-left:2px solid #94c943;border-right:2px solid #94c943;border-bottom:2px solid #94c943;background-color:#94c943;color:white;'>Keywords</th>";
                                                            }
                                                            if(arrInfosData[0].scoring.length>0)
                                                            {
                                                                strRow = strRow + "<th style='border-top:2px solid #f1820c;border-left:2px solid #f1820c;border-right:2px solid #f1820c;border-bottom:2px solid #f1820c;background-color:#f1820c;color:white;'>Scoring criteria name</th>";
                                                                strRow = strRow + "<th style='border-top:2px solid #f1820c;border-left:2px solid #f1820c;border-right:2px solid #f1820c;border-bottom:2px solid #f1820c;background-color:#f1820c;color:white;'>Query</th>";
                                                                strRow = strRow + "<th style='border-top:2px solid #f1820c;border-left:2px solid #f1820c;border-right:2px solid #f1820c;border-bottom:2px solid #f1820c;background-color:#f1820c;color:white;'>Weight</th>";
                                                            }
                                                        }
                                                        strRow = strRow + "<th x:autofilter='all' style='border-top:2px solid #008dd1;border-left:2px solid #008dd1;border-right:2px solid #008dd1;border-bottom:2px solid #008dd1;background-color:#008dd1;color:white;'>USER ACTION</th>";
                                                        strRow = strRow + "<th x:autofilter='all' style='border-top:2px solid #008dd1;border-left:2px solid #008dd1;border-right:2px solid #008dd1;border-bottom:2px solid #008dd1;background-color:#008dd1;color:white;'>SCORE</th>";
                                                        strRow = strRow + "<th x:autofilter='all' style='border-top:2px solid #008dd1;border-left:2px solid #008dd1;border-right:2px solid #008dd1;border-bottom:2px solid #008dd1;background-color:#008dd1;color:white;'>ACTION RESULT</th>";
                                                        strRow = strRow + "<th style='border-top:2px solid #008dd1;border-left:2px solid #008dd1;border-right:2px solid #008dd1;border-bottom:2px solid #008dd1;background-color:#008dd1;color:white;'>ACTION DATE</th>";
                                                        strRow = strRow + "<th style='border-top:2px solid #008dd1;border-left:2px solid #008dd1;border-right:2px solid #008dd1;border-bottom:2px solid #008dd1;background-color:#008dd1;color:white;'>COMMENT</th>";
                                                        strRow = strRow + "<th style='border-top:2px solid #72635d;border-left:2px solid #72635d;border-right:2px solid #72635d;border-bottom:2px solid #72635d;background-color:#72635d;color:white;'>" + upperColName + "</th>";
                                                    }
                                                    else
                                                    {
                                                        strRow = strRow + "<th style='border-top:2px solid #72635d;border-left:2px solid #72635d;border-right:2px solid #72635d;border-bottom:2px solid #72635d;background-color:#72635d;color:white;'>" + upperColName + "</th>";
                                                    }
                                                }
                                            }
                                            strRow = strRow + "</tr>";
                                            for (var r = 0; r < arrFilterData.length; r++)
                                            {
                                                strRow = strRow + "<tr>";
                                                for (var t = 0; t < keys.length; t++)
                                                {
                                                    var ret = arrInfosDataFilter.filter(function (em)
                                                    {
                                                        return (em.parent === arrFilterData[ r ]._id)
                                                    })
                                                    if (ret.length > 0)
                                                    {
                                                        if (t === keys.length - 1)
                                                        {
                                                            strRow = strRow + "<td align='middle' style='border-left:1px solid #72635d;border-right:1px solid #72635d;'>" + arrFilterData[ r ][ keys[ t ] ] + "</td>";
                                                        }
                                                        else
                                                        {
                                                            if (t === 0)
                                                            {
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #72635d;border-right:1px solid #72635d;'>" + (r + 1) + "</td>";
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #72635d;border-right:1px solid #72635d;'>" + arrFilterData[ r ][ keys[ t ] ] + "</td>";
                                                            }
                                                            else if (t === 3)
                                                            {
                                                                if(arrInfosData[0].categories.length>0)
                                                                {
                                                                    var sName='';
                                                                    var sFields='';
                                                                    var sKeywords='';
                                                                    for(var z=0;z<arrInfosData[0].categories.length;z++)
                                                                    {
                                                                        sName=sName+arrInfosData[0].categories[z].catname+'<br /><br />';
                                                                        sFields=sFields+arrInfosData[0].categories[z].fields.join(" , ")+'<br /><br />';
                                                                        sKeywords=sKeywords+arrInfosData[0].categories[z].keywords.join(" , ")+'<br /><br />';
                                                                    }
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #94c943;border-right:1px solid #94c943;border-top:1px solid #94c943;border-bottom:1px solid #94c943;'>" + sName + "</td>";
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #94c943;border-right:1px solid #94c943;border-top:1px solid #94c943;border-bottom:1px solid #94c943;'>" + sFields + "</td>";
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #94c943;border-right:1px solid #94c943;border-top:1px solid #94c943;border-bottom:1px solid #94c943;'>" + sKeywords + "</td>";
                                                                }
                                                                if(arrInfosData[0].scoring.length>0)
                                                                {
                                                                    var scname='';
                                                                    var squery='';
                                                                    var sweight='';
                                                                    for(var m=0;m<arrInfosData[0].scoring.length;m++)
                                                                    {
                                                                        scname=scname+arrInfosData[0].scoring[m].name+'<br /><br />';
                                                                        squery=squery+arrInfosData[0].scoring[m].query+'<br /><br />';
                                                                        sweight=sweight+arrInfosData[0].scoring[m].weight+'<br /><br />';
                                                                    }
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #f1820c;border-right:1px solid #f1820c;border-top:1px solid #f1820c;border-bottom:1px solid #f1820c;'>" + scname + "</td>";
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #f1820c;border-right:1px solid #f1820c;border-top:1px solid #f1820c;border-bottom:1px solid #f1820c;'>" + squery + "</td>";
                                                                    strRow = strRow + "<td align='middle' style='border-left:1px solid #f1820c;border-right:1px solid #f1820c;border-top:1px solid #f1820c;border-bottom:1px solid #f1820c;'>" + sweight + "</td>";
                                                                }
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #008dd1;border-right:1px solid #008dd1;border-top:1px solid #008dd1;border-bottom:1px solid #008dd1;'>" + ret[ 0 ].useraction + "</td>";
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #008dd1;border-right:1px solid #008dd1;border-top:1px solid #008dd1;border-bottom:1px solid #008dd1;'>" + ret[ 0 ].score + "</td>";
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #008dd1;border-right:1px solid #008dd1;border-top:1px solid #008dd1;border-bottom:1px solid #008dd1;'>" + ret[ 0 ].score_result + "</td>";
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #008dd1;border-right:1px solid #008dd1;border-top:1px solid #008dd1;border-bottom:1px solid #008dd1;'>" + ret[ 0 ].modified + "</td>";
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #008dd1;border-right:1px solid #008dd1;border-top:1px solid #008dd1;border-bottom:1px solid #008dd1;'>" + ret[ 0 ].comment + "</td>";

                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #72635d;border-right:1px solid #72635d;'>" + arrFilterData[ r ][ keys[ t ] ] + "</td>";
                                                            }
                                                            else
                                                            {
                                                                strRow = strRow + "<td align='middle' style='border-left:1px solid #72635d;border-right:1px solid #72635d;'>" + arrFilterData[ r ][ keys[ t ] ] + "</td>";
                                                            }
                                                        }
                                                    }
                                                }
                                                strRow = strRow + "</tr>";
                                            }
                                            strRow = strRow + "</table>";
                                            strRow = strRow + '</body></html>';
                                            res.writeHead(200, { 'Content-Type': "application/octet-stream" });
                                            res.write(strRow);
                                            res.end();
                                            //writeStream.close();
                                            db.close();
                                        })
                                    });
                                }
                            });
                        });
                    break;
                default:
                    res.writeHead(404);
                    res.end();
            }
        }

    }
    catch (ex)
    {

    }
}).listen(config.serverPort);


process.on('uncaughtException', function (err)
{
    globalRes.write(JSON.stringify({ error: err.message }));
    globalRes.end();
    console.log('Caught exception: ' + err);
});