const net = require('net');
const express = require('express');
const http = require('http');
const fs = require('fs');
const ObjectId = require('mongodb').ObjectID
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
const config = require("./config.json");
const XLSX = require('xlsx');
const Excel = require('exceljs');
const tempfile = require('tempfile');
const ws = require("nodejs-websocket")
const Cryptr = require('cryptr');
const hostname = require("os").hostname();
const ntlm2 = require('ntlm');
const headerParser = require('http-headers')
const serverOTP = "32423813";

var arrFilterData = [];
var arrInfosDataFilter = [];
var arrInfosData = [];
var dbIP = config.central_mongo;

var router = express.Router();

var url = config.central_mongo;
var serverEncryption = new Cryptr(serverOTP);

(function Services_Devarshi()
{
    router.get("/Sources", (req, res) =>
    {
        MongoClient.connect(url, function (err, db)
        {
            var dbo_central = db.db('Master_DB');
            var sorucesInfoCollection = dbo_central.collection('SourceDBInfo');

            sorucesInfoCollection.find().toArray((err, result) =>
            {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/globalBuckets", (req, res) =>
    {
        MongoClient.connect(url, function (err, db)
        {
            var dbo_central = db.db('Master_DB');
            var globalbucketInfoCollection = dbo_central.collection('GlobalBucket');

            globalbucketInfoCollection.find({}, { projection: { _id: 1,bucketname: 1,dbname: 1,type: 1,status: 1,description: 1 } }).toArray((err, result) =>
            {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.post("/querymodifyprofile", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var pcidata = JSON.parse(body);
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);

                var CentralDB = db.db('Master_DB');
                // find SourceDBInfo Obj
                CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                {
                    if (err) console.log(err);
                    // Conenct To Server to Copy
                    MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                    {
                        //determine filter
                        var filterObj = {};
                        var storeFilterObj = {};
                        if (pcidata.filter == 'date')
                        {
                            var field = sourceInfoObj.dateField[ 0 ];
                            var andLogicArr = [];
                            var fromDate = new Date(pcidata.startDate);
                            var toDate = new Date(pcidata.endDate)

                            var fromLogic = {};
                            fromLogic[ field ] = { $gte: fromDate };

                            var toLogic = {};
                            toLogic[ field ] = { $lte: toDate };

                            andLogicArr.push(fromLogic);
                            andLogicArr.push(toLogic);

                            filterObj[ '$and' ] = andLogicArr

                            storeFilterObj.type = 'daterange';
                            storeFilterObj.from = fromDate;
                            storeFilterObj.to = toDate;
                        }
                        if (pcidata.filter == 'keyword')
                        {
                            var field = sourceInfoObj.keywordField[ 0 ];
                            filterObj[ field ] = { $in: pcidata.keywords }
                            storeFilterObj.type = 'keyword';
                            storeFilterObj.keywords = pcidata.keywords;

                        }

                        var SourceDB = db2.db(sourceInfoObj.db_name);
                        var SourceCol = SourceDB.collection('data');

                        //fetch all ids
                        SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                        {
                            var profileDB = db.db(pcidata.profile_name);
                            // insert infos


                            if (err) console.log(err);


                            profileDB.collection('data').find({}).toArray(function (err, prevRes)
                            {
                                allIds = allIds.filter(sid =>
                                {
                                    var exists = false;
                                    for (var i = 0; i < prevRes.length; i++)
                                    {
                                        var ei = prevRes[ i ];
                                        if (ei.parent.equals(sid._id))
                                        {
                                            exists = true;
                                            prevRes.splice(i, 1);
                                            break;
                                        }
                                    }
                                    return !exists;
                                });

                                db.close();
                                db2.close();
                                httpResponse.writeHead(200, 'application/json');
                                httpResponse.write(JSON.stringify({ deleteCount: prevRes.length }));
                                httpResponse.end();
                            });
                        });
                    });
                });
            });
        });
    });

    router.post("/modifyprofile", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var username = serverEncryption.decrypt(req.cookies.user);
            body = body.replace(/\$\{userid\}/g,username);

            var pcidata = JSON.parse(body);
            var globalbuckets=[];
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);

                var CentralDB = db.db('Master_DB');
                // find SourceDBInfo Obj
                CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                {
                    if (err) console.log(err);
                    
                    // Update relevant obj in ProfileInfo
                    CentralDB.collection('ProfileInfo').updateOne(
                    {
                        "profile_name": pcidata.profile_name,
                    },
                    {
                        $set:{
                            "modifiedby": username,
                            "modified": new Date(),
                        }
                    },
                    function (err, result)
                    {
                        if (err) console.log(err);
                        CentralDB.collection('GlobalBucket').find({ dbname: sourceInfoObj.db_name }).toArray(function (err, result)
                        {
                            var predefinedbucket= [];
                            if(pcidata.bucket.length>0)
                            {
                                for(var m=0;m<pcidata.bucket.length;m++)
                                {
                                    predefinedbucket.push({
                                        "type": pcidata.bucket[m].type,
                                        "description": pcidata.bucket[m].description,
                                        "color": pcidata.bucket[m].color,
                                        "bucketname": pcidata.bucket[m].bucketname,
                                        "status": "active",
                                        "createdby": username,
                                        "createddt": new Date(),
                                        "modifiedby": username,
                                        "modifieddt": new Date(),
                                        "bucketdetail": []
                                    })
                                    var arrFilter=result.filter(function(e){return e.bucketname===pcidata.bucket[m].bucketname});
                                    if(arrFilter.length>0)
                                    {
                                        for(var z=0;z<arrFilter.length;z++)
                                        {
                                            var bkdetail=arrFilter[z].bucketdetail;
                                            for(var n=0;n<bkdetail.length;n++)
                                            {
                                                predefinedbucket[m].bucketdetail.push({
                                                    "itemId": bkdetail[n].itemId,
                                                    "fieldname": bkdetail[n].fieldname,
                                                    "range": {
                                                        "from": bkdetail[n].range.from,
                                                        "to": bkdetail[n].range.to
                                                    },
                                                    "text": bkdetail[n].text,
                                                    "tagid": bkdetail[n].tagid,
                                                    "status": bkdetail[n].status
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                            // Conenct To Server to Copy
                        MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                        {
                            //determine filter
                            predefinedbucket;
                            var filterObj = {};
                            var storeFilterObj = {};
                            if (pcidata.filter == 'date')
                            {
                                var field = sourceInfoObj.dateField[ 0 ];
                                var andLogicArr = [];
                                var fromDate = new Date(pcidata.startDate);
                                var toDate = new Date(pcidata.endDate)

                                var fromLogic = {};
                                fromLogic[ field ] = { $gte: fromDate };

                                var toLogic = {};
                                toLogic[ field ] = { $lte: toDate };

                                andLogicArr.push(fromLogic);
                                andLogicArr.push(toLogic);

                                filterObj[ '$and' ] = andLogicArr

                                storeFilterObj.type = 'daterange';
                                storeFilterObj.from = fromDate;
                                storeFilterObj.to = toDate;
                            }
                            if (pcidata.filter == 'keyword')
                            {
                                var field = sourceInfoObj.keywordField[ 0 ];
                                filterObj[ field ] = { $in: pcidata.keywords }
                                storeFilterObj.type = 'keyword';
                                storeFilterObj.keywords = pcidata.keywords;

                            }

                            var SourceDB = db2.db(sourceInfoObj.db_name);
                            var SourceCol = SourceDB.collection('data');

                            //fetch all ids
                            SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                            {
                                var profileDB = db.db(pcidata.profile_name);

                                //strip angularKey
                                pcidata.bucket.forEach(buck =>
                                {
                                    Object.keys(buck).forEach(key =>
                                    {
                                        if (key.startsWith('$'))
                                        {
                                            delete buck[ key ];
                                        }
                                    })
                                })

                                var user = serverEncryption.decrypt(req.cookies.user);
                            
                                // insert infos
                                profileDB.collection('infos').updateMany({}, {
                                    $set: {
                                        "profile_name": pcidata.profile_name,
                                        "db_name": sourceInfoObj.db_name,
                                        "server_path": sourceInfoObj.server_path,
                                        "user": user,
                                        "created": new Date(),
                                        "modified": new Date(),
                                        "modifiedby": user,
                                        categories: pcidata.categories,
                                        scoring: pcidata.scoring,
                                        fields: sourceInfoObj.fields,
                                        alias: sourceInfoObj.alias,
                                        filterObj: storeFilterObj,
                                        status: "",
                                        bucket: predefinedbucket
                                    }
                                },
                                    function (err, res)
                                    {
                                        if (err) console.log(err);


                                        profileDB.collection('data').find({}).toArray(function (err, prevRes)
                                        {
                                            allIds = allIds.filter(sid =>
                                            {
                                                var exists = false;
                                                for (var i = 0; i < prevRes.length; i++)
                                                {
                                                    var ei = prevRes[ i ];
                                                    if (ei.parent.equals(sid._id))
                                                    {
                                                        exists = true;
                                                        prevRes.splice(i, 1);
                                                        break;
                                                    }
                                                }
                                                return !exists;
                                            });

                                            var copyRef = allIds.map(i =>
                                            {
                                                return {
                                                    "parent": i._id,
                                                    "useraction": "",
                                                    "comment": "",
                                                    "modified": null,
                                                    "score": -1,
                                                    "score_result": ""
                                                }
                                            });

                                            // create copy ref
                                            if (copyRef.length > 0)
                                            {
                                                profileDB.collection('data').insertMany(copyRef, function (err, res)
                                                {
                                                    if (prevRes.length > 0)
                                                    {
                                                        deleteExcess(() =>
                                                        {
                                                            updateProfileInfo();
                                                        });
                                                    }
                                                    else
                                                    {
                                                        updateProfileInfo();
                                                    }
                                                });
                                            }
                                            else
                                            {
                                                if (prevRes.length > 0)
                                                {
                                                    deleteExcess(() =>
                                                    {
                                                        updateProfileInfo();
                                                    });
                                                }
                                                else
                                                {
                                                    updateProfileInfo();
                                                }
                                            }


                                            function deleteExcess(done)
                                            {
                                                var deleteQuery = { _id: { $in: prevRes.map(k => k._id) } };
                                                profileDB.collection('data').deleteMany(deleteQuery, function (err, delRes)
                                                {
                                                    done();
                                                });
                                            }

                                            // update records
                                            function updateProfileInfo()
                                            {
                                                profileDB.collection('data').countDocuments().then(dataCount =>
                                                {
                                                    CentralDB.collection('ProfileInfo').updateOne({ profile_name: pcidata.profile_name }, {
                                                        $set: {
                                                            total_record_count: dataCount,
                                                        }
                                                    }, function (err, res)
                                                        {
                                                            if (err) throw err
                                                            db.close();
                                                            db2.close();

                                                            var profileProcess_url = config.python_url + '/run/' + pcidata.profile_name;
                                                                //console.log('calling');
                                                            http.get(profileProcess_url, res =>
                                                            {
                                                                res.setEncoding("utf8");
                                                                let body = '';
                                                                res.on("data", data =>
                                                                {
                                                                    body += data;
                                                                });
                                                                res.on("end", () =>
                                                                {
                                                                    console.log('evaluation called', body);
                                                                });
                                                            });
                                                            //http.get(profileProcess_url, res =>{console.log('evaluation called',res)});

                                                            httpResponse.writeHead(200, 'application/json');
                                                            httpResponse.write(JSON.stringify({ result: "ok" }));
                                                            httpResponse.end();
                                                        });
                                                });
                                            }


                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    router.post("/createprofile", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var username = serverEncryption.decrypt(req.cookies.user);
            body = body.replace(/\$\{userid\}/g,username);

            var pcidata = JSON.parse(body);
            var globalbuckets=[];
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);
                var CentralDB = db.db('Master_DB');
                
                // find SourceDBInfo Obj
                CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                {
                    // Create relevant obj in ProfileInfo
                    CentralDB.collection('ProfileInfo').insertOne(
                    {
                        "profile_name": pcidata.profile_name,
                        "profile_path": config.new_profile_db_server,

                        "db_source_path": sourceInfoObj.server_path,
                        "db_name": sourceInfoObj.db_name,

                        "isActive": 1,
                        "color": "#FF0000",
                        "desc": "N/A",
                        "type": "profile",
                        "createdby": username,
                        "created": new Date(),
                        "modifiedby": username,
                        "modified": new Date(),
                        "childnode": []
                    }, function (err, result)
                    {
                        if (err) console.log(err);
                        CentralDB.collection('GlobalBucket').find({ dbname: sourceInfoObj.db_name }).toArray(function (err, result)
                        {
                            // Conenct To Server to Copy
                            var predefinedbucket= [];
                            if(pcidata.bucket.length>0)
                            {
                                for(var m=0;m<pcidata.bucket.length;m++)
                                {
                                    predefinedbucket.push({
                                        "type": pcidata.bucket[m].type,
                                        "description": pcidata.bucket[m].description,
                                        "color": pcidata.bucket[m].color,
                                        "bucketname": pcidata.bucket[m].bucketname,
                                        "status": "active",
                                        "createdby": username,
                                        "createddt": new Date(),
                                        "modifiedby": username,
                                        "modifieddt": new Date(),
                                        "bucketdetail": []
                                    })
                                    var arrFilter=result.filter(function(e){return e.bucketname===pcidata.bucket[m].bucketname});
                                    if(arrFilter.length>0)
                                    {
                                        for(var z=0;z<arrFilter.length;z++)
                                        {
                                            var bkdetail=arrFilter[z].bucketdetail;
                                            for(var n=0;n<bkdetail.length;n++)
                                            {
                                                predefinedbucket[m].bucketdetail.push({
                                                    "itemId": bkdetail[n].itemId,
                                                    "fieldname": bkdetail[n].fieldname,
                                                    "range": {
                                                        "from": bkdetail[n].range.from,
                                                        "to": bkdetail[n].range.to
                                                    },
                                                    "text": bkdetail[n].text,
                                                    "tagid": bkdetail[n].tagid,
                                                    "status": bkdetail[n].status
                                                });
                                            }
                                        }
                                    }
                                }
                            }
                            MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                            {
                                //determine filter
                                predefinedbucket;
                                var filterObj = {};
                                var storeFilterObj = {};
                                if (pcidata.filter == 'date')
                                {
                                    var field = sourceInfoObj.dateField[ 0 ];
                                    var andLogicArr = [];
                                    var fromDate = new Date(pcidata.startDate);
                                    var toDate = new Date(pcidata.endDate)

                                    var fromLogic = {};
                                    fromLogic[ field ] = { $gte: fromDate };

                                    var toLogic = {};
                                    toLogic[ field ] = { $lte: toDate };

                                    andLogicArr.push(fromLogic);
                                    andLogicArr.push(toLogic);

                                    filterObj[ '$and' ] = andLogicArr

                                    storeFilterObj.type = 'daterange';
                                    storeFilterObj.from = fromDate;
                                    storeFilterObj.to = toDate;
                                }
                                if (pcidata.filter == 'keyword')
                                {
                                    var field = sourceInfoObj.keywordField[ 0 ];
                                    filterObj[ field ] = { $in: pcidata.keywords }
                                    storeFilterObj.type = 'keyword';
                                    storeFilterObj.keywords = pcidata.keywords;

                                }

                                var SourceDB = db2.db(sourceInfoObj.db_name);
                                var SourceCol = SourceDB.collection('data');

                                //fetch all ids
                                SourceCol.find(filterObj).project({ _id: 1 }).toArray(function (err, allIds)
                                {
                                    var profileDB = db.db(pcidata.profile_name);

                                    //strip angularKey
                                    pcidata.bucket.forEach(buck =>
                                    {
                                        Object.keys(buck).forEach(key =>
                                        {
                                            if (key.startsWith('$'))
                                            {
                                                delete buck[ key ];
                                            }
                                        })
                                    })
                                    var user = serverEncryption.decrypt(req.cookies.user)
                                    // insert infos
                                    profileDB.collection('infos').insertOne({
                                        "profile_name": pcidata.profile_name,
                                        "db_name": sourceInfoObj.db_name,
                                        "server_path": sourceInfoObj.server_path,
                                        "user": user,
                                        "created": new Date(),
                                        "modified": new Date(),
                                        "modifiedby": user,
                                        categories: pcidata.categories,
                                        scoring: pcidata.scoring,
                                        fields: sourceInfoObj.fields,
                                        alias: sourceInfoObj.alias,
                                        filterObj: storeFilterObj,
                                        status: "",
                                        bucket: predefinedbucket
                                        //bucket: pcidata.bucket
                                    }, function (err, res)
                                    {
                                        if (err) console.log(err);
                                        allIds

                                        var copyRef = allIds.map(i =>
                                        {
                                            return {
                                                "parent": i._id,
                                                "useraction": "",
                                                "comment": "",
                                                "modified": null,
                                                "score": -1,
                                                "score_result": ""
                                            }
                                        });
                                        // create copy ref
                                        profileDB.collection('data').insertMany(copyRef, function (err, res)
                                        {
                                            // update records
                                            CentralDB.collection('ProfileInfo').updateOne({ profile_name: pcidata.profile_name }, {
                                                $set: {
                                                    total_record_count: copyRef.length,
                                                }
                                            }, function (err, res)
                                            {
                                                if (err) throw err
                                                db.close();
                                                db2.close();

                                                var profileProcess_url = config.python_url + '/run/' + pcidata.profile_name;
                                                //console.log('calling');
                                                http.get(profileProcess_url, res =>
                                                {
                                                    res.setEncoding("utf8");
                                                    let body = '';
                                                    res.on("data", data =>
                                                    {
                                                        body += data;
                                                    });
                                                    res.on("end", () =>
                                                    {
                                                        console.log('evaluation called', body);
                                                    });
                                                });
                                                //http.get(profileProcess_url, res =>{console.log('evaluation called',res)});

                                                httpResponse.writeHead(200, 'application/json');
                                                httpResponse.write(JSON.stringify({ result: "ok" }));
                                                httpResponse.end();
                                            });

                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    router.post("/getUnfound", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var pcidata = JSON.parse(body);
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);

                var CentralDB = db.db('Master_DB');
                // find SourceDBInfo Obj
                CentralDB.collection('SourceDBInfo').findOne({ _id: ObjectId(pcidata.sourceId) }, function (err, sourceInfoObj)
                {
                    // Create relevant obj in ProfileInfo
                    if (err) console.log(err);
                    // Conenct To Server to Copy
                    MongoClient.connect('mongodb://' + sourceInfoObj.server_path, { useNewUrlParser: true }, async function (err, db2)
                    {
                        //determine filter
                        var filterObj = {};
                        var storeFilterObj = {};

                        if (pcidata.filter == 'keyword')
                        {
                            var field = sourceInfoObj.keywordField[ 0 ];
                            filterObj[ field ] = { $in: pcidata.keywords }
                            storeFilterObj.type = 'keyword';
                            storeFilterObj.keywords = pcidata.keywords;

                        }
                        var projectObj = {};
                        projectObj[ field ] = 1;
                        var SourceDB = db2.db(sourceInfoObj.db_name);
                        var SourceCol = SourceDB.collection('data');

                        //fetch all ids
                        SourceCol.find(filterObj).project(projectObj).toArray(function (err, allItems)
                        {
                            allItems.forEach(item =>
                            {
                                var val = item[field];
                                var i_val = pcidata.keywords.indexOf(val);
                                if(i_val>0)
                                {
                                    pcidata.keywords.splice(i_val,1);
                                }
                            })

                            res.send(JSON.stringify({missing:pcidata.keywords}));
                            res.end();
                            db.close();
                            db2.close();
                        });
                    });

                });
            });
        });
    });

    router.get("/getProfileInfo/:profileId", (req, res) =>
    {
        var profileId = req.params.profileId;
        MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
        {
            var MasterDB = db.db("Master_DB");
            MasterDB.collection('ProfileInfo').findOne({ _id: ObjectId(profileId) }, function (err, profileMasterInfo)
            {
                var prof_dbname = profileMasterInfo.profile_name;
                var prof_path = profileMasterInfo.profile_path;

                MongoClient.connect("mongodb://" + prof_path, { useNewUrlParser: true }, function (err, db1)
                {
                    var profileDB = db1.db(prof_dbname);
                    profileDB.collection('infos').findOne({}, function (err, profileInfo)
                    {
                        res.writeHead(200, 'application/json');
                        res.write(JSON.stringify(profileInfo));
                        res.end();
                        db1.close();
                        db.close();
                    })
                });
            });
        });
    });

    router.post('/login', (req, res) =>
    {
        var msg = '';

        req.on('data', data =>
        {
            msg += data;
        });

        req.on('end', async () =>
        {

            var qss = msg.split('&');

            /**@typedef {object} loginParam 
             * @property {string} username
             * @property {string} password
             * @property {string} remember
             * @property {string} domain
            */

            /**@type {loginParam} */
            var body = {};
            qss.forEach(qs => { var kvp = qs.split('='); body[kvp[0]] = decodeURIComponent(kvp[1]); });


            var mongoAuthenticated = await getUserFromMongo(body.username, body.password);
            var wnsAuthenticated = false;
            if (mongoAuthenticated === false)
            {
                try
                {
                    wnsAuthenticated = await getWNSauthenticated(body.domain, body.username, body.password);
                    if (wnsAuthenticated)
                    {
                        await updateUserInMongo(body.username, body.password);
                    }
                }
                catch (ex) { }
            }

            if (wnsAuthenticated || mongoAuthenticated)
            {
                res.cookie('user', serverEncryption.encrypt(body.username));
                res.cookie('username', body.username);
                res.redirect('/html/Home.html');
            }
            else
            {
                res.send("<script>localStorage.failedattempt=true; document.location.href = '/html/login.html';</script>")
            }
        });

    });

    function getUserFromMongo(username, password)
    {
        return new Promise((res, rej) =>
        {
            MongoClient.connect('mongodb://ggnwgsk4qtx6t2:27017', { useNewUrlParser: true }, (err, db) =>
            {
                var dbo = db.db('Users');
                dbo.collection('accounts').findOne({ user: username }, (err, result) =>
                {
                    if (err)
                    {
                        res(false);
                        db.close();
                        return;
                    }
                    if (result === null || result === undefined)
                    {
                        res(false);
                        db.close();
                        return;
                    }

                    var cr = new Cryptr(username + ':' + password);
                    var hasPassed = false;
                    try
                    {
                        var possibledata = cr.decrypt(result.info);
                        possibledata = JSON.parse(possibledata);
                        if (possibledata.user == username)
                        {
                            hasPassed = true;
                        }
                    }
                    catch (ex) { };

                    res(hasPassed);
                    db.close();
                });
            });
        });
    }

    function updateUserInMongo(username, password)
    {
        var cr = new Cryptr(username + ":" + password);
        var jsonObj = JSON.stringify({ user: username });
        var jsonEnc = cr.encrypt(jsonObj);

        return new Promise((res, rej) =>
        {
            MongoClient.connect('mongodb://ggnwgsk4qtx6t2:27017', { useNewUrlParser: true }, (err, db) =>
            {
                if (err)
                    throw err;

                var dbo = db.db('Users');
                dbo.collection('accounts').updateOne({ user: username }, {
                    $set: {
                        info: jsonEnc
                    }
                }, (err, result) =>
                    {
                        if (err)
                            throw err;
                        if (result.matchedCount > 0)
                        {
                            res();
                            db.close();
                            return
                        }

                        dbo.collection('accounts').insertOne({ user: username, info: jsonEnc }, (err, response) =>
                        {
                            res();
                            db.close();
                        });

                    })
            });
        });
    }

    function getWNSauthenticated(domain, username, password)
    {
        var req = `CONNECT https://www.google.com:443 HTTP/1.1
User-Agent: Mozilla/5.0 (Windows NT; Windows NT 10.0; en-US) WindowsPowerShell/5.1.17763.592
Host: www.google.com
Proxy-Connection: Keep-Alive
            
`
        var initialRequest = req;
        var connId = 0;
        return new Promise((resolve, reject) =>
        {
            var client = new net.Socket();
            client.connect(8080, '10.36.193.47', function ()
            {
                var state = 'status';
                var bodyLen = 0;
                var bodyIndex = 0;

                var kacc = '';
                var acc = '';

                var httpHeader = null;
                var httpBody = null;

                var prevChar = '';

                var onData = data =>
                {
                    console.log('C    P <- S: ' + connId);
                    console.log('----');
                    console.log(data.toString());
                    console.log('----');

                    for (var i = 0; i < data.length; i++)
                    {
                        if (state == 'header' || state == 'status')
                        {
                            var c = String.fromCharCode(data[i]);
                            acc += c;
                            kacc += c;

                            if (c == '\n' && prevChar == '\n')
                            {
                                httpHeader = headerListener(acc);
                                acc = '';

                                if (httpHeader.headers && httpHeader.headers['content-length'] != undefined && httpHeader.headers['content-length'] != '0')
                                {
                                    state = 'body';
                                    bodyLen = parseInt(httpHeader.headers['content-length']);
                                    httpBody = new Uint8Array(bodyLen);
                                    prevChar = '';
                                    continue;
                                }
                                else
                                {

                                    resposneListener(httpHeader, null);
                                }
                            }
                            if (c != '\r')
                                prevChar = c;
                        }
                        if (state == 'body')
                        {
                            httpBody[bodyIndex] = data[i];
                            bodyIndex++;

                            if (bodyIndex >= bodyLen)
                            {
                                resposneListener(httpHeader, httpBody);
                            }
                        }
                    }


                }

                client.on('data', onData);

                function headerListener(data)
                {
                    var obj = headerParser(data.toString());
                    return obj;
                }

                function resposneListener(header, body)
                {
                    var lacc = kacc;
                    kacc = '';
                    acc = '';
                    state = 'status';
                    prevChar = '';
                    httpHeader = null;
                    httpBody = null;
                    bodyLen = 0;
                    bodyIndex = 0;
                    if (typeof onResposne == 'function')
                    {
                        onResposne({ header, body, kacc: lacc });
                    }
                }

                var onResposne = null;

                function sendM1()
                {
                    new Promise((res, rej) => res()).then(() =>
                    {
                        var type1 = ntlm2.challengeHeader(hostname, domain);

                        var ir1 = initialRequest;
                        ir1 = ir1.replace(/\r/g, '');
                        ir1 = ir1.split('\n');
                        if (ir1[ir1.length - 1] == '')
                            ir1.pop();
                        if (ir1[ir1.length - 1] == '')
                            ir1.pop();
                        ir1.push(`Proxy-Authorization: ${type1}`);
                        var closeConIndex = ir1.indexOf('Connection: close');
                        if (closeConIndex >= 0)
                        {
                            ir1.splice(closeConIndex, 1);
                        }
                        if (initialRequest.indexOf('User-Agent') == -1)
                        {
                            ir1.push('User-Agent: DevaAPS/2.1');
                        }
                        ir1.push('');
                        ir1.push('');
                        ir1 = ir1.join('\r\n');

                        //console.log(data);
                        console.log('C    P -> S: ' + connId);
                        console.log('----');
                        console.log(ir1);
                        console.log('----');
                        client.write(ir1);
                    });
                }

                function sendM3(type2)
                {
                    new Promise(res => res()).then(() =>
                    {

                        var res = {
                            headers: {
                                'www-authenticate': type2
                            }
                        };

                        var irh = headerParser(initialRequest);
                        var type3 = ntlm2.responseHeader(res, "https://" + irh.host, domain, username, password);

                        var ir3 = initialRequest;
                        ir3 = ir3.replace(/\r/g, '');
                        ir3 = ir3.split('\n');
                        if (ir3[ir3.length - 1] == '')
                            ir3.pop();
                        if (ir3[ir3.length - 1] == '')
                            ir3.pop();

                        ir3.push(`Proxy-Authorization: ${type3}`);
                        var closeConIndex = ir3.indexOf('Connection: close');
                        if (closeConIndex >= 0)
                        {
                            ir3.splice(closeConIndex, 1);
                        }
                        if (initialRequest.indexOf('User-Agent') == -1)
                        {
                            ir3.push('User-Agent: DevaAPS/2.1');
                        }
                        ir3.push('');
                        ir3.push('');
                        ir3 = ir3.join('\r\n');

                        //ir3 = ir3.replace('Connection: close','Connection: keep-alive');
                        console.log('C    P -> S: ' + connId);
                        console.log(ir3);
                        console.log('----');
                        client.write(ir3);
                    });
                }

                sendM1();
                onResposne = function (response)
                {
                    if (response.header.statusCode == 200)
                    {
                        client.off('data', onData);
                        console.log('M3 not required');
                        console.log('handing over socket');
                        resolve(true);
                    }
                    else
                    {
                        var pa = response.header.headers['proxy-authenticate'];
                        sendM3(pa);
                        console.log('M3 sent');

                        onResposne = function (response)
                        {
                            client.off('data', onData);

                            var irh = headerParser(initialRequest);
                            console.log('handing over socket');

                            if (response.header.statusCode == 200)
                                resolve(true);
                            else
                                resolve(false);
                        }
                    }
                }

            });
        });
    }

})();

(function Services_Himanshu()
{
    router.get("/MstSourceDBsInfo", (req, res) =>
    {
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            dbo.collection("SourceDBInfo").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/checkGroupExistence", (req, res) =>
    {
        var url1 = req.url;
        var groupname = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            var query = { status: "completed" };
            dbo.collection("ProfileInfo").find(query).toArray(function (err, result)
            {
                if (err) console.log(err);
                console.log("DuplicacyFound");
                res.write(JSON.stringify({ "Result": "DuplicacyFound" }));
                res.end();
                db.close();
            });
        });
    });

    router.get("/MstProfiles", (req, res) =>
    {
        var url1 = req.url;
        var username = serverEncryption.decrypt(req.cookies.user);
        url1 = url1.replace(/\$\{userid\}/g,username);

        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            dbo.collection("ProfileInfo").find({createdby:username}).sort({modified:-1}) .toArray(function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/CheckProfileCreationStatus", (req, res) =>
    {
        var url1 = req.url;
        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            var query = { profile_name: ProfileDBName };
            dbo.collection("ProfileInfo").find(query).toArray(function (err, result)
            {
                if (err) console.log(err);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                if (result.length > 0)
                {
                    var dbo = db.db(result[ 0 ].profile_name);
                    dbo.collection("infos").find({}).toArray(function (err, result)
                    {
                        if (err) console.log(err);
                        if (result.length > 0)
                        {
                            dbo.collection("data").find({}).toArray(function (err, result)
                            {
                                if (err) console.log(err);
                                if (result.length > 0)
                                {
                                    var query = { status: "completed" };
                                    dbo.collection("infos").find(query).toArray(function (err, result)
                                    {
                                        if (err) console.log(err);
                                        //res.writeHead(200, { 'Content-Type': 'application/json' });
                                        if (result.length > 0)
                                        {
                                            res.write(JSON.stringify({ "ReqStatus": "completed" }));
                                            console.log("completed");
                                        }
                                        else
                                        {
                                            res.write(JSON.stringify({ "ReqStatus": "score_updating" }));
                                            console.log("score_updating");
                                        }
                                        res.end();
                                        db.close();
                                    });
                                }
                                else
                                {
                                    res.write(JSON.stringify({ "ReqStatus": "data_collection_creation" }));
                                    console.log("data_collection_creation");
                                    res.end();
                                    db.close();
                                }
                            });
                        }
                        else
                        {
                            res.write(JSON.stringify({ "ReqStatus": "Infos_collection_creation" }));
                            console.log("Infos_collection_creation");
                            res.end();
                            db.close();
                        }
                    });
                }
                else
                {
                    res.write(JSON.stringify({ "ReqStatus": "Mst_DB_profile_creation" }));
                    console.log("Mst_DB_profile_creation");
                    res.end();
                    db.close();
                }
            });
        });
    });


    router.get("/DeleteGroup", (req, res) =>
    {
        var url1 = req.url;
        var GroupName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        url = dbIP;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            //var myquery = { profile_name: GroupName };
            
            dbo.collection("ProfileInfo").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var strData=JSON.stringify(result);
                var arrData=JSON.parse(strData);
                if(arrData.length>0)
                {
                    var delGroup=arrData.filter(function(el)
                    {
                        return el.profile_name==GroupName
                    })
                    var childnodes=delGroup[0].childnode;
                    var delProfiles="";
                    var delDbs=[];
                    delProfiles=delGroup[0]._id;
                    for(var k=0;k<childnodes.length;k++)
                    {
                        delProfiles=delProfiles+","+childnodes[k].node;
                        delDbs.push(childnodes[k].node);
                    }
                    delProfiles = delProfiles.split(',').map(i => ObjectId(i));
                    var query = { _id: { $in: delProfiles } };
                    dbo.collection("ProfileInfo").deleteMany(query, function (err, obj) 
                    {
                        arrData;
                        delDbs;
                        for(var t=0;t<delDbs.length;t++)
                        {
                            var proname=arrData.filter(function(el)
                            {
                                return el._id==delDbs[t]
                            })
                            var dbo = db.db(proname[0].profile_name);
                            dbo.dropDatabase(function (err, result)
                            {
                                console.log("Error : " + err);
                                if (err) throw err;
                                //console.log(proname[0].profile_name + " DB has been deleted successfully");
                                res.write(JSON.stringify({"Result":"Group_Deleted"}));
                            });
                        }
                    });
                }
            });
            res.write(JSON.stringify({"Result":"Group_Deleted"}));
            res.end();
            db.close();
        });
    });

    router.get("/DeleteProfile", (req, res) =>
    {
        var url1 = req.url;
        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var ProfileId = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            var myquery = { _id: ObjectId(ProfileId) };
            dbo.collection("ProfileInfo").deleteOne(myquery, function (err, obj) 
            {
                if (err) throw err;
                var dbo = db.db(ProfileDBName);
                dbo.dropDatabase(function (err, result)
                {
                    console.log("Error : " + err);
                    if (err) throw err;
                    console.log(ProfileDBName + " DB has been deleted successfully");
                    res.write(JSON.stringify(result));
                    res.end();
                    db.close();
                });
            });
        });
    });

    router.get("/MstItems", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var inId = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]).split(',');
        inId = inId.map(i => ObjectId(i));
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("data").find({ _id: { $in: inId } }).toArray(function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });


    router.post("/MstCustomFilterItems", (req, res) =>
    {
        var body = '';
        var url1 = req.url;
        var url = dbIP;
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var pcidata = JSON.parse(body);

            MongoClient.connect(url, function (err, db)
            {
                if (err) console.log(err);
                pcidata;
                var dbo = db.db(pcidata.db_name);
                var query = {};
                var nodes=pcidata.nodes;
                var objIds=pcidata.objIds;
                for(var m=0;m<nodes.length;m++)
                {
                    if(nodes[m].ctrlType=="date")
                    {
                        var startDT = new Date(nodes[m].startDT);
                        var endDT = new Date(nodes[m].endDT);
                        var filterStartDT = new Date(startDT.getFullYear(), startDT.getMonth(), startDT.getDate(), 0, 0, 0);
                        var filterEndDT = new Date(endDT.getFullYear(), endDT.getMonth(), endDT.getDate(), 0, 0, 0);

                        query[ nodes[m].fieldName ] = { $gte: filterStartDT, $lte: filterEndDT };
                    }
                    else
                    {
                        var fieldValue = nodes[m].value.replace(new RegExp('----', 'g'), ' ').replace(new RegExp('____', 'g'), '&');
                        query[ nodes[m].fieldName ] = { $regex: fieldValue.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
                    }
                }
                var inId = objIds.map(i => ObjectId(i));
                query[ "_id" ] = { $in: inId };
                dbo.collection("data").find(query, { projection: { _id: 1 } }).toArray(function (err, result)
                {
                    if (err) console.log(err);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.write(JSON.stringify(result));
                    res.end();
                    db.close();
                });
            });
        })
    })


    router.post("/MstCustomSortItems", (req, res) =>
    {
        var body = '';
        var url1 = req.url;
        var url = dbIP;
        var httpResponse = res;
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var pcidata = JSON.parse(body);

            MongoClient.connect(url, function (err, db)
            {
                if (err) console.log(err);
                pcidata;
                
                var dbName = pcidata.dbName;
                var PfName = pcidata.PfName;
                var fieldName = pcidata.fieldName;
                var sortOption = pcidata.sortOption;
                var objIds = pcidata.objIds;

                var inId = objIds.map(i => ObjectId(i));

                var mysort = {};
                if (sortOption.split('_')[ 1 ] == 'desc')
    {
                    mysort[ fieldName ] = -1;
                }
                else
    {
                    mysort[ fieldName ] = 1;
                }
                dbo = db.db(dbName);
                dbo.collection("data").find({ _id: { $in: inId } }, { projection: { _id: 1 } }).sort(mysort).toArray(function (err, result)
                {
                    if (err) console.log(err);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.write(JSON.stringify(result));
                    res.end();
                    db.close();
                })
            });
        })
    })

    router.get("/MstCustomFilterItems_old", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var fieldName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var fieldValue = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        var isDate = (((url1.split('?')[ 1 ]).split('&')[ 4 ]).split('=')[ 1 ]);
        url = dbIP;
        var query = {};
        if (isDate == 'Yes')
        {
            var dates = fieldValue.split('___');
            var startDT = new Date(dates[ 0 ]);
            var endDT = new Date(dates[ 1 ]);
            var filterStartDT = new Date(startDT.getFullYear(), startDT.getMonth(), startDT.getDate(), 0, 0, 0);
            var filterEndDT = new Date(endDT.getFullYear(), endDT.getMonth(), endDT.getDate(), 0, 0, 0);
            query[ fieldName ] = { $gte: filterStartDT, $lte: filterEndDT };
            /*
            query={ $where: function() 
            { 
                return (new Date(this[fieldName]).getMonth() == DT.getMonth() && new Date(this[fieldName]).getFullYear() == DT.getFullYear() && new Date(this[fieldName]).getDate()==DT.getDate())
            }}
            */
        }
        else
        {
            fieldValue = fieldValue.replace(new RegExp('----', 'g'), ' ').replace(new RegExp('____', 'g'), '&');
            query[ fieldName ] = { $regex: fieldValue.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
        }
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("data").find(query, { projection: { _id: 1 } }).toArray(function (err, result)
            {
                if (err) console.log(err);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/MstCustomSortItems_old", (req, res) =>
    {
        var url1 = req.url;
        var dbName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var dbPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var PfName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var PfPath = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        var fieldName = (((url1.split('?')[ 1 ]).split('&')[ 4 ]).split('=')[ 1 ]);
        var sortOption = (((url1.split('?')[ 1 ]).split('&')[ 5 ]).split('=')[ 1 ]);

        arrInfosDataFilter = new Array();
        arrFilterData = new Array();

        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(PfName);
            dbo.collection("data").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var arrJson = JSON.stringify(result);
                arrInfosDataFilter = JSON.parse(arrJson);
                var inId = "";
                if (arrInfosDataFilter.length > 0)
                {
                    for (var k = 0; k < arrInfosDataFilter.length; k++)
                    {
                        if (inId == '')
                            inId = arrInfosDataFilter[ k ].parent;
                        else
                            inId = inId + ',' + arrInfosDataFilter[ k ].parent;
                    }
                    inId = inId.split(',').map(i => ObjectId(i));
                    dbo = db.db(dbName);
                    var mysort = {};
                    if (sortOption.split('_')[ 1 ] == 'desc')
                    {
                        mysort[ fieldName ] = -1;
                    }
                    else
                    {
                        mysort[ fieldName ] = 1;
                    }
                    dbo.collection("data").find({ _id: { $in: inId } }, { projection: { _id: 1 } }).sort(mysort).toArray(function (err, result)
                    {
                        if (err) console.log(err);
                        res.writeHead(200, { 'Content-Type': 'application/json' });
                        res.write(JSON.stringify(result));
                        res.end();
                        db.close();
                    })
                }
            })
        });
    });

    router.get("/MstSelectedProfileInfos", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("infos").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/getProfileInformation", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        url = dbIP;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("infos").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var savedInfo = JSON.stringify(result)
                var dbInfo = JSON.parse(savedInfo);
                if (err) console.log(err);
                res.write(dbInfo);
                res.end();
                db.close();
            });
        });
    });

    router.get("/checkBucketExistence", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var bucketname = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        url = dbIP;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("infos").find({}, { projection: { bucket: 1 } }).toArray(function (err, result)
            {
                if (err) console.log(err);
                var savedInfo = JSON.stringify(result)
                var dbInfo = JSON.parse(savedInfo);
                dbInfo = dbInfo[ 0 ].bucket;
                var result = dbInfo.filter(function (c)
                {
                    return (c.bucketname.toLowerCase() == bucketname.toLowerCase())
                });
                if (result.length > 0)
                {
                    if (err) console.log(err);
                    console.log("DuplicacyFound");
                    res.write(JSON.stringify({ "Result": "DuplicacyFound" }));
                    res.end();
                    db.close();
                }
                else
                {
                    if (err) console.log(err);
                    console.log("Valid");
                    res.write(JSON.stringify({ "Result": "Valid" }));
                    res.end();
                    db.close();
                }
            });
        });
    });

    router.get("/CreateIndex", (req, res) =>
    {
        var url1 = req.url;
        var arrFields = new Array();
        url = dbIP;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db("Master_DB");
            dbo.collection("SourceDBInfo").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var arrData = JSON.stringify(result);
                arrFields = JSON.parse(arrData);
                if (arrFields.length > 0)
                {
                    for (var k = 0; k < arrFields.length; k++)
                    {
                        var alias = arrFields[ k ].alias;
                        var dbo = db.db(arrFields[ k ].db_name);

                        var keys = Object.keys(arrFields[ k ].alias);
                        for (var s = 0; s < keys.length; s++)
                        {
                            var query = {};
                            query[ arrFields[ k ].alias[ keys[ s ] ] ] = 1;
                            dbo.collection("data").createIndex(query, function (err, result)//ensureIndex,createIndex,dropIndexes,indexInformation
                            {
                                if (err) console.log(err);
                                console.log(result);
                            });
                        }
                    }
                }
                res.end();
                db.close();
            });
        });
    });



    router.get('/MstSelectedProfileData', (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var action = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        url = dbIP;
        var query = {};
        if (action == "allitems")
        {
            query = {};
        }
        else if (action == "pending")
        {
            query = { useraction: "" };
        }
        else if (action == "relevant")
        {
            query = { useraction: "relevant" };
        }
        else if (action == "not-relevant")
        {
            query = { useraction: "not-relevant" };
        }
        else if (action == "seen")
        {
            query = { modified: { $ne: "" }, useraction: "" }
        }
        else if (action == "unseen")
        {
            query = { modified: { $eq: "" }, useraction: "" }
        }
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            dbo.collection("data").find(query).toArray(function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/doItemUpdate", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var response = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var objId = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        var comm = (((url1.split('?')[ 1 ]).split('&')[ 4 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            var myquery = { _id: ObjectId(objId) };
            var newvalues = { $set: { useraction: response, modified: new Date(), comment: decodeURI(comm) } };
            dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                console.log("1 document updated");
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });

    router.get("/doCommentUpdate", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var objId = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var comm = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            var myquery = { parent: ObjectId(objId) };
            var newvalues = { $set: { comment: decodeURI(comm) } };
            dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                console.log("1 document updated");
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    });


    router.get("/doDeleteBucket", (req, res) =>
    {
        var url1 = req.url;
        var username = serverEncryption.decrypt(req.cookies.user);
        url1 = url1.replace(/\$\{userid\}/g,username);

        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var objId = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var info = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        url = dbIP;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            var decodeInfo = decodeURIComponent(info);
            var arrInfo = JSON.parse(decodeInfo);
            dbo.collection('infos').find({}, { projection: { bucket: 1 } }).toArray(function (err, result)
            {
                if (err) console.log(err);
                var savedInfo = JSON.stringify(result)
                var dbInfo = JSON.parse(savedInfo);
                dbInfo = dbInfo[ 0 ].bucket;

                var bucketname = arrInfo.bucketname;
                var dbField = arrInfo.field;
                var modifiedby = arrInfo.modifiedby;
                var modifieddt = arrInfo.modifieddt;
                var itemId = arrInfo.itemid;
                var from = arrInfo.start;
                var to = arrInfo.end;
                var tagid = itemId + "_" + dbField.replace(/\s/g, '') + "_" + from + "_" + to;
                var result = dbInfo.filter(function (c)
                {
                    return (c.bucketname.toLowerCase() == bucketname.toLowerCase())
                });
                if (result.length > 0)
                {
                    var iFound = 0;
                    if (result[ 0 ].bucketdetail.length > 0)
                    {
                        for (var i = 0; i < result[ 0 ].bucketdetail.length; i++)
                        {
                            if (result[ 0 ].bucketdetail[ i ].tagid == tagid)
                            {
                                iFound = 1;
                                //result[0].bucketdetail.splice(i,1);
                                result[ 0 ].bucketdetail[ i ].status = "deleted";
                            }
                        }
                        if (iFound == 1)
                        {
                            var newvalues = { $set: { bucket: dbInfo } };
                            dbo.collection('infos').updateOne({}, newvalues, function (err, result)
                            {
                                if (err) console.log(err);
                                res.write(JSON.stringify({ "Result": "Bucket_deleted" }));
                                res.end();
                                db.close();
                            });
                        }
                        else
                        {
                            if (err) console.log(err);
                            console.log("BucketNotFound");
                            res.write(JSON.stringify({ "Result": "BucketNotFound" }));
                            res.end();
                            db.close();
                        }
                    }
                    else
                    {
                        if (err) console.log(err);
                        console.log("TaggingNotFound");
                        res.write(JSON.stringify({ "Result": "TaggingNotFound" }));
                        res.end();
                        db.close();
                    }
                }
                else
                {
                    if (err) console.log(err);
                    console.log("BucketNotFound");
                    res.write(JSON.stringify({ "Result": "BucketNotFound" }));
                    res.end();
                    db.close();
                }
            });
        });
    });



    router.post("/doUpdateBucket", (req, res) =>
    {
        var body = '';
        
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var username = serverEncryption.decrypt(req.cookies.user);
            body = body.replace(/\$\{userid\}/g,username);
            var pcidata = JSON.parse(body);
        
        var url1 = req.url;
            var db_name=pcidata[0].dbName;
            var objId=pcidata[0].objId;
        url = dbIP;
            var httpResponse = res;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
                var arrInfo = pcidata[0].info;
            dbo.collection('infos').find({}, { projection: { bucket: 1 } }).toArray(function (err, result)
            {
                if (err) console.log(err);
                var savedInfo = JSON.stringify(result)
                var dbInfo = JSON.parse(savedInfo);
                dbInfo = dbInfo[ 0 ].bucket;
                var bucketname = arrInfo[ 0 ].bucketname;
                var result = dbInfo.filter(function (c)
                {
                    return (c.bucketname.toLowerCase() == bucketname.toLowerCase())
                });
                if (result.length > 0)
                {
                    var dbField = arrInfo[ 0 ].fieldname;
                    var modifiedby = arrInfo[ 0 ].modifiedby;
                    var modifieddt = arrInfo[ 0 ].modifieddt;
                    var selectedText = arrInfo[ 0 ].text;
                    var itemId = arrInfo[ 0 ].itemId;
                    var from = arrInfo[ 0 ].from;
                    var to = arrInfo[ 0 ].to;
                        var strcomment = arrInfo[ 0 ].comment;
                    var isValidate = false;
                    if (result[ 0 ].bucketdetail.length > 0)
                    {
                        var chk = false;
                        var ns = from;
                        var ne = to;
                        var diff = ne - ns;
                        if (diff < 0)
                        {
                            console.log("WrongSelection");
                            res.write(JSON.stringify({ "Result": "WrongSelection" }));
                            res.end();
                            db.close();
                        }
                        else
                        {
                            for (var i = 0; i < diff; i++)
                            {
                                for (var t = 0; t < dbInfo.length; t++)
                                {
                                    for (var r = 0; r < dbInfo[ t ].bucketdetail.length; r++)
                                    {
                                        if (ns >= parseInt(dbInfo[ t ].bucketdetail[ r ].range.from) && ns <= parseInt(dbInfo[ t ].bucketdetail[ r ].range.to))
                                        {
                                            if (dbInfo[ t ].bucketdetail[ r ].itemId == itemId && dbInfo[ t ].bucketdetail[ r ].fieldname == dbField && dbInfo[ t ].bucketdetail[ r ].status == "active")
                                            {
                                                chk = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (chk == true)
                                    {
                                        break;
                                    }
                                }
                                if (chk == true)
                                {
                                    break;
                                }
                                ns++;
                            }
                            if (chk == true)
                            {
                                console.log("Overlapping");
                                res.write(JSON.stringify({ "Result": "Overlapping" }));
                                res.end();
                                db.close();
                            }
                            else
                            {
                                isValidate = true;
                            }
                        }
                    }
                    else
                    {
                        isValidate = true;
                    }

                    if (isValidate == true)
                    {
                        result[ 0 ].bucketdetail.push({ itemId: itemId, fieldname: dbField, range: { from: from, to: to }, text: selectedText, tagid: itemId + "_" + dbField.replace(/\s/g, '') + "_" + from + "_" + to, status: 'active',comment:strcomment });
                        result[ 0 ].modifiedby = modifiedby;
                        result[ 0 ].modifieddt = modifieddt;

                        var newvalues = { $set: { bucket: dbInfo } };
                        dbo.collection('infos').updateOne({}, newvalues, function (err, result)
                        {
                            if (err) console.log(err);
                            res.write(JSON.stringify({ "Result": "Bucket_updated" }));
                            res.end();
                            db.close();
                        });
                    }
                }
                else
                {
                    if (err) console.log(err);
                    console.log("BucketNotFound");
                    res.write(JSON.stringify({ "Result": "BucketNotFound" }));
                    res.end();
                    db.close();
                }
            });
        });
        })
    });

    router.get("/doLastSeenUpdate", (req, res) =>
    {
        var url1 = req.url;
        var db_name = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var db_path = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var parentID = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var lstSeen = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        url = dbIP;
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(db_name);
            var myquery = { parent: ObjectId(parentID) };
            var newvalues = {};
            if (lstSeen == 'Y')
                newvalues = { $set: { modified: new Date() } };
            else
                newvalues = { $set: { modified: "" } };

            dbo.collection('data').updateOne(myquery, newvalues, function (err, result)
            {
                if (err) console.log(err);
                //console.log(result);
                console.log("1 document updated");
                res.write(JSON.stringify(result));
                res.end();
                db.close();
            });
        });
    })


    router.post("/updategroup", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var grpinfo = JSON.parse(body);
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);
                var CentralDB = db.db('Master_DB');
                // find ProfileInfo Obj
                CentralDB.collection('ProfileInfo').find({}).toArray(function (err, result)
                {
                    if (err) console.log(err);
                    var arrCentralProfileDBInfo=[];
                    var arrJson = JSON.stringify(result);
                    arrCentralProfileDBInfo = JSON.parse(arrJson);
                    var grpname=grpinfo[0].groupname;
                    var arrSelectedProfiles=grpinfo[0].profilesinfo;
                    var SelectedGroupID=grpinfo[0].groupid;
                    var operation=grpinfo[0].op;
                    var arrChildNode=[];
                    var isExist={};
                    var selectedNodes=[];
                    var retOrgGrpName=arrCentralProfileDBInfo.filter(function(e)
                    {
                        return e._id==SelectedGroupID
                    })
                    var savedName="";
                    if(retOrgGrpName.length>0)
                    {
                        savedName=retOrgGrpName[0].profile_name;
                    }
                    for(var t=0;t<arrSelectedProfiles.length;t++)
                    {
                        selectedNodes.push({"node":arrSelectedProfiles[t].DestinationProfile});
                    }
                    for(var c=0;c<arrCentralProfileDBInfo.length;c++)
                    {
                        if(arrCentralProfileDBInfo[c].profile_name==grpname && operation=="creategroup")
                        {
                            isExist={"Status":"Failed","profileid":arrCentralProfileDBInfo[c]._id,"profilename":arrCentralProfileDBInfo[c].profile_name,"Error":"Group name : "+grpname+" already exist"};
                        }
                        else if(operation=="updategroup" && arrCentralProfileDBInfo[c].profile_name==grpname && arrCentralProfileDBInfo[c]._id!=SelectedGroupID)
                        {
                            isExist={"Status":"Failed","profileid":arrCentralProfileDBInfo[c]._id,"profilename":arrCentralProfileDBInfo[c].profile_name,"Error":"Group name : "+grpname+" already exist"};
                        }
                        if(arrCentralProfileDBInfo[c].type!=undefined)
                        {
                            if(arrCentralProfileDBInfo[c].type=='group')
                            {
                                for(var m=0;m<arrCentralProfileDBInfo[c].childnode.length;m++)
                                {
                                    arrChildNode.push({'childnode':arrCentralProfileDBInfo[c].childnode[m].node,'parentnode':arrCentralProfileDBInfo[c]._id,'ChildNodeName':arrCentralProfileDBInfo[c].profile_name});
                                }
                            }
                        }
                    }
                    if(isExist.Status!="Failed")
                    {
                        if(operation=="updategroup")
                        {
                            var retGroupID=arrCentralProfileDBInfo.filter(function(e)
                            {
                                return e._id==SelectedGroupID
                            })
                            for(var c=0;c<arrSelectedProfiles.length;c++)
                            {
                                var retPro=arrChildNode.filter(function(el)
                                {
                                    return el.childnode==arrSelectedProfiles[c].DestinationProfile && el.parentnode!=retGroupID[0]._id
                                })
                                if(retPro.length>0)
                                {
                                    isExist={"Status":"Failed","profileid":retPro[0].childnode,"profilename":retPro[0].ChildNodeName,"Error":"Profile already exist in another group"};
                                }
                            }
                        }
                        else
                        {
                            for(var c=0;c<arrSelectedProfiles.length;c++)
                            {
                                var retPro=arrChildNode.filter(function(el)
                                {
                                    return el.childnode==arrSelectedProfiles[c].DestinationProfile
                                })
                                if(retPro.length>0)
                                {
                                    isExist={"Status":"Failed","profileid":retPro[0].childnode,"profilename":retPro[0].ChildNodeName,"Error":"Profile already exist in another group"};
                                }
                            }
                        }
                        
                        if(isExist.Status=="Failed")
                        {
                            httpResponse.writeHead(200, { 'Content-Type': 'application/json' });
                            httpResponse.write(JSON.stringify({ "Result": isExist }));
                            httpResponse.end();
                            db.close();
                        }
                        else
                        {
                            if(operation=="creategroup")
                            {
                                CentralDB.collection('ProfileInfo').insertOne(
                                {
                                    "profile_name": grpinfo[0].groupname,
                                    "profile_path": config.new_profile_db_server,
        
                                    "db_source_path": "",
                                    "db_name": "",
        
                                    "isActive": 1,
                                    "color": "#FF0000",
                                    "desc": "N/A",
                                    "type": "group",
                                    "childnode": selectedNodes,
                                    "total_record_count":selectedNodes.length
                                }, function (err, result)
                                {
                                    if (err) console.log(err);
                                    isExist={"Status":"Success","profileid":"","profilename":grpinfo[0].groupname,"Error":"Group has been created successfully."};
                                    httpResponse.writeHead(200, { 'Content-Type': 'application/json' });
                                    httpResponse.write(JSON.stringify({ "Result": isExist }));
                                    httpResponse.end();
                                    db.close();
                                })
                            }
                            else if(operation=="updategroup")
                            {
                                CentralDB.collection('ProfileInfo').updateOne({ _id: ObjectId(SelectedGroupID) }, {
                                    $set: {
                                        "type": "group",
                                        "profile_name": grpinfo[0].groupname,
                                        "childnode": selectedNodes,
                                        "total_record_count":selectedNodes.length
                                    }
                                    }, function (err, res)
                                        {
                                            if (err) throw err
                                            isExist={"Status":"Success","profileid":"","profilename":grpinfo[0].groupname,"Error":"Group has been updated successfully."};
                                            httpResponse.writeHead(200, { 'Content-Type': 'application/json' });
                                            httpResponse.write(JSON.stringify({ "Result": isExist }));
                                            httpResponse.end();
                                            db.close();
                                        }
                                    )
                            }
                        }
                    }
                    else
                    {
                        httpResponse.writeHead(200, { 'Content-Type': 'application/json' });
                        httpResponse.write(JSON.stringify({ "Result": isExist }));
                        httpResponse.end();
                        db.close();
                    }
                })
            })
        });
    })


    router.post("/groupinfo", (req, res) =>
    {
        var body = '';
        var httpResponse = res;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        req.on('data', function (data)
        {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });

        req.on('end', function ()
        {
            body;
            req;

            var grpinfo = JSON.parse(body);
            MongoClient.connect(url, { useNewUrlParser: true }, function (err, db)
            {
                //var dbo = db.db(db_name);
                var CentralDB = db.db('Master_DB');
                // find ProfileInfo Obj
                var grpid=grpinfo[0].grpid;
                CentralDB.collection('ProfileInfo').find({_id:ObjectId(grpid)}).toArray(function (err, result)
                {
                    if (err) console.log(err);
                    var childnodeinfo=[];
                    var arrJson = JSON.stringify(result);
                    childnodeinfo = JSON.parse(arrJson);
                    res.write(JSON.stringify(childnodeinfo));
                    res.end();
                    db.close();
                })
            })
        });
    })


    router.get("/ExcelExport_xlsx/:filename", (req, res) =>
    {
        var url1 = req.url;
        var SourceDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var SourceDBPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var ProfileDBPath = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        arrInfosDataFilter = new Array();
        arrFilterData = new Array();
        arrInfosData=new Array();
        
        url = dbIP;
        //res.writeHead(200, { 'Content-Type': 'application/json' });
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(ProfileDBName);
            dbo.collection("data").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var arrJson = JSON.stringify(result);
                arrInfosDataFilter = JSON.parse(arrJson);
                var inId = "";
                if (arrInfosDataFilter.length > 0)
                {
                    for (var k = 0; k < arrInfosDataFilter.length; k++)
                    {
                        if (inId == '')
                            inId = arrInfosDataFilter[ k ].parent;
                        else
                            inId = inId + ',' + arrInfosDataFilter[ k ].parent;
                    }
                    inId = inId.split(',').map(i => ObjectId(i));
                    dbo = db.db(SourceDBName);
                    dbo.collection("data").find({ _id: { $in: inId } }).toArray(function (err, result)
                    {
                        arrInfosDataFilter;
                        if (err) console.log(err);

                        arrFilterData = [];
                        result.forEach(row =>
                        {
                            var cloneObj = {};
                            Object.keys(row).forEach(key =>
                            {
                                cloneObj[ key ] = JSON.parse(JSON.stringify(row[ key ]));
                            })
                            arrFilterData.push(cloneObj);
                        });

                        // array object copy code

                        dbo = db.db(ProfileDBName);
                        dbo.collection("infos").find({}).toArray(function (err, result)
                        {
                            arrInfosDataFilter;
                            arrFilterData;
                            if (err) console.log(err);
                            arrInfosData = [];

                            //cloneing code
                            result.forEach(row =>
                            {
                                var cloneObj = {};
                                arrInfosData.push(cloneObj);
                                Object.keys(row).forEach(key =>
                                {
                                    cloneObj[key] = JSON.parse(JSON.stringify(row[key]));
                                })
                            })
                            var keys = Object.keys(arrFilterData[ 0 ]);
                            keys.splice(0, 1);
                            var arrSheet=[];
                            var arrMetaData=[];
                            var cells={};
                            var metadata={};
                            if(arrInfosData[0].categories.length>0)
                            {
                                for(var z=0;z<arrInfosData[0].categories.length;z++)
                                {
                                    metadata={
                                                "Type":"Category",
                                                "Name":arrInfosData[0].categories[z].catname,
                                                "Fields/Condition":arrInfosData[0].categories[z].fields.join(" , "),
                                                "Keywords/Weight":arrInfosData[0].categories[z].keywords.join(" , ")
                                            }
                                    arrMetaData.push(metadata);
                                }
                            }
                            if(arrInfosData[0].scoring.length>0)
                            {
                                for(var m=0;m<arrInfosData[0].scoring.length;m++)
                                {
                                    metadata={
                                        "Type":"Score",
                                        "Name":arrInfosData[0].scoring[m].name,
                                        "Fields/Condition":arrInfosData[0].scoring[m].query,
                                        "Keywords/Weight":arrInfosData[0].scoring[m].weight
                                    }
                                    arrMetaData.push(metadata);
                                }
                            }
                            var keyname="";
                            for (var r = 0; r < arrFilterData.length; r++)
                            {
                                cells={};
                                for (var t = 0; t < keys.length; t++)
                                {
                                    var ret = arrInfosDataFilter.filter(function (em)
                                    {
                                        return (em.parent == arrFilterData[ r ]._id)
                                    })
                                    if (ret.length > 0)
                                    {
                                        if (t == keys.length - 1)
                                        {
                                            keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                            cells[keyname]=arrFilterData[ r ][ keys[ t ] ];
                                        }
                                        else
                                        {
                                            if (t == 0)
                                            {
                                                cells["SNO"]=(r + 1);
                                                keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                cells[keyname]=arrFilterData[ r ][ keys[ t ] ];
                                            }
                                            else if (t == 3)
                                            {
                                                cells["USER_ACTION"]=ret[ 0 ].useraction;
                                                cells["SCORE"]=ret[ 0 ].score;
                                                cells["ACTION_RESULT"]=ret[ 0 ].score_result;
                                                cells["ACTION_DATE"]=ret[ 0 ].modified;
                                                cells["COMMENT"]=ret[ 0 ].comment;
                                                keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                cells[keyname]=arrFilterData[ r ][ keys[ t ] ];
                                            }
                                            else
                                            {
                                                keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                cells[keyname]=arrFilterData[ r ][ keys[ t ] ];
                                            }
                                        }
                                    }
                                }
                                if(arrInfosData[0].bucket!=undefined)
                                {
                                    if(arrInfosData[0].bucket.length>0)
                                    {
                                        var appendBuk="";
                                        for(var l=0;l<arrInfosData[0].bucket.length;l++)
                                        {
                                            appendBuk="";
                                            if(arrInfosData[0].bucket[l].bucketdetail.length>0)
                                            {
                                                for(var c=0;c<arrInfosData[0].bucket[l].bucketdetail.length;c++)
                                                {
                                                    var bkInfo=arrInfosData[0].bucket[l].bucketdetail;
                                                    var cnt=arrFilterData[ r ][ bkInfo[c].fieldname ].substring(parseInt(bkInfo[c].range.from),parseInt(bkInfo[c].range.to))
                                                    if(bkInfo[c].itemId==arrFilterData[ r ]._id && bkInfo[c].status=="active")
                                                    {
                                                        appendBuk=appendBuk+"<b>"+bkInfo[c].fieldname+" : </b>"+cnt+";"
                                                    }
                                                }
                                            }
                                            if(appendBuk!=="")
                                            {
                                                keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                cells[keyname]=appendBuk;
                                            }
                                            else
                                            {
                                                keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                cells[keyname]="";
                                            }
                                        }
                                    }
                                }
                                arrSheet.push(cells);
                                cells={};
                            }
                            if(typeof XLSX == 'undefined') XLSX = require('xlsx');
                            var ws = XLSX.utils.json_to_sheet(arrSheet);
                            var wsMetaData = XLSX.utils.json_to_sheet(arrMetaData);
                            var wb = XLSX.utils.book_new();
                            XLSX.utils.book_append_sheet(wb, wsMetaData, "metadata");
                            XLSX.utils.book_append_sheet(wb, ws, "data");
                            //XLSX.writeFile(wb, ProfileDBName+".xlsx");

                            var wopts = { bookType:'xlsx', bookSST:false, type:'array' };
                            var wbout = XLSX.write(wb,wopts);
                            wbout = new Buffer(wbout);
                            res.writeHead(200,'application/octet-stream')
                            res.write(wbout);
                            //res.write(JSON.stringify(arrSheet));
                            res.end();
                            db.close();
                        })
                    });
                }
            });
        });
    });

    getSourceDataInfo = function (arrPagination,arrInfosDataFilter,count,dbo,db,ProfileDBName,httpResponse,filterQueryData)
    {
        //npm install popups
        //console.log(count,arrPagination[count].Start-1,arrPagination[count].End-1);
        
        var msg = {
            Task: 'FetchingData',
            Start : arrPagination[count].Start,
            End : arrPagination[count].End,
            Total:arrInfosDataFilter.length
        }
        msg = JSON.stringify(msg);
        httpResponse.send(msg);

        var inId="";
        for (var k = arrPagination[count].Start-1; k <= arrPagination[count].End-1; k++)
        {
            if (inId == '')
                inId = arrInfosDataFilter[ k ].parent;
            else
                inId = inId + ',' + arrInfosDataFilter[ k ].parent;
        }
        inId = inId.split(',').map(i => ObjectId(i));

        var appliedFilters=[];
        var appliedColumns=[];
        var query={};
        var projectedColumns={};
        if(filterQueryData.length>0)
        {
            appliedFilters=filterQueryData[0].appliedFilter
            appliedColumns=filterQueryData[0].appliedColumns

            for(var x=0;x<appliedColumns.length;x++)
            {
                projectedColumns[appliedColumns[x].Column]=1;
            }
            query={ _id: { $in: inId } };
        }
        else
        {
            query={ _id: { $in: inId } };
            projectedColumns={};
        }

        dbo.collection("data").find(query,{ projection: projectedColumns }).toArray(function (err, result)//{ projection:projectedColumns}
        {
            arrInfosDataFilter;
            filterQueryData;
            if (err) console.log(err);
            
            result.forEach(row =>
            {
                arrFilterData.push(row);
            });
            
            
            count++;
            if(count<arrPagination.length)
            {
                getSourceDataInfo(arrPagination,arrInfosDataFilter,count,dbo,db,ProfileDBName,httpResponse,filterQueryData);
            }
            else
            {
                filterQueryData;
                var dbContent="";
                var msg = {
                    Task: 'CreatingExcel',
                    Start : 0,
                    End : 0,
                    Total:arrInfosDataFilter.length
                }
                msg = JSON.stringify(msg);
                httpResponse.send(msg);

                var tempFilePath = tempfile('.xlsx');
                url = dbIP;
                const options = {
                    filename: tempFilePath,//tempFilePath//ProfileDBName+'.xlsx'
                    useStyles: true,
                    useSharedStrings: true
                };
                const workbook = new Excel.stream.xlsx.WorkbookWriter(options);

                arrFilterData;
                dbo = db.db(ProfileDBName);
                dbo.collection("infos").find({}).toArray(function (err, result)
                {   
                        filterQueryData;
                        const worksheet_metadata = workbook.addWorksheet('metadata', {properties:{tabColor:{argb:'FF00FF00'},color: { argb: 'FFFFFFFF' },showGridLines: false,views:[{xSplit: 1, ySplit:1}]}});
                        const worksheet = workbook.addWorksheet('data', {properties:{tabColor:{argb:'FFC0000'},color: { argb: 'FFFFFFFF' },showGridLines: false,views:[{xSplit: 1, ySplit:1}]}});
                        var arrExcelCols=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ","BA","BB","BC","BD","BE","BF","BG","BH","BI","BJ","BK","BL","BM","BN","BO","BP","BQ","BR","BS","BT","BU","BV","BW","BX","BY","BZ","CA","CB","CC","CD","CE","CF","CG","CH","CI","CJ","CK","CL","CM","CN","CO","CP","CQ","CR","CS","CT","CU","CV","CW","CX","CY","CZ","DA","DB","DC","DD","DE","DF","DG","DH","DI","DJ","DK","DL","DM","DN","DO","DP","DQ","DR","DS","DT","DU","DV","DW","DX","DY","DZ","EA","EB","EC","ED","EE","EF","EG","EH","EI","EJ","EK","EL","EM","EN","EO","EP","EQ","ER","ES","ET","EU","EV","EW","EX","EY","EZ"];
                        var keys = Object.keys(arrFilterData[ 0 ]);
                        for (var rm = 0; rm < keys.length; rm++)
                        {
                            var kn=keys[ rm ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                            if(kn=="_id" || kn=="__EMPTY" || kn=="Unnamed__0" || kn=="" || kn=="0" || kn=="Unnamed: 0")
                            {
                                keys.splice(rm, 1);
                                rm=-1;
                            }
                        }
                        var columns=[];
                        for (var t = 0; t < keys.length; t++)
                        {
                            keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                            if (t == keys.length - 1)
                            {
                                columns.push({ header: keyname, key: keyname,width: 50 });
                                if(filterQueryData.length==0)
                                {
                                    columns.push({ header: 'USER_ACTION', key: 'USER_ACTION',width: 30 });
                                    columns.push({ header: 'SCORE', key: 'SCORE',width: 30 });
                                    columns.push({ header: 'ACTION_RESULT', key: 'ACTION_RESULT',width: 30 });
                                    columns.push({ header: 'ACTION_DATE', key: 'ACTION_DATE',width: 30 });
                                    columns.push({ header: 'COMMENT', key: 'COMMENT',width: 30 });
                                }
                                else
                                {
                                    var iUSER_ACTION=0;
                                    var iACTION_DATE=0;
                                    var iACTION_RESULT=0;
                                    var iSCORE=0;
                                    var iCOMMENT=0;
                                    if(filterQueryData[0].appliedUserAction.length>0)
                                    {
                                        for(var tm=0;tm<filterQueryData[0].appliedFilter.length;tm++)
                                        {
                                            if(iUSER_ACTION==0 && (filterQueryData[0].appliedFilter[tm].Column=="pending" || filterQueryData[0].appliedFilter[tm].Column=="relevant" || filterQueryData[0].appliedFilter[tm].Column=="not-relevant"))
                                            {
                                                iUSER_ACTION=1;
                                                columns.push({ header: 'USER_ACTION', key: 'USER_ACTION',width: 30 });
                                            }
                                            if(iACTION_DATE==0 && (filterQueryData[0].appliedFilter[tm].Column=="unread" || filterQueryData[0].appliedFilter[tm].Column=="read"))
                                            {
                                                iACTION_DATE=1;
                                                columns.push({ header: 'ACTION_DATE', key: 'ACTION_DATE',width: 30 });
                                            }
                                            if(iACTION_RESULT==0 && (filterQueryData[0].appliedFilter[tm].Column=="review" || filterQueryData[0].appliedFilter[tm].Column=="skip"))
                                            {
                                                iACTION_RESULT=1;
                                                columns.push({ header: 'ACTION_RESULT', key: 'ACTION_RESULT',width: 30 });
                                            }
                                        }
                                        for(var tq=0;tq<filterQueryData[0].appliedUserAction.length;tq++)
                                        {
                                            if(iSCORE==0 && (filterQueryData[0].appliedUserAction[tq].Column=="score"))
                                            {
                                                iSCORE=1;
                                                columns.push({ header: 'SCORE', key: 'SCORE',width: 30 });
                                            }
                                            if(iCOMMENT==0 && (filterQueryData[0].appliedUserAction[tq].Column=="comment"))
                                            {
                                                iCOMMENT=1
                                                columns.push({ header: 'COMMENT', key: 'COMMENT',width: 30 });
                                            }
                                        }
                                    }
                                    else
                                    {
                                        for(var tm=0;tm<filterQueryData[0].appliedFilter.length;tm++)
                                        {
                                            if(iUSER_ACTION==0 && (filterQueryData[0].appliedFilter[tm].Column=="pending" || filterQueryData[0].appliedFilter[tm].Column=="relevant" || filterQueryData[0].appliedFilter[tm].Column=="not-relevant"))
                                            {
                                                iUSER_ACTION=1;
                                                columns.push({ header: 'USER_ACTION', key: 'USER_ACTION',width: 30 });
                                            }
                                            if(iACTION_DATE==0 && (filterQueryData[0].appliedFilter[tm].Column=="unread" || filterQueryData[0].appliedFilter[tm].Column=="read"))
                                            {
                                                iACTION_DATE=1;
                                                columns.push({ header: 'ACTION_DATE', key: 'ACTION_DATE',width: 30 });
                                            }
                                            if(iACTION_RESULT==0 && (filterQueryData[0].appliedFilter[tm].Column=="review" || filterQueryData[0].appliedFilter[tm].Column=="skip"))
                                            {
                                                iACTION_RESULT=1;
                                                columns.push({ header: 'ACTION_RESULT', key: 'ACTION_RESULT',width: 30 });
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (t == 0)
                                {
                                    columns.push({ header: 'SNO', key: 'SNO',width: 10 });
                                    columns.push({ header: keyname, key: keyname,width: 20 });
                                }
                                else if (t == 3)
                                {
                                    columns.push({ header: keyname, key: keyname,width: 50 });
                                }
                                else
                                {
                                    columns.push({ header: keyname, key: keyname,width: 50 });
                                }
                            }
                        }

                    arrInfosDataFilter;
                    arrFilterData;
                    if (err) console.log(err);
                    arrInfosData = [];

                    //cloneing code
                    result.forEach(row =>
                    {
                        var cloneObj = {};
                        arrInfosData.push(cloneObj);
                        Object.keys(row).forEach(key =>
                        {
                            cloneObj[key] = JSON.parse(JSON.stringify(row[key]));
                        })
                    })
                    //keys.splice(0, 1);
                    var arrMetaData=[];
                    var cells={};
                    var metadata={};
                    var columns_metadata=[];
                    
                    columns_metadata.push({ header: 'Type', key: 'Type', width: 20 });
                    columns_metadata.push({ header: 'Name', key: 'Name', width: 30 });
                    columns_metadata.push({ header: 'Fields/Condition', key: 'Fields/Condition', width: 30 });
                    columns_metadata.push({ header: 'Keywords/Weight', key: 'Keywords/Weight', width: 30 });
                    columns_metadata.push({ header: 'Created by', key: 'Created by', width: 30 });
                    columns_metadata.push({ header: 'Created date', key: 'Created date', width: 30 });
                    
                    worksheet_metadata.columns = columns_metadata;
                    var colName=''
                    for(var col=0;col<columns_metadata.length;col++)
                    {
                        colName=arrExcelCols[col]+"1";
                        worksheet_metadata.getCell(colName).font = { color: { argb: '#000000' } };
                        worksheet_metadata.getCell(colName).fill = { type: 'pattern',pattern:'solid',fgColor:{argb:'FF6ACFFF'},bgColor:{argb:'FF000000'} };
                    }

                    columns_metadata=[];
                    
                    if(arrInfosData[0].categories.length>0)
                    {
                        var dt=new Date(arrInfosData[0].created);
                        metadata={
                            "Type":"Profile name",
                            "Name":ProfileDBName,
                            "Fields/Condition":"-",
                            "Keywords/Weight":"-",
                            "Created by":arrInfosData[0].user,
                            "Created date":("0" + (dt.getMonth()+1)).slice(-2)+"/"+("0" + dt.getDate()).slice(-2)+"/"+dt.getFullYear()
                        }
                        arrMetaData.push(metadata);
                        worksheet_metadata.addRow(metadata).commit();
                        metadata={};
                        for(var z=0;z<arrInfosData[0].categories.length;z++)
                        {
                            metadata={
                                        "Type":"Category",
                                        "Name":arrInfosData[0].categories[z].catname,
                                        "Fields/Condition":arrInfosData[0].categories[z].fields.join(" , "),
                                        "Keywords/Weight":arrInfosData[0].categories[z].keywords.join(" , "),
                                        "Created by":"",
                                        "Created date":""
                                    }
                                    arrMetaData.push(metadata);
                                    worksheet_metadata.addRow(metadata).commit();
                                    metadata={};
                        }
                    }
                    if(arrInfosData[0].scoring.length>0)
                    {
                        for(var m=0;m<arrInfosData[0].scoring.length;m++)
                        {
                            metadata={
                                "Type":"Score",
                                "Name":arrInfosData[0].scoring[m].name,
                                "Fields/Condition":arrInfosData[0].scoring[m].query,
                                "Keywords/Weight":arrInfosData[0].scoring[m].weight,
                                "Created by":"",
                                "Created date":""
                            }
                            arrMetaData.push(metadata);
                            worksheet_metadata.addRow(metadata).commit();
                            metadata={};
                        }
                    }
                    if(arrInfosData[0].bucket!=undefined)
                    {
                        if(arrInfosData[0].bucket.length>0)
                        {
                            for(var l=0;l<arrInfosData[0].bucket.length;l++)
                            {
                                keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                if(filterQueryData[0].appliedUserAction.length>0)
                                {
                                    if(filterQueryData[0].appliedBuckets.length>0)
                                    {
                                        for(var b=0;b<filterQueryData[0].appliedBuckets.length;b++)
                                        {
                                            if(keyname==filterQueryData[0].appliedBuckets[b].Column)
                                            {
                                                columns.push({ header: keyname, key: keyname,width: 50 });
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // no bucket added
                                    }
                                }
                                else
                                {
                                    columns.push({ header: keyname, key: keyname,width: 50 });
                                }
                            }
                        }
                    }
                    worksheet.columns = columns;
                    colName='';
                    for(var col=0;col<columns.length;col++)
                    {
                        colName=arrExcelCols[col]+"1";
                        worksheet.getCell(colName).font = { color: { argb: '#000000' } };
                        worksheet.getCell(colName).fill = { type: 'pattern',pattern:'solid',fgColor:{argb:'FF6ACFFF'},bgColor:{argb:'FF000000'} };
                    }
                    columns=[];
                    
                    var dbContent="";
                    var msg = {
                        Task: 'CreatingColumns',
                        Start : 0,
                        End : 0,
                        Total:arrInfosDataFilter.length
                    }
                    msg = JSON.stringify(msg);
                    httpResponse.send(msg);
                    var iRowCount=0;
                    for (var r = 0; r < arrFilterData.length; r++)
                    {
                        cells={};
                        for (var t = 0; t < keys.length; t++)
                        {
                            var ret = arrInfosDataFilter.filter(function (em)
                            {
                                return (em.parent == arrFilterData[ r ]._id)
                            })
                            if (ret.length > 0)
                            {
                                if (t == keys.length - 1)
                                {
                                    keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                    dbContent=arrFilterData[ r ][ keys[ t ] ]==null?"":arrFilterData[ r ][ keys[ t ] ];
                                    if(dbContent!=null && dbContent!="" && dbContent.length>30000)
                                    {
                                        dbContent=dbContent.substring(0,30000);
                                    }
                                    cells[keyname]=dbContent;

                                    if(filterQueryData.length==0)
                                    {
                                        cells["USER_ACTION"]=ret[ 0 ].useraction;
                                        cells["SCORE"]=ret[ 0 ].score;
                                        cells["ACTION_RESULT"]=ret[ 0 ].score_result;
                                        cells["ACTION_DATE"]=ret[ 0 ].modified;
                                        cells["COMMENT"]=ret[ 0 ].comment;
                                    }
                                    else
                                    {
                                        if(filterQueryData[0].appliedUserAction.length>0)
                                        {
                                            for(tm=0;tm<filterQueryData[0].appliedFilter.length;tm++)
                                            {
                                                if(filterQueryData[0].appliedFilter[tm].Column=="pending" || filterQueryData[0].appliedFilter[tm].Column=="relevant" || filterQueryData[0].appliedFilter[tm].Column=="not-relevant")
                                                {
                                                    cells["USER_ACTION"]=ret[ 0 ].useraction;
                                                }
                                                if(filterQueryData[0].appliedFilter[tm].Column=="unread" || filterQueryData[0].appliedFilter[tm].Column=="read")
                                                {
                                                    cells["ACTION_DATE"]=ret[ 0 ].modified;
                                                }
                                                if(filterQueryData[0].appliedFilter[tm].Column=="review" || filterQueryData[0].appliedFilter[tm].Column=="skip")
                                                {
                                                    cells["ACTION_RESULT"]=ret[ 0 ].score_result;
                                                }
                                            }
                                            if(filterQueryData[0].appliedUserAction.length>0)
                                            {
                                                for(var tq=0;tq<filterQueryData[0].appliedUserAction.length;tq++)
                                                {
                                                    if(filterQueryData[0].appliedUserAction[tq].Column=="score")
                                                    {
                                                        cells["SCORE"]=ret[ 0 ].score;
                                                    }
                                                    if(filterQueryData[0].appliedUserAction[tq].Column=="comment")
                                                    {
                                                        cells["COMMENT"]=ret[ 0 ].comment;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            for(var tm=0;tm<filterQueryData[0].appliedFilter.length;tm++)
                                            {
                                                if(filterQueryData[0].appliedFilter[tm].Column=="pending" || filterQueryData[0].appliedFilter[tm].Column=="relevant" || filterQueryData[0].appliedFilter[tm].Column=="not-relevant")
                                                {
                                                    cells["USER_ACTION"]=ret[ 0 ].useraction;
                                                }
                                                if(filterQueryData[0].appliedFilter[tm].Column=="unread" || filterQueryData[0].appliedFilter[tm].Column=="read")
                                                {
                                                    cells["ACTION_DATE"]=ret[ 0 ].modified;
                                                }
                                                if(filterQueryData[0].appliedFilter[tm].Column=="review" || filterQueryData[0].appliedFilter[tm].Column=="skip")
                                                {
                                                    cells["ACTION_RESULT"]=ret[ 0 ].score_result;
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (t == 0)
                                    {
                                        cells["SNO"]=(r + 1);
                                        keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                        dbContent=arrFilterData[ r ][ keys[ t ] ]==null?"":arrFilterData[ r ][ keys[ t ] ];
                                        if(dbContent!=null && dbContent!="" && dbContent.length>30000)
                                        {
                                            dbContent=dbContent.substring(0,30000);
                                        }
                                        cells[keyname]=dbContent;
                                    }
                                    else if (t == 3)
                                    {
                                        keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                        dbContent=arrFilterData[ r ][ keys[ t ] ]==null?"":arrFilterData[ r ][ keys[ t ] ];
                                        if(dbContent!=null && dbContent!="" && dbContent.length>30000)
                                        {
                                            dbContent=dbContent.substring(0,30000);
                                        }
                                        cells[keyname]=dbContent;
                                    }
                                    else
                                    {
                                        keyname=keys[ t ].replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                        dbContent=arrFilterData[ r ][ keys[ t ] ]==null?"":arrFilterData[ r ][ keys[ t ] ];
                                        if(dbContent!=null && dbContent!="" && dbContent.length>30000)
                                        {
                                            dbContent=dbContent.substring(0,30000);
                                        }
                                        cells[keyname]=dbContent;
                                    }
                                }
                            }
                        }
                        
                        if(arrInfosData[0].bucket!=undefined)
                        {
                            if(arrInfosData[0].bucket.length>0)
                            {
                                var appendBuk="";
                                for(var l=0;l<arrInfosData[0].bucket.length;l++)
                                {
                                    appendBuk="";
                                    if(filterQueryData[0].appliedUserAction.length>0)
                                    {
                                        if(filterQueryData[0].appliedBuckets.length>0)
                                        {
                                            for(var b=0;b<filterQueryData[0].appliedBuckets.length;b++)
                                            {
                                                if(arrInfosData[0].bucket[l].bucketname==filterQueryData[0].appliedBuckets[b].Column)
                                                {
                                                    if(arrInfosData[0].bucket[l].bucketdetail.length>0)
                                                    {
                                                        for(var c=0;c<arrInfosData[0].bucket[l].bucketdetail.length;c++)
                                                        {
                                                            var bkInfo=arrInfosData[0].bucket[l].bucketdetail;
                                                            var comment="";
                                                            //var cnt=arrFilterData[ r ][ bkInfo[c].fieldname ].substring(parseInt(bkInfo[c].range.from),parseInt(bkInfo[c].range.to))
                                                            var cnt="";
                                                            if(bkInfo[c].itemId==arrFilterData[ r ]._id && bkInfo[c].status=="active")
                                                            {
                                                                //appendBuk=appendBuk+"<b>"+bkInfo[c].fieldname+" : </b>"+cnt+";"
                                                                if(bkInfo[c].comment!=undefined)
                                                                {
                                                                    if(bkInfo[c].comment!="")
                                                                        appendBuk=appendBuk+bkInfo[c].text+"#"+bkInfo[c].comment+";"
                                                                    else
                                                                        appendBuk=appendBuk+bkInfo[c].text+";"
                                                                }
                                                                else
                                                                {
                                                                    appendBuk=appendBuk+bkInfo[c].text+";"
                                                                }
                                                                //appendBuk=appendBuk+cnt+";"
                                                            }
                                                        }
                                                    }
                                                    if(appendBuk!=="")
                                                    {
                                                        keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                        cells[keyname]=appendBuk;
                                                    }
                                                    else
                                                    {
                                                        keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                                        cells[keyname]="";
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            appendBuk="";
                                        }
                                    }
                                    else
                                    {
                                        if(arrInfosData[0].bucket[l].bucketdetail.length>0)
                                        {
                                            for(var c=0;c<arrInfosData[0].bucket[l].bucketdetail.length;c++)
                                            {
                                                var bkInfo=arrInfosData[0].bucket[l].bucketdetail;
                                                //var cnt=arrFilterData[ r ][ bkInfo[c].fieldname ].substring(parseInt(bkInfo[c].range.from),parseInt(bkInfo[c].range.to))
                                                var cnt="";
                                                if(bkInfo[c].itemId==arrFilterData[ r ]._id && bkInfo[c].status=="active")
                                                {
                                                    if(bkInfo[c].comment!=undefined)
                                                    {
                                                        if(bkInfo[c].comment!="")
                                                            appendBuk=appendBuk+bkInfo[c].text+"#"+bkInfo[c].comment+";"
                                                        else
                                                            appendBuk=appendBuk+bkInfo[c].text+";"
                                                    }
                                                    else
                                                    {
                                                        appendBuk=appendBuk+bkInfo[c].text+";"
                                                    }
                                                    //appendBuk=appendBuk+"<b>"+bkInfo[c].fieldname+" : </b>"+cnt+";"
                                                    //appendBuk=appendBuk+cnt+";"
                                                }
                                            }
                                        }
                                        if(appendBuk!=="")
                                        {
                                            keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                            cells[keyname]=appendBuk;
                                        }
                                        else
                                        {
                                            keyname=arrInfosData[0].bucket[l].bucketname.replace(/[^a-zA-Z0-9]/ig, "_").replace(/  +/g, ' ').replace(/\s/g,'_');
                                            cells[keyname]="";
                                        }
                                    }
                                }
                            }
                        }
                        worksheet.addRow(cells).commit();
                        cells={};
                        iRowCount++;
                        var dbContent="";
                        var msg = {
                            Task: 'CommitingRow',
                            Start : iRowCount,
                            End : 0,
                            Total:arrInfosDataFilter.length
                        }
                        msg = JSON.stringify(msg);
                        httpResponse.send(msg);


                    }
                    workbook.commit().then(function(data,res) 
                    {
                        //console.log(tempFilePath);
                        var msg = {
                            Task: 'finish',
                            Start : 0,
                            End : 0,
                            Total:arrInfosDataFilter.length
                        }
                        msg = JSON.stringify(msg);
                        httpResponse.send(msg);

                        fs.readFile(tempFilePath,(err,data)=>
                        {
                            if(err)throw err;
                            var dbContent="";

                            var msg = {
                                Task: 'Complete',
                                Start : 0,
                                End : 0,
                                Total:arrInfosDataFilter.length
                            }
                            msg = JSON.stringify(msg);
                            httpResponse.send(msg);

                            httpResponse.sendBinary(data,function()
                            {
                                httpResponse.close();
                            });
                        });
                    });
                    db.close();
                })
            }
        });
    }

    
    
    router.get("/ExcelExport_exceljs/:filename/:page/:perPage/:filterdata", (req, res) =>
    {
        var url1 = req.url;
        var qs = url1.split("?")[1];
        res.writeHead(200,'text/html');
        res.end(`
        <div id="div_loader"><div style="position: fixed;background: rgba(78, 78, 78, 0.6);left:0;right:0;top:0;bottom:0;text-align: center;z-index:10000;"><span style="position:absolute;top:40%;left:50%;transform:translate(-50%);width:50px;background:url(http://ggnwgsk4qtx6t2:8082/images/loader_excelExport_newtab.gif);height:50px;background-size:contain;"></span>
            <div id="div_msg" style="position:absolute;width:600px;height:100px;top:45%;left:35%;margin-left:20px;margin-top:100px;color: #fff;font-family:  arial;font-weight: bold;">File is downloading. Please do not close or refresh this window.</div>
                <div id="div_msgalter" style="position:absolute;width:600px;height:100px;top:50%;left:35%;margin-left:20px;margin-top:100px;color: #fff;font-family:  arial;"></div>
            </div>
        </div>
        <script>
        
        const socket = new WebSocket('ws://ggnwgsk4qtx6t2:8001');
        var query ={
            filename:"${req.params.filename}",
            page:${req.params.page},
            perPage:${req.params.perPage},
            filterdata:${req.params.filterdata},
            qs:"${qs}"
        };
        // Connection opened
        socket.addEventListener('open', function (event) {
            socket.send(JSON.stringify(query));
        });
        
        // Listen for messages
        var blobs = [];
        
        socket.addEventListener('message', function (event) {
            var data = event.data;
            if(typeof data == 'string')
            {
                //console.log(data);
                var obj = JSON.parse(data);
                //console.log(obj);
                if(obj.Task=='FetchingData')
                {
                    document.getElementById('div_msgalter').innerHTML='Fetching records [ '+obj.Start+' to '+obj.End+' ] / '+obj.Total+' from database.';
                }
                else if(obj.Task=='CreatingExcel')
                {
                    document.getElementById('div_msgalter').innerHTML='Creating excel file';
                }
                else if(obj.Task=='CreatingColumns')
                {
                    document.getElementById('div_msgalter').innerHTML='Creating columns in excel file.';
                }
                else if(obj.Task=='CommitingRow')
                {
                    document.getElementById('div_msgalter').innerHTML=''+obj.Start+' / '+obj.Total+' rows have been committed in the excel file.';
                }
                else if(obj.Task=='Complete' || obj.Task=='finish')
                {
                    document.getElementById("div_msg").innerHTML='Excel file has been created successfully. Now you can download.';
                    document.getElementById('div_msgalter').innerHTML='Note : Please close this window after download.';
                }
            }
            else if(data instanceof Blob)
            {
                blobs.push(data);
            }
        });
        socket.addEventListener('close',function()
        {
            var bigBlob = new Blob(blobs,{type:'application/octet-stream'});
            if (window.navigator && window.navigator.msSaveOrOpenBlob) 
            {
                window.navigator.msSaveBlob(bigBlob, ${req.params.filename} );
                return;
            }
            else
            {
                var a = document.createElement('a');
                a.href = URL.createObjectURL(bigBlob);
                a.download = "${req.params.filename}";
                a.click();
                window.setTimeout(function(){window.close();},5000);
            }
        })
        </script>
        `);
    });
    
    router.get("/ExcelExport_exceljs11/:filename/:page/:perPage/:filterdata",(req,res)=>
    {
        var url1 = req.url;
        var httpResponse = res;
        
        var pageNo = parseInt(req.params.page)
        var size = parseInt(req.params.perPage)
        var SourceDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
        var SourceDBPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
        var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
        var ProfileDBPath = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
        arrInfosDataFilter = new Array();
        arrFilterData = new Array();
        arrInfosData=new Array();
        var tempFilePath = tempfile('.xlsx');
        url = dbIP;
        const options = {
            filename: tempFilePath,//tempFilePath//ProfileDBName+'.xlsx'
            useStyles: true,
            useSharedStrings: true
          };
        const workbook = new Excel.stream.xlsx.WorkbookWriter(options);
      
        MongoClient.connect(url, function (err, db)
        {
            if (err) console.log(err);
            var dbo = db.db(ProfileDBName);
            dbo.collection("data").find({}).toArray(function (err, result)
            {
                if (err) console.log(err);
                var arrJson = JSON.stringify(result);
                arrInfosDataFilter = JSON.parse(arrJson);
                var inId = "";
                if (arrInfosDataFilter.length > 0)
                {
                    dbo = db.db(SourceDBName);
                    var arrPagination=[];
                    if(arrInfosDataFilter.length<=size)
                    {
                        arrPagination.push({"Start":1,"End":arrInfosDataFilter.length,"PaggingStatus":false});
                    }
                    else
                    {
                        var TotalPages=Math.ceil(arrInfosDataFilter.length/size);
                        var preEnd=0;
                        for(var tm=0;tm<TotalPages;tm++)
                        {
                            if(tm==0)
                            {
                                arrPagination.push({"Start":1,"End":size,"PaggingStatus":false});
                            }
                            else if(tm==TotalPages-1)
                            {
                                preStart=arrPagination[tm-1].Start;
                                preEnd=arrPagination[tm-1].End;
                                arrPagination.push({"Start":(preEnd+1),"End":(arrInfosDataFilter.length),"PaggingStatus":false});
                            }
                            else
                            {
                                preStart=arrPagination[tm-1].Start;
                                preEnd=arrPagination[tm-1].End;
                                arrPagination.push({"Start":(preEnd+1),"End":(preEnd+size),"PaggingStatus":false});
                            }
                        }
                    }
                    arrFilterData = [];
                    getSourceDataInfo(arrPagination,arrInfosDataFilter,0,dbo,db,ProfileDBName,httpResponse);
                }
            });
        });
    });

    
    
    Array.prototype.flexFilter = function(info)
    {
        var matchesFilter, matches = [], count;
        matchesFilter = function(item) 
        {
            count = 0
            for (var n = 0; n < info.length; n++) 
            {
                var val = info[n]["Values"];

                if(typeof val == 'function')
                {
                    if( val(item[info[n]["Field"]]))
                    count++;
                    continue;
                }
                else if (val.indexOf(item[info[n]["Field"]]) > -1) {
                    count++;
                    continue;
                }
                else
                {
                    var docontinue = false;
                    for(var i=0; i<val.length; i++)
                    {
                    var valFn = val[i];
                    if(typeof valFn == 'function')
                    {
                        if(valFn(item[info[n]["Field"]]))
                        count++;
                        docontinue=true;
                        break;
                    }
                    }
                    if(docontinue)continue;
                }
            }
            return count == info.length;
        }
        for (var i = 0; i < this.length; i++) 
        {
            if (matchesFilter(this[i])) 
            {
                matches.push(this[i]);
            }
        }
        return matches;
    }
    
    var server = ws.createServer(function (conn) 
    {
            //console.log("New connection")
            conn.on("text", function (str) {
            //console.log("Received "+str)
            var obj = JSON.parse(str);
    
            
            var httpResponse = conn;
            var url1 = '?' + obj.qs;
    
            var pageNo = parseInt(obj.page);
            var size = parseInt(obj.perPage);
            var filterQueryData=obj.filterdata;
            var SourceDBName = (((url1.split('?')[ 1 ]).split('&')[ 0 ]).split('=')[ 1 ]);
            var SourceDBPath = (((url1.split('?')[ 1 ]).split('&')[ 1 ]).split('=')[ 1 ]);
            var ProfileDBName = (((url1.split('?')[ 1 ]).split('&')[ 2 ]).split('=')[ 1 ]);
            var ProfileDBPath = (((url1.split('?')[ 1 ]).split('&')[ 3 ]).split('=')[ 1 ]);
            
            arrInfosDataFilter = new Array();
            arrFilterData = new Array();
            arrInfosData=new Array();
            var tempFilePath = tempfile('.xlsx');
            url = dbIP;
            const options = {
                filename: tempFilePath,//tempFilePath//ProfileDBName+'.xlsx'
                useStyles: true,
                useSharedStrings: true
              };
            const workbook = new Excel.stream.xlsx.WorkbookWriter(options);
          
            MongoClient.connect(url, function (err, db)
            {
                if (err) console.log(err);
                var dbo = db.db(ProfileDBName);
                /*
                var query=[];
                var criteria=[];
                if(filterQueryData.length>0)
                {
                    if(filterQueryData[0].appliedFilter.length>0)
                    {
                        for(var z=0;z<filterQueryData[0].appliedFilter.length;z++)
                        {
                            if(filterQueryData[0].appliedFilter[z].Column=="pending")
                            {
                                query.push({useraction:""});
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="relevant")
                            {
                                query.push({useraction:"relevant"});
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="not-relevant")
                            {
                                query.push({useraction:"not-relevant"});
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="read")
                            {
                                var qry={
                                    $and : [
                                        {modified:{ $ne: ""}}, 
                                        {modified:{ $ne: undefined}},
                                        {modified:{ $ne: null}},
                                        {useraction:""}
                                    ]
                                };
                                query.push(qry);
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="unread")
                            {
                                var qry={
                                    $and : [
                                        {modified:{ $eq: ""}}, 
                                        {modified:{ $eq: undefined}},
                                        {modified:{ $eq: null}},
                                        {useraction:""}
                                    ]
                                };
                                query.push(qry);
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="review")
                            {
                                var qry={
                                    $or : [
                                        {score_result:{ $eq: "Review"}}, 
                                        {score_result:{ $eq: "review" }},
                                    ]
                                };
                            }
                            else if(filterQueryData[0].appliedFilter[z].Column=="skip")
                            {
                                var qry={
                                    $or : [
                                        {score_result:{ $eq: "skip"}}, 
                                        {score_result:{ $eq: "Skip" }},
                                    ]
                                };
                            }
                        }
                    }
                    else
                    {
                        query={};
                    }
                }
                else
                {
                    query={};
                }
                */
                dbo.collection("data").find({}).toArray(function (err, result)
                {
                    if (err) console.log(err);
                    var arrJson = JSON.stringify(result);
                    arrInfosDataFilter=[];
                    arrInfosDataFilter = JSON.parse(arrJson);
                    filterQueryData;
                    var criteria=[];
                    if(filterQueryData.length>0 && filterQueryData[0].appliedFilter.length>0)
                    {
                            for(var z=0;z<filterQueryData[0].appliedFilter.length;z++)
                            {
                                var retResponse=criteria.filter(function(n)
                                {
                                    if(filterQueryData[0].appliedFilter[z].Column=="pending")
                                        return (n.Field=="useraction")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="relevant")
                                        return (n.Field=="useraction")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="not-relevant")
                                        return (n.Field=="useraction")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="read")
                                        return (n.Field=="modified")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="unread")
                                        return (n.Field=="modified")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="review")
                                        return (n.Field=="score_result")
                                    else if(filterQueryData[0].appliedFilter[z].Column=="skip")
                                        return (n.Field=="score_result")
                                    
                                });
                                if(retResponse.length>0)
                                {
                                    var arrResponse=retResponse[0].Values;
                                    var resultret=arrResponse.filter(function(n)
                                    {
                                        return (n==filterQueryData[0].appliedFilter[z].Column)
                                    });
                                    if(resultret.length==0)
                                    {
                                        if(filterQueryData[0].appliedFilter[z].Column=="read")
                                        {
                                            retResponse[0].Values.push(function(val){return val!==null && val!==undefined && val!==''});
                                        }
                                        else if(filterQueryData[0].appliedFilter[z].Column=="unread")
                                        {
                                            retResponse[0].Values.push(null);
                                            retResponse[0].Values.push("");
                                        }
                                        else
                                        {
                                             retResponse[0].Values.push(filterQueryData[0].appliedFilter[z].Column);
                                        }
                                    }
                                }
                                else
                                {
                                    if(filterQueryData[0].appliedFilter[z].Column=="pending")
                                        criteria.push({ Field: "useraction", Values: ["",null] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="relevant")
                                        criteria.push({ Field: "useraction", Values: ["relevant"] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="not-relevant")
                                        criteria.push({ Field: "useraction", Values: ["not-relevant"] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="read")
                                        criteria.push({ Field: "modified", Values: [function(val){return val!==null && val!==undefined && val!==''}] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="unread")
                                        criteria.push({ Field: "modified", Values: ["",null] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="review")
                                        criteria.push({ Field: "score_result", Values: ["review","Review","REVIEW"] });
                                    else if(filterQueryData[0].appliedFilter[z].Column=="skip")
                                        criteria.push({ Field: "score_result", Values: ["skip","Skip","SKIP"] });
                                }
                            }
                            var filtered = arrInfosDataFilter.flexFilter(criteria);
                            arrInfosDataFilter=filtered;
                    }
                    var inId = "";
                    if (arrInfosDataFilter.length > 0)
                    {
                        dbo = db.db(SourceDBName);
                        var arrPagination=[];
                        if(arrInfosDataFilter.length<=size)
                        {
                            arrPagination.push({"Start":1,"End":arrInfosDataFilter.length,"PaggingStatus":false});
                        }
                        else
                        {
                            var TotalPages=Math.ceil(arrInfosDataFilter.length/size);
                            var preEnd=0;
                            for(var tm=0;tm<TotalPages;tm++)
                            {
                                if(tm==0)
                                {
                                    arrPagination.push({"Start":1,"End":size,"PaggingStatus":false});
                                }
                                else if(tm==TotalPages-1)
                                {
                                    preStart=arrPagination[tm-1].Start;
                                    preEnd=arrPagination[tm-1].End;
                                    arrPagination.push({"Start":(preEnd+1),"End":(arrInfosDataFilter.length),"PaggingStatus":false});
                                }
                                else
                                {
                                    preStart=arrPagination[tm-1].Start;
                                    preEnd=arrPagination[tm-1].End;
                                    arrPagination.push({"Start":(preEnd+1),"End":(preEnd+size),"PaggingStatus":false});
                                }
                            }
                        }
                        arrFilterData = [];
                        getSourceDataInfo(arrPagination,arrInfosDataFilter,0,dbo,db,ProfileDBName,httpResponse,filterQueryData);
                    }
                });
            });
        
        })
        conn.on("close", function (code, reason) {
            console.log("Connection closed")
        })
        
    }).listen(8001)


})();
module.exports = router;